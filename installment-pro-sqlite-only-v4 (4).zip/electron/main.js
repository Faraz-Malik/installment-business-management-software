// ============================================================
// InstallmentPro - Electron Desktop App
// ============================================================
// This file turns the Next.js web app into a Windows desktop
// application. When you build the .exe, Electron:
//   1. Starts the Next.js server internally on port 3847
//   2. Opens a native window pointing to that server
//   3. Uses SQLite (installment-pro.db) instead of PostgreSQL
//   4. Saves the database file inside the user's AppData folder
//      so nothing is lost when the app is updated.
// ============================================================

const { app, BrowserWindow, Menu, dialog, shell, ipcMain } = require("electron");
const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");
const http = require("http");

let mainWindow;
let nextServer;

const isDev = !app.isPackaged;
const PORT = 3847;

// ---- Where should the database file live? ----
// In production: %APPDATA%/InstallmentPro/installment-pro.db  (persistent)
// In development: project folder
const userDataPath = app.getPath("userData");
process.env.DB_PATH = path.join(userDataPath, "installment-pro.db");
process.env.NODE_ENV = "production";
process.env.PORT = String(PORT);

// -----------------------------------------------------------------
// Wait until the internal Next.js server is ready to accept requests
// -----------------------------------------------------------------
function waitForServer(url, timeout = 60000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const check = () => {
      http
        .get(url, (res) => {
          if (res.statusCode && res.statusCode < 500) {
            resolve();
          } else {
            retry();
          }
        })
        .on("error", retry);
    };
    const retry = () => {
      if (Date.now() - start > timeout) {
        reject(new Error("Server startup timed out"));
      } else {
        setTimeout(check, 400);
      }
    };
    check();
  });
}

// -----------------------------------------------------------------
// Start the internal Next.js server
// -----------------------------------------------------------------
function startNextServer() {
  const appPath = isDev
    ? path.join(__dirname, "..")
    : path.join(process.resourcesPath, "app");

  const serverJs = path.join(appPath, "server.js");

  nextServer = spawn(process.execPath, [serverJs], {
    cwd: appPath,
    env: {
      ...process.env,
      ELECTRON_RUN_AS_NODE: "1",
      HOSTNAME: "127.0.0.1",
      PORT: String(PORT),
    },
    stdio: ["ignore", "pipe", "pipe"],
  });

  nextServer.stdout.on("data", (d) => console.log(`[Server] ${d}`));
  nextServer.stderr.on("data", (d) => console.error(`[Server Error] ${d}`));
  nextServer.on("exit", (code) =>
    console.log(`[Server] exited with code ${code}`),
  );
}

// -----------------------------------------------------------------
// Create the main app window
// -----------------------------------------------------------------
async function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    title: "InstallmentPro",
    backgroundColor: "#0f172a",
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, "preload.js"),
    },
  });

  // Show a friendly loading screen while the server starts
  mainWindow.loadURL(
    "data:text/html;charset=utf-8," +
      encodeURIComponent(`
      <html>
        <body style="background:#0f172a;color:#fff;font-family:-apple-system,Segoe UI,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;flex-direction:column;">
          <h1 style="margin:0;font-size:32px;">Installment<span style="color:#10b981;">Pro</span></h1>
          <p style="color:#94a3b8;margin-top:8px;">Starting your business suite…</p>
          <div style="margin-top:20px;width:220px;height:4px;background:#1e293b;border-radius:4px;overflow:hidden;position:relative;">
            <div style="position:absolute;width:40%;height:100%;background:#10b981;animation:load 1.2s infinite ease-in-out;"></div>
          </div>
          <style>@keyframes load{0%{left:-40%}100%{left:100%}}</style>
        </body>
      </html>
    `),
  );
  mainWindow.show();

  startNextServer();

  try {
    await waitForServer(`http://127.0.0.1:${PORT}`);
    mainWindow.loadURL(`http://127.0.0.1:${PORT}`);
  } catch (err) {
    dialog.showErrorBox(
      "Startup Error",
      "InstallmentPro could not start its internal server.\n\n" +
        String(err),
    );
    app.quit();
  }

  // Simple application menu
  const menu = Menu.buildFromTemplate([
    {
      label: "File",
      submenu: [
        {
          label: "Open Database Folder",
          click: () => shell.openPath(userDataPath),
        },
        { type: "separator" },
        { role: "reload" },
        { role: "quit" },
      ],
    },
    {
      label: "View",
      submenu: [
        { role: "zoomIn" },
        { role: "zoomOut" },
        { role: "resetZoom" },
        { type: "separator" },
        { role: "togglefullscreen" },
      ],
    },
    {
      label: "Help",
      submenu: [
        {
          label: "About InstallmentPro",
          click: () => {
            dialog.showMessageBox({
              type: "info",
              title: "About InstallmentPro",
              message: "InstallmentPro v1.0.0",
              detail:
                "Offline Installment Business Management System.\n\n" +
                "Your data is safely stored on this computer at:\n" +
                userDataPath +
                "\n\nNo internet required. No monthly fees.",
            });
          },
        },
      ],
    },
  ]);
  Menu.setApplicationMenu(menu);
}

// -----------------------------------------------------------------
// PDF export (Tasks 4/5): renders the current page to a real,
// vector-quality PDF via Chromium's print engine and lets the user
// choose where to save it.
// -----------------------------------------------------------------
ipcMain.handle("save-as-pdf", async (event, defaultFileName) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win) return { ok: false, error: "Window not found" };

  const { canceled, filePath } = await dialog.showSaveDialog(win, {
    title: "Save as PDF",
    defaultPath: defaultFileName || "document.pdf",
    filters: [{ name: "PDF Document", extensions: ["pdf"] }],
  });
  if (canceled || !filePath) return { ok: false, canceled: true };

  try {
    const pdfBuffer = await win.webContents.printToPDF({
      printBackground: true,
      pageSize: "A4",
      margins: { top: 0.4, bottom: 0.4, left: 0.4, right: 0.4 },
    });
    fs.writeFileSync(filePath, pdfBuffer);
    return { ok: true, filePath };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
});

// -----------------------------------------------------------------
// App lifecycle
// -----------------------------------------------------------------
app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (nextServer) nextServer.kill();
  app.quit();
});

app.on("before-quit", () => {
  if (nextServer) nextServer.kill();
});
