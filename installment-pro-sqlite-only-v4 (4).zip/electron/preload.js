// ============================================================
// Preload script (Tasks 4/5 — PDF export)
// ============================================================
// This is the ONLY IPC surface this app exposes. It exists for
// one reason: a plain web page (which is what the renderer is —
// this app doesn't use Node integration or IPC anywhere else)
// cannot generate a real, vector-quality PDF on its own. Browsers
// don't expose "save this page as PDF" to page JavaScript for
// security reasons — only Electron's main process can do that,
// via webContents.printToPDF(), which uses Chromium's actual print
// engine (same one behind the existing Print button) rather than
// rasterizing the page into an image the way most client-side "PDF
// export" JS libraries do. That's why this needs a small IPC
// bridge instead of a new npm dependency.
//
// contextIsolation stays on; nodeIntegration stays off. Only this
// one function is exposed, nothing else from Electron/Node leaks
// into the page.
// ============================================================

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electronAPI", {
  saveAsPDF: (defaultFileName) =>
    ipcRenderer.invoke("save-as-pdf", defaultFileName),
});
