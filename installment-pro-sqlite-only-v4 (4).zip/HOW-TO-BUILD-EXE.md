# 🏗️ HOW TO BUILD THE `.EXE` INSTALLER

**Follow these steps EXACTLY, in order. Do not skip any step.**

This guide is written for anyone — no advanced knowledge needed.

---

## ✅ STEP 1: Install Node.js on Your Computer (One-time only)

1. Open your web browser
2. Go to: **https://nodejs.org/**
3. Click the big green **"LTS"** button (the one that says "Recommended for most users")
4. Wait for the download to finish
5. Double-click the downloaded file (`node-vXX.X.X-x64.msi`)
6. Click **Next → Next → Next → Install → Finish**

### 👉 Test that it worked:

1. Press **`Windows key + R`** on your keyboard
2. Type `cmd` and press **Enter** — a black window opens
3. Type this and press Enter:
   ```
   node --version
   ```
4. If you see something like `v20.11.0` — ✅ Success! Close the black window.

---

## ✅ STEP 2: Install VS Code (Free Code Editor)

1. Go to: **https://code.visualstudio.com/**
2. Click **"Download for Windows"**
3. Run the downloaded file
4. Click **Next → Next → ✅ Check "Add to PATH" → Install → Finish**

---

## ✅ STEP 3: Extract the Project ZIP

1. Move the downloaded project ZIP to a simple location like:
   ```
   C:\Projects\InstallmentPro\
   ```
2. Right-click the ZIP → **"Extract All..."** → click **"Extract"**
3. You should now see a folder with files like `package.json`, `src`, etc.

---

## ✅ STEP 4: Open the Project in VS Code

1. Open **VS Code**
2. Click menu: **File → Open Folder**
3. Select the extracted project folder (`C:\Projects\InstallmentPro`)
4. Click **"Select Folder"**
5. On the left side, you should see files/folders listed ✅

---

## ✅ STEP 5: Open the Terminal Inside VS Code

1. In VS Code, click menu: **Terminal → New Terminal**
   (Or press: **`Ctrl + ~`** on your keyboard)
2. A black area opens at the bottom of VS Code
3. You should see something like:
   ```
   PS C:\Projects\InstallmentPro>
   ```

---

## ✅ STEP 6: Install All Required Packages

In the VS Code Terminal (bottom of screen), type this command and press **Enter**:

```
npm install
```

**Wait 5-10 minutes.** You'll see a lot of text scrolling. This is normal. ☕ Grab a cup of tea.

When done, you'll see the prompt (`PS C:\...>`) come back.

### 👉 If you see an ERROR (red text):

Try running this instead:
```
npm install --legacy-peer-deps
```

---

## ✅ STEP 7: Build the Next.js App

In the same terminal, type:

```
npm run build
```

**Wait 2-3 minutes.** You should see:
```
✓ Compiled successfully
```

at the end. If yes, ✅ continue.

---

## ✅ STEP 8: Build the `.exe` Installer!

This is the big moment! Type:

```
npm run electron:build
```

**Wait 10-20 minutes.** It's downloading Electron (~150 MB) and packaging your app.

You'll see lots of progress messages. Just wait patiently. ☕☕

When it's done, you'll see something like:
```
• building        target=nsis file=dist-installer\InstallmentPro-Setup-1.0.0.exe
```

---

## 🎉 STEP 9: Find Your Installer!

1. In VS Code (left sidebar), you'll see a NEW folder called **`dist-installer`**
2. Click to open it
3. Inside you'll find:
   ```
   📦 InstallmentPro-Setup-1.0.0.exe  ← THIS IS YOUR INSTALLER!
   ```
4. This file is about **150-200 MB**
5. Right-click on it → **"Show in File Explorer"** to see it in Windows

**🎉 CONGRATULATIONS! You built a real Windows installer!**

---

## ✅ STEP 10: Test It On Your Own PC First

1. Double-click `InstallmentPro-Setup-1.0.0.exe`
2. Windows may show a blue **"SmartScreen"** warning:
   - Click **"More info"** (small text)
   - Click **"Run anyway"** button
   - _(This warning appears because the file is not "signed" — it's normal for small developers. Client can safely ignore it.)_
3. The installer opens → Click **Next → Next → Install → Finish**
4. Look at your Desktop — there's now an **"InstallmentPro"** icon!
5. Double-click it → The app opens in its own window! 🎉

### Test everything works:
- Add a supplier
- Add a customer
- Create an installment sale
- Receive a payment
- Print a receipt
- Go to Settings and download a backup

If everything works ✅ — you are ready to give it to your client!

---

## 📦 STEP 11: Deliver to Client

### What to bring:
1. A **USB drive** with:
   - `InstallmentPro-Setup-1.0.0.exe`
   - `USER-MANUAL.md` (in this project folder)

### Installation at client's PC (10 minutes):
1. Plug USB into client's computer
2. Copy the `.exe` file to their Desktop
3. Double-click it → Click "More info" → "Run anyway"
4. Click Next → Next → Install → Finish
5. Double-click the new Desktop icon → App opens

### Training the client (15 minutes):
1. Click **Settings** in sidebar → Fill in business name, phone, currency → Save
2. Show them **Suppliers** → Add supplier
3. Show them **Customers** → Add customer
4. Show them **Purchases** → Record a purchase
5. Show them **Installment Sales** → Create a deal
6. Show them **Payments** → Receive a payment → Print receipt
7. **VERY IMPORTANT:** Show them **Settings → Download Backup** — tell them to do this every week!

---

## 🔧 Common Problems & Fixes

| Problem | Solution |
|---|---|
| `npm install` fails | Run: `npm install --legacy-peer-deps` |
| `better-sqlite3` build error | Install Python from python.org (check "Add to PATH") → run `npm install` again |
| Build takes too long | Normal on slow internet — first time can be 30 min |
| `.exe` won't open on client PC | Right-click → "Run as administrator" |
| SmartScreen keeps blocking | Click "More info" → "Run anyway" (safe) |
| Client wants to move app to another PC | Copy backup file → install on new PC → restore backup |
| Client's data disappeared after Windows update | Check: `C:\Users\[Name]\AppData\Roaming\InstallmentPro\` |

---

## 💾 Where is the Client's Data Stored?

After installation, the client's data lives at:

```
C:\Users\[ClientName]\AppData\Roaming\InstallmentPro\installment-pro.db
```

- This is a **single file** containing ALL their data
- If they want to move to a new PC → copy this file
- Backups downloaded from Settings are JSON files (safer for long-term storage)

---

## 🎁 Reusing This Software for Other Clients

To install for a **second client**, just:

1. Copy the same `InstallmentPro-Setup-1.0.0.exe` file
2. Install on their PC (same steps)
3. Each client gets their own separate database — data never mixes! ✅

You can charge $100 per installation. 💰

---

## 🆘 Need to Rebuild Later?

If you make code changes and want a new installer:

1. Open project in VS Code
2. Open Terminal (`Ctrl + ~`)
3. Run: `npm run electron:build`
4. New `.exe` appears in `dist-installer/` folder

That's it!

---

## 📞 Summary of All Commands

```
npm install              → Install everything (first time only)
npm run electron:dev     → Test the app in dev mode
npm run electron:build   → Build the final .exe installer
```

---

**You did it! You just built professional Windows software. 🎉**

_If any step fails, take a screenshot of the error and search Google for the exact error message. Node.js errors are well-documented online._
