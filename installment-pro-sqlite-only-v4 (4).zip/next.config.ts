import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // "standalone" output creates a self-contained server.js
  // that Electron can run inside the desktop app.
  // For the online preview it also works fine.
  output: "standalone",
  // Prevent bundlers from trying to bundle SQLite native binaries
  serverExternalPackages: ["better-sqlite3"],
  // Belt-and-suspenders fix for a real issue found during packaging:
  // routes doing dynamic file I/O (backup/restore) made Turbopack's
  // file tracer over-include the entire project — raw .ts source,
  // docs, the license-tool folder — into .next/standalone, which
  // then shipped inside the installer. Explicitly excluding these
  // guarantees they're never included, regardless of which exact
  // line the tracer gets confused by.
  outputFileTracingExcludes: {
    "*": [
      "./src/**/*.ts",
      "./src/**/*.tsx",
      "./license-tool/**",
      "./*.md",
      "./electron/**",
      "./scripts/**",
      "./drizzle.config.ts",
      "./eslint.config.mjs",
      "./postcss.config.mjs",
      "./tsconfig*.json",
      "./tsconfig.tsbuildinfo",
      "./dist-installer/**",
    ],
  },
};

export default nextConfig;
