"use client";
import { useEffect } from "react";

// Replaces window.alert(). See ConfirmDialog.tsx for why: native
// blocking dialogs are a known source of stuck focus/unresponsive
// clicks in Electron on Windows.

export function Toast({
  message,
  onClose,
}: {
  message: string | null;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!message) return;
    const t = setTimeout(onClose, 4000);
    return () => clearTimeout(t);
  }, [message, onClose]);

  if (!message) return null;
  return (
    <div className="fixed bottom-4 right-4 z-[70] max-w-sm bg-rose-600 text-white text-sm rounded-lg shadow-lg px-4 py-3 flex items-start gap-3">
      <span className="flex-1">{message}</span>
      <button
        type="button"
        onClick={onClose}
        className="text-white/80 hover:text-white leading-none"
        aria-label="Dismiss"
      >
        ✕
      </button>
    </div>
  );
}
