"use client";

export function ArchiveTabs({
  view,
  onChange,
}: {
  view: "active" | "archived";
  onChange: (v: "active" | "archived") => void;
}) {
  return (
    <div className="flex gap-1 p-1 bg-slate-100 rounded-md">
      <button
        type="button"
        onClick={() => onChange("active")}
        className={`px-3 py-1.5 text-xs font-medium rounded ${
          view === "active"
            ? "bg-white shadow-sm text-slate-900"
            : "text-slate-500 hover:text-slate-700"
        }`}
      >
        Active
      </button>
      <button
        type="button"
        onClick={() => onChange("archived")}
        className={`px-3 py-1.5 text-xs font-medium rounded ${
          view === "archived"
            ? "bg-white shadow-sm text-slate-900"
            : "text-slate-500 hover:text-slate-700"
        }`}
      >
        Archived
      </button>
    </div>
  );
}
