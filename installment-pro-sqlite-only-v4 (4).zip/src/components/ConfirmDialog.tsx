"use client";

// Replaces window.confirm(). Native, synchronous confirm()/alert()
// dialogs are a well-documented source of stuck focus / unresponsive
// clicks in Electron apps on Windows — the renderer's pointer-event
// dispatch can fail to recover properly after the blocking dialog
// closes. This is a plain React-rendered modal instead, so it never
// blocks the render/event loop.

export type ConfirmRequest = {
  message: string;
  onConfirm: () => void;
};

export function ConfirmDialog({
  request,
  onClose,
}: {
  request: ConfirmRequest | null;
  onClose: () => void;
}) {
  if (!request) return null;
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-[60]">
      <div className="bg-white rounded-lg w-full max-w-sm p-5 space-y-4">
        <p className="text-sm text-slate-800">{request.message}</p>
        <div className="flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm rounded border border-slate-300"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              request.onConfirm();
              onClose();
            }}
            className="px-4 py-2 text-sm rounded bg-rose-600 text-white hover:bg-rose-700"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
}
