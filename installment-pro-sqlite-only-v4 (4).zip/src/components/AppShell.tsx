"use client";
import { usePathname, useRouter } from "next/navigation";
import Link from "next/link";
import type { ReactNode } from "react";

const topItems = [
  { href: "/", label: "Dashboard", icon: "📊" },
  { href: "/calculator", label: "Fast Deal Calculator", icon: "🧮" },
];

const groups = [
  {
    label: "Sales",
    items: [
      { href: "/customers", label: "Customers", icon: "👥" },
      { href: "/sales", label: "Installment Sales", icon: "💼" },
      { href: "/payments", label: "Payments", icon: "💵" },
    ],
  },
  {
    label: "Inventory",
    items: [
      { href: "/suppliers", label: "Suppliers", icon: "🏭" },
      { href: "/purchases", label: "Purchases", icon: "🧾" },
    ],
  },
  {
    label: "Money",
    items: [
      { href: "/investors", label: "Investors", icon: "💰" },
      { href: "/expenses", label: "Expenses", icon: "📉" },
      { href: "/reports", label: "Reports", icon: "📈" },
    ],
  },
];

const bottomItems = [{ href: "/settings", label: "Settings", icon: "⚙️" }];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  // The login and activation screens render full-bleed, without the
  // app sidebar — everything else keeps the exact existing shell/
  // layout unchanged.
  if (pathname === "/login" || pathname === "/activate") {
    return <>{children}</>;
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  function isActive(href: string) {
    return href === "/" ? pathname === "/" : pathname.startsWith(href);
  }

  function NavLink({ href, label, icon }: { href: string; label: string; icon: string }) {
    const active = isActive(href);
    return (
      <Link
        href={href}
        className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${
          active
            ? "bg-slate-800 text-white font-medium"
            : "text-slate-300 hover:bg-slate-800 hover:text-white"
        }`}
      >
        <span className="text-base">{icon}</span>
        <span>{label}</span>
      </Link>
    );
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-64 shrink-0 bg-slate-900 text-slate-100 flex flex-col">
        <div className="px-6 py-5 border-b border-slate-800">
          <div className="text-lg font-bold tracking-tight">
            Installment<span className="text-emerald-400">Pro</span>
          </div>
          <div className="text-xs text-slate-400 mt-0.5">
            Business Management Suite
          </div>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {topItems.map((item) => (
            <NavLink key={item.href} {...item} />
          ))}
          {groups.map((group) => (
            <div key={group.label} className="pt-3">
              <div className="px-3 pb-1 text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                {group.label}
              </div>
              {group.items.map((item) => (
                <NavLink key={item.href} {...item} />
              ))}
            </div>
          ))}
          <div className="pt-3">
            {bottomItems.map((item) => (
              <NavLink key={item.href} {...item} />
            ))}
          </div>
        </nav>
        <div className="px-4 py-3 border-t border-slate-800 space-y-2">
          <button
            onClick={logout}
            className="w-full text-left text-xs text-slate-400 hover:text-white flex items-center gap-2"
          >
            <span>🚪</span> Logout
          </button>
          <div className="text-xs text-slate-500">v1.0.0 · Offline Ready</div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-x-auto">
        <div className="max-w-7xl mx-auto px-8 py-8">{children}</div>
      </main>
    </div>
  );
}
