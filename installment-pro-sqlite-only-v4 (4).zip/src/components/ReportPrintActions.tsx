"use client";
import { saveAsPDF } from "@/lib/pdf";

export function ReportPrintActions() {
  return (
    <div className="flex gap-2 print:hidden">
      <button
        onClick={() => saveAsPDF(`Business-Report-${new Date().toISOString().slice(0, 10)}.pdf`)}
        className="px-4 py-2 rounded-md border border-slate-300 text-sm hover:bg-slate-50"
      >
        ⬇ Save as PDF
      </button>
      <button
        onClick={() => window.print()}
        className="px-4 py-2 rounded-md bg-slate-900 text-white text-sm font-medium hover:bg-slate-800"
      >
        🖨 Print
      </button>
    </div>
  );
}
