import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

// ------------------------------------------------------------
// SQLite-native schema, matching the raw DDL in db/index.ts
// column-for-column. This app's only real target is the offline
// SQLite desktop database (see ARCHITECTURE.md / TECHNOLOGY-
// DECISIONS.md) — the schema previously used drizzle-orm/pg-core
// (pgTable, serial, timestamp().defaultNow(), boolean, numeric),
// which generates Postgres-specific SQL. Every insert that relied
// on a column default (createdAt via .defaultNow(), which Drizzle
// compiles to a literal `now()` call) failed under better-sqlite3
// with `SqliteError: no such function: now`, since SQLite has no
// now() function — it needs CURRENT_TIMESTAMP instead. This
// affected every table with a createdAt default, i.e. essentially
// every insert in the app.
// ------------------------------------------------------------

// Users (for future auth; local single-user app). Not created by
// the current migration DDL in db/index.ts and not imported by any
// route today — kept for forward compatibility, matching its
// original "future auth" status.
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  fullName: text("full_name"),
  role: text("role").notNull().default("owner"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

// Suppliers
export const suppliers = sqliteTable("suppliers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  phone: text("phone"),
  address: text("address"),
  cnic: text("cnic"),
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  archivedAt: text("archived_at"), // NULL = active, set = archived (soft-deleted)
});

// Customers
export const customers = sqliteTable("customers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  cnic: text("cnic"),
  phone: text("phone"),
  address: text("address"),
  guarantorName: text("guarantor_name"),
  guarantorPhone: text("guarantor_phone"),
  guarantorPermanentAddress: text("guarantor_permanent_address"),
  guarantorCurrentAddress: text("guarantor_current_address"),
  guarantorOccupation: text("guarantor_occupation"),
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  archivedAt: text("archived_at"), // NULL = active, set = archived (soft-deleted)
});

// Purchases (owner buys from supplier)
export const purchases = sqliteTable("purchases", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  supplierId: integer("supplier_id")
    .notNull()
    .references(() => suppliers.id),
  itemName: text("item_name").notNull(),
  purchasePrice: real("purchase_price").notNull(),
  purchaseDate: text("purchase_date").notNull(),
  paymentStatus: text("payment_status").notNull().default("paid"), // paid | unpaid | partial
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  archivedAt: text("archived_at"), // NULL = active, set = archived (soft-deleted)
});

// Installment sales (deal to customer)
export const installmentSales = sqliteTable("installment_sales", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id")
    .notNull()
    .references(() => customers.id),
  purchaseId: integer("purchase_id").references(() => purchases.id),
  productName: text("product_name").notNull(),
  purchasePrice: real("purchase_price").notNull(),
  profitPercent: real("profit_percent").notNull(),
  profitAmount: real("profit_amount").notNull(),
  finalPrice: real("final_price").notNull(),
  downPayment: real("down_payment").notNull().default(0),
  remainingBalance: real("remaining_balance").notNull(),
  numInstallments: integer("num_installments").notNull(),
  installmentAmount: real("installment_amount").notNull(),
  frequency: text("frequency").notNull().default("monthly"), // weekly | monthly
  startDate: text("start_date").notNull(),
  status: text("status").notNull().default("active"), // active | completed | cancelled
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  archivedAt: text("archived_at"), // NULL = active, set = archived (soft-deleted)
});

// Payments received from customers
export const payments = sqliteTable("payments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  saleId: integer("sale_id")
    .notNull()
    .references(() => installmentSales.id, { onDelete: "cascade" }),
  amount: real("amount").notNull(),
  paidOn: text("paid_on").notNull(),
  method: text("method").notNull().default("cash"),
  receiptNumber: text("receipt_number").notNull().unique(),
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  archivedAt: text("archived_at"), // NULL = active, set = archived (soft-deleted)
});

// Expenses
export const expenses = sqliteTable("expenses", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  amount: real("amount").notNull(),
  category: text("category"),
  spentOn: text("spent_on").notNull(),
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  archivedAt: text("archived_at"), // NULL = active, set = archived (soft-deleted)
});

// Settings (single-row style)
export const settings = sqliteTable("settings", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  businessName: text("business_name").notNull().default("My Business"),
  businessPhone: text("business_phone"),
  businessAddress: text("business_address"),
  currency: text("currency").notNull().default("PKR"),
  taxPercent: real("tax_percent").notNull().default(0),
  receiptFooter: text("receipt_footer"),
  isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
  // "full_price" (default, existing behavior): profit % applies to the
  // entire purchase price. "remaining_balance": profit % applies only
  // to (purchase price - down payment). With no down payment, both
  // modes produce the identical result — the formula naturally
  // collapses to the same thing, no special-casing needed.
  profitCalculationMode: text("profit_calculation_mode")
    .notNull()
    .default("full_price"),
});

// ------------------------------------------------------------
// Improvement 2 — Fast Deal Calculator "leads". A quotation the
// user chose to save (the calculator itself never touches the
// database until the user explicitly clicks "Save as Lead").
// ------------------------------------------------------------
export const leads = sqliteTable("leads", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name"),
  phone: text("phone"),
  // Same customer detail fields the Customers form collects, so a
  // quotation converted to a sale creates a fully-detailed customer
  // record, not just a name and phone number.
  cnic: text("cnic"),
  address: text("address"),
  guarantorName: text("guarantor_name"),
  guarantorPhone: text("guarantor_phone"),
  guarantorPermanentAddress: text("guarantor_permanent_address"),
  guarantorCurrentAddress: text("guarantor_current_address"),
  guarantorOccupation: text("guarantor_occupation"),
  productName: text("product_name"),
  notes: text("notes"),
  purchasePrice: real("purchase_price").notNull(),
  profitPercent: real("profit_percent").notNull(),
  downPayment: real("down_payment").notNull().default(0),
  discount: real("discount").notNull().default(0),
  numInstallments: integer("num_installments").notNull(),
  frequency: text("frequency").notNull().default("monthly"),
  profitCalculationMode: text("profit_calculation_mode")
    .notNull()
    .default("full_price"),
  // Optional — same as "Linked Purchase (optional)" on the New Sale
  // form. If set, converting this lead to a sale carries the
  // supplier link through automatically; if left blank, the
  // resulting sale has no supplier link, exactly like a manually
  // created sale with no Linked Purchase selected.
  purchaseId: integer("purchase_id"),
  convertedToSaleId: integer("converted_to_sale_id"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  archivedAt: text("archived_at"),
});

// ============================================================
// Improvement 3 — Investment Management
// ============================================================
// Nothing here hardcodes a financial formula. An investor's terms
// live entirely in their agreement (fixed/percentage/profit-share/
// hybrid/manual), and every rupee that moves — a contribution, a
// return payment, a reinvestment, a withdrawal, a settlement
// adjustment — is one row in investment_transactions. That table
// is the single source of truth / audit trail: balances are always
// derived from it, never stored and silently drifted out of sync.
// ============================================================

export const investors = sqliteTable("investors", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  cnic: text("cnic"),
  phone: text("phone"),
  address: text("address"),
  notes: text("notes"),
  status: text("status").notNull().default("active"), // active | inactive
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  archivedAt: text("archived_at"),
});

// Reusable presets an agreement can be created from.
export const agreementTemplates = sqliteTable("agreement_templates", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  type: text("type").notNull(), // fixed_monthly | percentage_monthly | profit_sharing | hybrid | manual
  fixedMonthlyAmount: real("fixed_monthly_amount"),
  percentageRate: real("percentage_rate"),
  paymentFrequency: text("payment_frequency").notNull().default("monthly"), // monthly|quarterly|six_monthly|yearly|custom
  reinvestmentMode: text("reinvestment_mode").notNull().default("none"), // full|partial|none
  partialReinvestPercent: real("partial_reinvest_percent"),
  lossPolicy: text("loss_policy").notNull().default("none"), // none|capital_ratio|manual|carry_forward|custom
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const investmentAgreements = sqliteTable("investment_agreements", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  investorId: integer("investor_id")
    .notNull()
    .references(() => investors.id),
  type: text("type").notNull(),
  fixedMonthlyAmount: real("fixed_monthly_amount"),
  percentageRate: real("percentage_rate"),
  paymentFrequency: text("payment_frequency").notNull().default("monthly"),
  reinvestmentMode: text("reinvestment_mode").notNull().default("none"),
  partialReinvestPercent: real("partial_reinvest_percent"),
  lossPolicy: text("loss_policy").notNull().default("none"),
  notes: text("notes"),
  status: text("status").notNull().default("active"), // active | closed
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  closedAt: text("closed_at"),
  archivedAt: text("archived_at"),
});

// One investor can have multiple investments, each under its own
// agreement (an investor could plausibly have two different deals
// with different terms at once).
export const investments = sqliteTable("investments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  investorId: integer("investor_id")
    .notNull()
    .references(() => investors.id),
  agreementId: integer("agreement_id")
    .notNull()
    .references(() => investmentAgreements.id),
  amount: real("amount").notNull(),
  startDate: text("start_date").notNull(),
  status: text("status").notNull().default("active"), // active | closed
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  archivedAt: text("archived_at"),
});

// The audit trail. Every financial movement against an investment
// is one row here — this table is what balances are computed FROM,
// never a cached number that could silently drift.
export const investmentTransactions = sqliteTable("investment_transactions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  investmentId: integer("investment_id")
    .notNull()
    .references(() => investments.id),
  type: text("type").notNull(), // contribution|return_payment|reinvestment|withdrawal|settlement_adjustment
  amount: real("amount").notNull(),
  date: text("date").notNull(),
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

// Owner's own capital ledger — separate from investor money.
export const ownerCapital = sqliteTable("owner_capital", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  type: text("type").notNull(), // initial | additional | withdrawal
  amount: real("amount").notNull(),
  date: text("date").notNull(),
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
