// ============================================================
// DATABASE CONNECTION (SQLite only)
// ============================================================
// This build targets the offline Windows desktop app exclusively.
// There is no PostgreSQL code path — that dual-driver setup was
// the root cause of several bugs (a schema written only for
// Postgres, `.execute()` calls that don't exist on the SQLite
// driver, `::int` casts and `INTERVAL` syntax SQLite can't parse).
// One driver, one schema, one code path.
//
// IMPORTANT: initialization is LAZY (see createLazyProxy below).
// The connection is only opened the first time `db` or `pool` is
// actually used (e.g. `db.select()...`), not merely by importing
// this file. This matters because `next build` imports every API
// route module — across many parallel worker processes at once —
// just to inspect its exports. If opening the database were a
// side effect of import, every one of those worker processes
// would open + CREATE TABLE against the same SQLite file
// simultaneously, and lose the resulting lock race with
// `SqliteError: database is locked` (SQLITE_BUSY) — this only
// shows up on a machine with enough CPU cores for Next to spawn
// many build workers. Lazy init means build-time import is just
// import — nothing touches the real database file until a
// request actually runs.
// ============================================================

/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-require-imports */

function initSqlite() {
  const { drizzle } = require("drizzle-orm/better-sqlite3");
  const Database = require("better-sqlite3");
  const path = require("path");
  const fs = require("fs");

  const dbPath =
    process.env.DB_PATH || path.join(/*turbopackIgnore: true*/ process.cwd(), "installment-pro.db");
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const sqlite = new Database(dbPath);
  // Wait for other processes/connections to release a lock instead
  // of failing immediately with SQLITE_BUSY. This is defense-in-depth
  // for real runtime contention (e.g. a backup/restore in progress) —
  // the build-time contention itself is avoided entirely by making
  // this whole function lazy (see module header comment above).
  sqlite.pragma("busy_timeout = 5000");
  sqlite.pragma("journal_mode = WAL");
  sqlite.pragma("foreign_keys = ON");
  // Task 7 performance review: SQLite's own documentation
  // recommends NORMAL specifically for WAL-mode databases — it's
  // still crash-safe (unlike OFF), but skips the extra fsync on
  // every transaction that FULL (the default) does, which WAL's
  // own durability model already makes unnecessary.
  sqlite.pragma("synchronous = NORMAL");

  // Create tables if they don't exist
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      full_name TEXT,
      role TEXT NOT NULL DEFAULT 'owner',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS suppliers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      address TEXT,
      cnic TEXT,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      cnic TEXT,
      phone TEXT,
      address TEXT,
      guarantor_name TEXT,
      guarantor_phone TEXT,
      guarantor_permanent_address TEXT,
      guarantor_current_address TEXT,
      guarantor_occupation TEXT,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS purchases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
      item_name TEXT NOT NULL,
      purchase_price REAL NOT NULL,
      purchase_date TEXT NOT NULL,
      payment_status TEXT NOT NULL DEFAULT 'paid',
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS installment_sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_id INTEGER NOT NULL REFERENCES customers(id),
      purchase_id INTEGER REFERENCES purchases(id),
      product_name TEXT NOT NULL,
      purchase_price REAL NOT NULL,
      profit_percent REAL NOT NULL,
      profit_amount REAL NOT NULL,
      final_price REAL NOT NULL,
      down_payment REAL NOT NULL DEFAULT 0,
      remaining_balance REAL NOT NULL,
      num_installments INTEGER NOT NULL,
      installment_amount REAL NOT NULL,
      frequency TEXT NOT NULL DEFAULT 'monthly',
      start_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL REFERENCES installment_sales(id) ON DELETE CASCADE,
      amount REAL NOT NULL,
      paid_on TEXT NOT NULL,
      method TEXT NOT NULL DEFAULT 'cash',
      receipt_number TEXT NOT NULL UNIQUE,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      amount REAL NOT NULL,
      category TEXT,
      spent_on TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      business_name TEXT NOT NULL DEFAULT 'My Business',
      business_phone TEXT,
      business_address TEXT,
      currency TEXT NOT NULL DEFAULT 'PKR',
      tax_percent REAL NOT NULL DEFAULT 0,
      receipt_footer TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      profit_calculation_mode TEXT NOT NULL DEFAULT 'full_price'
    );
    CREATE TABLE IF NOT EXISTS leads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      phone TEXT,
      cnic TEXT,
      address TEXT,
      guarantor_name TEXT,
      guarantor_phone TEXT,
      guarantor_permanent_address TEXT,
      guarantor_current_address TEXT,
      guarantor_occupation TEXT,
      product_name TEXT,
      notes TEXT,
      purchase_price REAL NOT NULL,
      profit_percent REAL NOT NULL,
      down_payment REAL NOT NULL DEFAULT 0,
      discount REAL NOT NULL DEFAULT 0,
      num_installments INTEGER NOT NULL,
      frequency TEXT NOT NULL DEFAULT 'monthly',
      profit_calculation_mode TEXT NOT NULL DEFAULT 'full_price',
      purchase_id INTEGER,
      converted_to_sale_id INTEGER,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS investors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      cnic TEXT,
      phone TEXT,
      address TEXT,
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS agreement_templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      fixed_monthly_amount REAL,
      percentage_rate REAL,
      payment_frequency TEXT NOT NULL DEFAULT 'monthly',
      reinvestment_mode TEXT NOT NULL DEFAULT 'none',
      partial_reinvest_percent REAL,
      loss_policy TEXT NOT NULL DEFAULT 'none',
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS investment_agreements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      investor_id INTEGER NOT NULL REFERENCES investors(id),
      type TEXT NOT NULL,
      fixed_monthly_amount REAL,
      percentage_rate REAL,
      payment_frequency TEXT NOT NULL DEFAULT 'monthly',
      reinvestment_mode TEXT NOT NULL DEFAULT 'none',
      partial_reinvest_percent REAL,
      loss_policy TEXT NOT NULL DEFAULT 'none',
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      closed_at TEXT,
      archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS investments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      investor_id INTEGER NOT NULL REFERENCES investors(id),
      agreement_id INTEGER NOT NULL REFERENCES investment_agreements(id),
      amount REAL NOT NULL,
      start_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      archived_at TEXT
    );
    CREATE TABLE IF NOT EXISTS investment_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      investment_id INTEGER NOT NULL REFERENCES investments(id),
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      date TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS owner_capital (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      date TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Migration for databases created before archiving existed (Tasks 1-2
  // installs): add archived_at to tables that don't have it yet. SQLite
  // has no "ADD COLUMN IF NOT EXISTS", so check via PRAGMA table_info
  // first — safe to run on every startup, a no-op once migrated.
  const archivableTables = [
    "suppliers",
    "customers",
    "purchases",
    "installment_sales",
    "payments",
    "expenses",
  ];
  for (const table of archivableTables) {
    const cols = sqlite.prepare(`PRAGMA table_info(${table})`).all() as {
      name: string;
    }[];
    if (!cols.some((c) => c.name === "archived_at")) {
      sqlite.exec(`ALTER TABLE ${table} ADD COLUMN archived_at TEXT`);
    }
  }

  // Improvement 1: profit_calculation_mode setting, for databases
  // created before this existed. Defaults to 'full_price', matching
  // exactly what every prior version always did — existing
  // installs see zero behavior change until the owner explicitly
  // switches it in Settings.
  const settingsCols = sqlite.prepare(`PRAGMA table_info(settings)`).all() as {
    name: string;
  }[];
  if (!settingsCols.some((c) => c.name === "profit_calculation_mode")) {
    sqlite.exec(
      `ALTER TABLE settings ADD COLUMN profit_calculation_mode TEXT NOT NULL DEFAULT 'full_price'`,
    );
  }

  // Leads got a purchase_id column after the Fast Deal Calculator's
  // first release — same idempotent pattern.
  const leadsCols = sqlite.prepare(`PRAGMA table_info(leads)`).all() as {
    name: string;
  }[];
  if (leadsCols.length && !leadsCols.some((c) => c.name === "purchase_id")) {
    sqlite.exec(`ALTER TABLE leads ADD COLUMN purchase_id INTEGER`);
  }
  const leadCustomerFieldsToAdd: [string, string][] = [
    ["cnic", "TEXT"],
    ["address", "TEXT"],
    ["guarantor_name", "TEXT"],
    ["guarantor_phone", "TEXT"],
    ["guarantor_permanent_address", "TEXT"],
    ["guarantor_current_address", "TEXT"],
    ["guarantor_occupation", "TEXT"],
  ];
  for (const [col, type] of leadCustomerFieldsToAdd) {
    if (leadsCols.length && !leadsCols.some((c) => c.name === col)) {
      sqlite.exec(`ALTER TABLE leads ADD COLUMN ${col} ${type}`);
    }
  }

  // Guarantor detail fields added after the first customers release.
  const customersCols = sqlite.prepare(`PRAGMA table_info(customers)`).all() as {
    name: string;
  }[];
  const guarantorFieldsToAdd: [string, string][] = [
    ["guarantor_permanent_address", "TEXT"],
    ["guarantor_current_address", "TEXT"],
    ["guarantor_occupation", "TEXT"],
  ];
  for (const [col, type] of guarantorFieldsToAdd) {
    if (customersCols.length && !customersCols.some((c) => c.name === col)) {
      sqlite.exec(`ALTER TABLE customers ADD COLUMN ${col} ${type}`);
    }
  }

  // Task 7 performance review: none of these existed before. SQLite
  // does not auto-index foreign key columns, and every list page now
  // filters on archived_at (added in Task 3) on every load — without
  // these, each of those queries does a full table scan. Purely
  // additive and idempotent (IF NOT EXISTS), no behavior change.
  sqlite.exec(`
    CREATE INDEX IF NOT EXISTS idx_suppliers_archived ON suppliers(archived_at);
    CREATE INDEX IF NOT EXISTS idx_customers_archived ON customers(archived_at);
    CREATE INDEX IF NOT EXISTS idx_purchases_archived ON purchases(archived_at);
    CREATE INDEX IF NOT EXISTS idx_purchases_supplier ON purchases(supplier_id);
    CREATE INDEX IF NOT EXISTS idx_sales_archived ON installment_sales(archived_at);
    CREATE INDEX IF NOT EXISTS idx_sales_customer ON installment_sales(customer_id);
    CREATE INDEX IF NOT EXISTS idx_sales_purchase ON installment_sales(purchase_id);
    CREATE INDEX IF NOT EXISTS idx_payments_archived ON payments(archived_at);
    CREATE INDEX IF NOT EXISTS idx_payments_sale ON payments(sale_id);
    CREATE INDEX IF NOT EXISTS idx_expenses_archived ON expenses(archived_at);
  `);

  // Improvement 7 (database optimization): index the new tables' foreign
  // keys and archived_at columns too, same reasoning as Task 7 above.
  sqlite.exec(`
    CREATE INDEX IF NOT EXISTS idx_leads_archived ON leads(archived_at);
    CREATE INDEX IF NOT EXISTS idx_investors_archived ON investors(archived_at);
    CREATE INDEX IF NOT EXISTS idx_agreements_investor ON investment_agreements(investor_id);
    CREATE INDEX IF NOT EXISTS idx_agreements_archived ON investment_agreements(archived_at);
    CREATE INDEX IF NOT EXISTS idx_investments_investor ON investments(investor_id);
    CREATE INDEX IF NOT EXISTS idx_investments_agreement ON investments(agreement_id);
    CREATE INDEX IF NOT EXISTS idx_investments_archived ON investments(archived_at);
    CREATE INDEX IF NOT EXISTS idx_invtx_investment ON investment_transactions(investment_id);
  `);

  // First-run bootstrap: create a default administrator account if
  // none exists yet. Uses bcryptjs's sync API deliberately — this
  // function is itself synchronous (see module header), and this
  // only runs once per fresh database.
  const userCount = sqlite
    .prepare("SELECT COUNT(*) as c FROM users")
    .get() as { c: number };
  if (userCount.c === 0) {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const bcrypt = require("bcryptjs");
    const defaultHash = bcrypt.hashSync("admin123", 10);
    sqlite
      .prepare(
        "INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)",
      )
      .run("admin", defaultHash, "Administrator", "owner");
  }

  return { db: drizzle(sqlite, { schema: require("./schema") }), pool: { sqlite } };
}

let cached: { db: any; pool: any } | null = null;

function getConnection() {
  if (!cached) {
    cached = initSqlite();
  }
  return cached;
}

// Closes the current sqlite connection and clears the cache so the
// next access reinitializes fresh. Used by the restore flow (see
// api/restore/route.ts) to safely swap the underlying .db file on
// disk — better-sqlite3 must release its file handle before the
// file is overwritten, or the replacement can fail/corrupt on
// Windows, which doesn't allow overwriting a file that's still open
// the way POSIX systems do.
export function closeConnection() {
  if (cached) {
    try {
      cached.pool.sqlite.close();
    } catch {
      // already closed or never opened — fine either way
    }
    cached = null;
  }
}

// Lazily resolves `target()[prop]` on first property access instead of
// eagerly at import time. Functions are bound to the real underlying
// object so `this` stays correct when called off the proxy.
function createLazyProxy(pick: (conn: { db: any; pool: any }) => any) {
  return new Proxy(
    {},
    {
      get(_target, prop) {
        const real = pick(getConnection());
        const value = real[prop];
        return typeof value === "function" ? value.bind(real) : value;
      },
      has(_target, prop) {
        return prop in pick(getConnection());
      },
    },
  );
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const db: any = createLazyProxy((conn) => conn.db);
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const pool: any = createLazyProxy((conn) => conn.pool);
