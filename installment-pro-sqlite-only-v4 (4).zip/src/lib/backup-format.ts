export const BACKUP_FORMAT_VERSION = 1;
export const APP_VERSION = "1.0.0";
