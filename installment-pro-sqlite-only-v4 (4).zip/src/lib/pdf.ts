declare global {
  interface Window {
    electronAPI?: {
      saveAsPDF: (
        defaultFileName?: string,
      ) => Promise<{ ok: boolean; canceled?: boolean; error?: string; filePath?: string }>;
    };
  }
}

// Falls back to the browser's own print dialog (where the user can
// pick "Save as PDF" as the destination) when not running inside
// Electron — e.g. during `next dev` in a regular browser tab.
export async function saveAsPDF(defaultFileName?: string) {
  if (typeof window !== "undefined" && window.electronAPI) {
    return window.electronAPI.saveAsPDF(defaultFileName);
  }
  window.print();
  return { ok: true };
}
