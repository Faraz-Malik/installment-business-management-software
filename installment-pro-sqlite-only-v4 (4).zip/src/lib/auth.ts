// ============================================================
// AUTH HELPERS
// ============================================================
// Session tokens are self-contained, HMAC-signed strings (not
// looked up in the database). This is deliberate: middleware.ts
// runs on every request and needs to check the session — keeping
// that check to pure `crypto` (no DB query) keeps middleware fast
// and avoids depending on better-sqlite3 loading correctly inside
// the middleware execution context.
//
// The signing secret is persisted to a small file next to the
// SQLite database (same userData folder) rather than kept only in
// memory. This was tested directly: middleware.ts and the API
// route handlers turned out to run in separate bundled module
// contexts even within the same server process, so an in-memory
// module-level secret was NOT actually shared between them —
// tokens signed by the login route failed to validate in
// middleware. A file on disk is read identically by both.
// It's still generated fresh on first run and never leaves the
// machine — restarting the app does NOT invalidate sessions
// (the secret persists), but the file is regenerated if missing.
// ============================================================

import crypto from "crypto";
import fs from "fs";
import path from "path";
import bcrypt from "bcryptjs";

export const SESSION_COOKIE = "ipro_session";
const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours

function secretFilePath(): string {
  const dbPath =
    process.env.DB_PATH || path.join(/*turbopackIgnore: true*/ process.cwd(), "installment-pro.db");
  return path.join(path.dirname(dbPath), ".session-secret");
}

let cachedSecret: Buffer | null = null;
function getSecret(): Buffer {
  if (cachedSecret) return cachedSecret;

  const filePath = secretFilePath();
  try {
    if (fs.existsSync(filePath)) {
      cachedSecret = Buffer.from(fs.readFileSync(filePath, "utf8"), "hex");
      if (cachedSecret.length === 32) return cachedSecret;
    }
  } catch {
    // fall through to generate a fresh one
  }

  const fresh = crypto.randomBytes(32);
  try {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(filePath, fresh.toString("hex"), { mode: 0o600 });
  } catch {
    // If we can't persist it, sessions just won't survive a process
    // restart — not ideal, but not a crash either.
  }
  cachedSecret = fresh;
  return fresh;
}

export type SessionPayload = {
  uid: number;
  username: string;
  exp: number;
};

function base64url(input: Buffer | string): string {
  return Buffer.from(input)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function base64urlToBuffer(input: string): Buffer {
  const padded = input.replace(/-/g, "+").replace(/_/g, "/");
  return Buffer.from(padded, "base64");
}

export function createSessionToken(uid: number, username: string): string {
  const payload: SessionPayload = {
    uid,
    username,
    exp: Date.now() + SESSION_TTL_MS,
  };
  const payloadB64 = base64url(JSON.stringify(payload));
  const sig = crypto
    .createHmac("sha256", getSecret())
    .update(payloadB64)
    .digest();
  return `${payloadB64}.${base64url(sig)}`;
}

export function verifySessionToken(token: string | undefined): SessionPayload | null {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  const [payloadB64, sigB64] = parts;

  const expectedSig = crypto
    .createHmac("sha256", getSecret())
    .update(payloadB64)
    .digest();
  const actualSig = base64urlToBuffer(sigB64);

  if (
    expectedSig.length !== actualSig.length ||
    !crypto.timingSafeEqual(expectedSig, actualSig)
  ) {
    return null;
  }

  try {
    const payload: SessionPayload = JSON.parse(
      base64urlToBuffer(payloadB64).toString("utf8"),
    );
    if (typeof payload.exp !== "number" || payload.exp < Date.now()) {
      return null;
    }
    return payload;
  } catch {
    return null;
  }
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 10);
}

export async function verifyPassword(
  plain: string,
  hash: string,
): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}
