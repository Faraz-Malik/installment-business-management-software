// ============================================================
// LICENSE ACTIVATION
// ============================================================
// How this works, in plain terms:
//
// 1. On first run, this app generates a random Device ID and saves
//    it permanently next to the database (device-id.txt). It never
//    changes after that, for that install, on that PC.
//
// 2. The Device ID is shown on screen. The client sends it to the
//    developer (WhatsApp, call, email — anything).
//
// 3. The developer runs the separate Key Generator tool (see
//    /license-tool in the project root — NOT shipped to clients),
//    enters that Device ID, and it computes the matching Activation
//    Key using the SAME secret as this file.
//
// 4. The client types that key into the Activate screen. This file
//    recomputes the expected key from the Device ID + this same
//    secret, and compares.
//
// IMPORTANT: LICENSE_SECRET below MUST be identical, character for
// character, in this file AND in license-tool/generate-key.js. If
// they ever differ, every key the tool generates will be rejected.
//
// Honest limitation, stated plainly rather than hidden: this stops
// a copy of the installer being handed to someone else and just
// working — a fresh install generates a new Device ID, so an old
// key won't activate it. It does not stop a sufufficiently
// determined person from reverse-engineering this file to bypass
// the check entirely. No purely offline license check can prevent
// that; this is a deterrent against casual copying, not a vault.
// ============================================================

import crypto from "crypto";
import fs from "fs";
import path from "path";

const LICENSE_SECRET =
  "835b2e4f3e295f1ec30d57bdefe6a2298843c55cd9b6aeadc4397dd38be9cee4";

function dataDir(): string {
  const dbPath =
    process.env.DB_PATH || path.join(/*turbopackIgnore: true*/ process.cwd(), "installment-pro.db");
  return path.dirname(dbPath);
}
function deviceIdPath(): string {
  return path.join(dataDir(), "device-id.txt");
}
function activationPath(): string {
  return path.join(dataDir(), "activation.json");
}

export function getDeviceId(): string {
  const p = deviceIdPath();
  if (fs.existsSync(p)) {
    const existing = fs.readFileSync(p, "utf8").trim();
    if (existing) return existing;
  }
  const id = crypto.randomBytes(8).toString("hex").toUpperCase(); // 16 hex chars
  const dir = path.dirname(p);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(p, id, { mode: 0o600 });
  return id;
}

export function computeExpectedKey(deviceId: string): string {
  const hash = crypto
    .createHmac("sha256", LICENSE_SECRET)
    .update(deviceId.trim().toUpperCase())
    .digest("hex")
    .toUpperCase();
  const raw = hash.slice(0, 20); // 20 hex chars -> 5 groups of 4
  return raw.match(/.{1,4}/g)!.join("-");
}

function normalize(key: string): string {
  return key.toUpperCase().replace(/[^A-Z0-9]/g, "");
}

export function verifyLicenseKey(deviceId: string, key: string): boolean {
  if (!key) return false;
  const expected = computeExpectedKey(deviceId);
  return normalize(expected) === normalize(key);
}

export function isActivated(): boolean {
  const p = activationPath();
  if (!fs.existsSync(p)) return false;
  try {
    const data = JSON.parse(fs.readFileSync(p, "utf8")) as {
      deviceId?: string;
      key?: string;
    };
    if (!data.deviceId || !data.key) return false;
    // Re-check against the CURRENT device ID, not just what's stored —
    // if this whole folder were copied to a different PC, this file
    // travels with it, but the device-id.txt would need to match too
    // for this to matter (see note in README about that edge case).
    return (
      data.deviceId === getDeviceId() && verifyLicenseKey(data.deviceId, data.key)
    );
  } catch {
    return false;
  }
}

export function saveActivation(deviceId: string, key: string): void {
  fs.writeFileSync(
    activationPath(),
    JSON.stringify(
      { deviceId, key: key.toUpperCase(), activatedAt: new Date().toISOString() },
      null,
      2,
    ),
  );
}
