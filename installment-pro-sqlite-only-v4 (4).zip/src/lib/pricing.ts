// ============================================================
// PRICING / PROFIT CALCULATION (Improvement 1)
// ============================================================
// Single source of truth for this formula. It's used by sale
// creation today, and will be used by the Fast Deal Calculator
// (Improvement 2) — kept in one place deliberately, after an
// earlier bug in this project where the same calculation existed
// in two separate files and only one of them got fixed when the
// underlying issue was found.
//
// Two modes, controlled by the business's "Profit Calculation"
// setting:
//   - "full_price" (default, matches every version before this
//     one): profit % applies to the entire purchase price.
//   - "remaining_balance": profit % applies only to the financed
//     amount (purchase price minus down payment).
//
// With a down payment of 0, both modes produce an identical
// result — the formula naturally collapses to the same thing, so
// there's no special-casing needed for "no advance payment".
// ============================================================

export type ProfitCalculationMode = "full_price" | "remaining_balance";

export type PricingInput = {
  purchasePrice: number;
  profitPercent: number;
  downPayment: number;
  numInstallments: number;
  mode: ProfitCalculationMode;
};

export type PricingResult = {
  financedAmount: number;
  profitAmount: number;
  finalPrice: number;
  remainingBalance: number;
  installmentAmount: number;
};

function round2(n: number): number {
  return +n.toFixed(2);
}

export function calculatePricing(input: PricingInput): PricingResult {
  const { purchasePrice, profitPercent, downPayment, numInstallments, mode } = input;

  const financedAmount =
    mode === "remaining_balance" ? purchasePrice - downPayment : purchasePrice;

  const profitAmount = round2(financedAmount * (profitPercent / 100));
  const finalPrice = round2(purchasePrice + profitAmount);
  const remainingBalance = round2(finalPrice - downPayment);
  const installmentAmount =
    numInstallments > 0 ? round2(remainingBalance / numInstallments) : 0;

  return { financedAmount, profitAmount, finalPrice, remainingBalance, installmentAmount };
}
