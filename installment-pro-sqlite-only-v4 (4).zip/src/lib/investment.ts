// ============================================================
// INVESTMENT CALCULATIONS (Improvement 3)
// ============================================================
// Balances are ALWAYS derived from the transaction ledger, never
// stored as a cached number — this is what keeps the audit trail
// meaningful (see schema.ts comments on investment_transactions).
//
// Principal vs. returns are tracked separately on purpose:
//   - contribution / reinvestment / withdrawal / settlement_adjustment
//     move the investment's PRINCIPAL balance (what's actually
//     invested right now).
//   - return_payment is money paid OUT to the investor as their
//     return — it does NOT reduce principal, since it isn't the
//     investor taking their capital back, it's their agreed return
//     on it.
// ============================================================

export type InvestmentTransactionType =
  | "contribution"
  | "return_payment"
  | "reinvestment"
  | "withdrawal"
  | "settlement_adjustment";

export type InvestmentTransaction = {
  type: InvestmentTransactionType;
  amount: number;
};

export type InvestmentBalance = {
  principal: number;
  totalReturnsPaid: number;
  totalReinvested: number;
  totalWithdrawn: number;
};

export function computeInvestmentBalance(
  transactions: InvestmentTransaction[],
): InvestmentBalance {
  let principal = 0;
  let totalReturnsPaid = 0;
  let totalReinvested = 0;
  let totalWithdrawn = 0;

  for (const t of transactions) {
    switch (t.type) {
      case "contribution":
        principal += t.amount;
        break;
      case "reinvestment":
        principal += t.amount;
        totalReinvested += t.amount;
        break;
      case "withdrawal":
        principal -= t.amount;
        totalWithdrawn += t.amount;
        break;
      case "settlement_adjustment":
        principal += t.amount; // amount can be negative (a loss) or positive (a correction)
        break;
      case "return_payment":
        totalReturnsPaid += t.amount;
        break;
    }
  }

  return {
    principal: +principal.toFixed(2),
    totalReturnsPaid: +totalReturnsPaid.toFixed(2),
    totalReinvested: +totalReinvested.toFixed(2),
    totalWithdrawn: +totalWithdrawn.toFixed(2),
  };
}

export type AgreementForReturn = {
  type: string;
  fixedMonthlyAmount: number | null;
  percentageRate: number | null;
};

// Suggests the expected return for one payment period — a starting
// point the owner can accept or override, never posted automatically.
// Returns null for agreement types with no simple formula
// (profit_sharing / hybrid / manual) — those are always manually
// entered, since they depend on information outside this system
// (actual profit that period, or a custom blended rule).
export function suggestReturnAmount(
  agreement: AgreementForReturn,
  currentPrincipal: number,
): number | null {
  if (agreement.type === "fixed_monthly") {
    return agreement.fixedMonthlyAmount ?? null;
  }
  if (agreement.type === "percentage_monthly") {
    if (agreement.percentageRate == null) return null;
    return +((currentPrincipal * agreement.percentageRate) / 100).toFixed(2);
  }
  return null;
}
