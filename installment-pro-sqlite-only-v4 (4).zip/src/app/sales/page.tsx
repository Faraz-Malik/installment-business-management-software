"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";
import { Toast } from "@/components/Toast";
import { ArchiveTabs } from "@/components/ArchiveTabs";
import { calculatePricing, type ProfitCalculationMode } from "@/lib/pricing";

type Sale = {
  id: number;
  customerId: number;
  customerName: string | null;
  productName: string;
  purchasePrice: string;
  profitPercent: string;
  profitAmount: string;
  finalPrice: string;
  downPayment: string;
  remainingBalance: string;
  numInstallments: number;
  installmentAmount: string;
  frequency: string;
  startDate: string;
  status: string;
  totalPaid: string;
  archivedAt: string | null;
};

type Customer = { id: number; name: string };
type Purchase = {
  id: number;
  itemName: string;
  purchasePrice: string;
  supplierName: string | null;
};

export default function SalesPage() {
  const [rows, setRows] = useState<Sale[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [error, setError] = useState<string | null>(null);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [view, setView] = useState<"active" | "archived">("active");
  const [profitMode, setProfitMode] = useState<ProfitCalculationMode>("full_price");

  const [form, setForm] = useState({
    customerId: "",
    purchaseId: "",
    productName: "",
    purchasePrice: "",
    profitPercent: "30",
    downPayment: "0",
    numInstallments: "10",
    frequency: "monthly",
    startDate: new Date().toISOString().slice(0, 10),
    notes: "",
  });

  async function load() {
    setLoading(true);
    const [s, c, p, biz] = await Promise.all([
      fetch(`/api/sales?archived=${view === "archived"}`).then((r) => r.json()),
      fetch("/api/customers").then((r) => r.json()),
      fetch("/api/purchases").then((r) => r.json()),
      fetch("/api/settings").then((r) => r.json()),
    ]);
    setRows(s);
    setCustomers(c);
    setPurchases(p);
    if (biz?.profitCalculationMode) setProfitMode(biz.profitCalculationMode);
    setLoading(false);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  function archive(id: number) {
    setConfirmReq({
      message: "Archive this installment sale? It will be hidden from the active list, and can be restored later.",
      onConfirm: async () => {
        const r = await fetch(`/api/sales/${id}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ archived: true }),
        });
        if (!r.ok) {
          setToast("Failed to archive");
          return;
        }
        await load();
      },
    });
  }

  async function restore(id: number) {
    const r = await fetch(`/api/sales/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archived: false }),
    });
    if (!r.ok) {
      setToast("Failed to restore");
      return;
    }
    await load();
  }

  function removePermanently(id: number) {
    setConfirmReq({
      message: "Permanently delete this installment sale and all its payment history? This cannot be undone.",
      onConfirm: async () => {
        const r = await fetch(`/api/sales/${id}`, { method: "DELETE" });
        if (!r.ok) {
          const err = await r.json().catch(() => ({}));
          setToast(err.error || "Failed to delete");
          return;
        }
        await load();
      },
    });
  }

  const calc = useMemo(() => {
    const pp = parseFloat(form.purchasePrice) || 0;
    const pct = parseFloat(form.profitPercent) || 0;
    const down = parseFloat(form.downPayment) || 0;
    const n = parseInt(form.numInstallments) || 0;
    const result = calculatePricing({
      purchasePrice: pp,
      profitPercent: pct,
      downPayment: down,
      numInstallments: n,
      mode: profitMode,
    });
    return {
      profit: result.profitAmount,
      final: result.finalPrice,
      remaining: result.remainingBalance,
      inst: result.installmentAmount,
    };
  }, [form, profitMode]);

  function onPurchasePick(id: string) {
    const p = purchases.find((x) => String(x.id) === id);
    setForm((f) => ({
      ...f,
      purchaseId: id,
      productName: p ? p.itemName : f.productName,
      purchasePrice: p ? p.purchasePrice : f.purchasePrice,
    }));
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const r = await fetch("/api/sales", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ...form, profitCalculationMode: profitMode }),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      setError(err.error || "Failed to create sale");
      return;
    }
    setShowForm(false);
    setForm({
      customerId: "",
      purchaseId: "",
      productName: "",
      purchasePrice: "",
      profitPercent: "30",
      downPayment: "0",
      numInstallments: "10",
      frequency: "monthly",
      startDate: new Date().toISOString().slice(0, 10),
      notes: "",
    });
    await load();
  }

  const filtered = rows.filter((r) => {
    const matchesSearch = [r.customerName, r.productName]
      .filter(Boolean)
      .join(" ")
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesStatus =
      statusFilter === "all" ? true : r.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div>
      <PageHeader
        title="Installment Sales"
        description="Deals sold to customers on installments."
        actions={
          <button
            onClick={() => {
              setError(null);
              setShowForm(true);
            }}
            className="px-4 py-2 rounded-md bg-slate-900 text-white text-sm font-medium hover:bg-slate-800"
            disabled={customers.length === 0}
            title={
              customers.length === 0
                ? "Add a customer first"
                : "New Sale"
            }
          >
            + New Installment Sale
          </button>
        }
      />

      {customers.length === 0 && (
        <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded text-sm text-amber-800">
          Add at least one customer before creating an installment sale.
        </div>
      )}

      <div className="bg-white rounded-lg border border-slate-200">
        <div className="p-4 border-b border-slate-200 flex gap-3 items-center justify-between flex-wrap">
          <div className="flex gap-3">
            <input
              className="flex-1 max-w-md border border-slate-300 rounded-md px-3 py-2 text-sm"
              placeholder="Search customer, product…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border border-slate-300 rounded-md px-3 py-2 text-sm"
            >
              <option value="all">All statuses</option>
              <option value="active">Active</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
          <ArchiveTabs view={view} onChange={setView} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="text-left px-4 py-2 font-medium">Customer</th>
                <th className="text-left px-4 py-2 font-medium">Product</th>
                <th className="text-right px-4 py-2 font-medium">Final</th>
                <th className="text-right px-4 py-2 font-medium">Paid</th>
                <th className="text-right px-4 py-2 font-medium">Remaining</th>
                <th className="text-left px-4 py-2 font-medium">Plan</th>
                <th className="text-left px-4 py-2 font-medium">Status</th>
                <th className="text-right px-4 py-2 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading && (
                <tr>
                  <td colSpan={8} className="p-6 text-center text-slate-500">
                    Loading…
                  </td>
                </tr>
              )}
              {!loading && filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-6 text-center text-slate-500">
                    No sales found.
                  </td>
                </tr>
              )}
              {filtered.map((s) => {
                const paid =
                  parseFloat(s.totalPaid) + parseFloat(s.downPayment);
                return (
                  <tr key={s.id} className="hover:bg-slate-50">
                    <td className="px-4 py-2 font-medium text-slate-800">
                      {s.customerName ?? "-"}
                    </td>
                    <td className="px-4 py-2">{s.productName}</td>
                    <td className="px-4 py-2 text-right">
                      {formatCurrency(s.finalPrice)}
                    </td>
                    <td className="px-4 py-2 text-right text-emerald-700">
                      {formatCurrency(paid)}
                    </td>
                    <td className="px-4 py-2 text-right text-rose-700 font-medium">
                      {formatCurrency(s.remainingBalance)}
                    </td>
                    <td className="px-4 py-2 text-xs text-slate-600">
                      {s.numInstallments}× {formatCurrency(s.installmentAmount)}
                      <br />
                      <span className="text-slate-400">
                        {s.frequency} · from {formatDate(s.startDate)}
                      </span>
                    </td>
                    <td className="px-4 py-2">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-xs ${
                          s.status === "active"
                            ? "bg-blue-100 text-blue-700"
                            : s.status === "completed"
                              ? "bg-emerald-100 text-emerald-700"
                              : "bg-slate-100 text-slate-600"
                        }`}
                      >
                        {s.status}
                      </span>
                    </td>
                    <td className="px-4 py-2 text-right space-x-2">
                      <Link
                        href={`/sales/${s.id}`}
                        className="text-blue-600 hover:underline text-xs"
                      >
                        Open →
                      </Link>
                      {view === "active" ? (
                        <button
                          onClick={() => archive(s.id)}
                          className="text-amber-600 hover:underline text-xs"
                        >
                          Archive
                        </button>
                      ) : (
                        <>
                          <button
                            onClick={() => restore(s.id)}
                            className="text-emerald-600 hover:underline text-xs"
                          >
                            Restore
                          </button>
                          <button
                            onClick={() => removePermanently(s.id)}
                            className="text-rose-600 hover:underline text-xs"
                          >
                            Delete Permanently
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <form
            onSubmit={save}
            className="bg-white rounded-lg w-full max-w-2xl p-6 space-y-3 max-h-[95vh] overflow-y-auto"
          >
            <h2 className="text-lg font-semibold">New Installment Sale</h2>
            {error && (
              <div className="p-2 bg-rose-50 text-rose-700 text-sm rounded">
                {error}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <Field label="Customer *">
                <select
                  required
                  className="input"
                  value={form.customerId}
                  onChange={(e) =>
                    setForm({ ...form, customerId: e.target.value })
                  }
                >
                  <option value="">Select customer…</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Linked Purchase (optional)">
                <select
                  className="input"
                  value={form.purchaseId}
                  onChange={(e) => onPurchasePick(e.target.value)}
                >
                  <option value="">— None —</option>
                  {purchases.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.itemName} · {formatCurrency(p.purchasePrice)}
                    </option>
                  ))}
                </select>
              </Field>
            </div>

            <Field label="Product Name *">
              <input
                required
                className="input"
                value={form.productName}
                onChange={(e) =>
                  setForm({ ...form, productName: e.target.value })
                }
              />
            </Field>

            <div className="grid grid-cols-3 gap-3">
              <Field label="Purchase Price *">
                <input
                  required
                  type="number"
                  step="0.01"
                  min="0"
                  className="input"
                  value={form.purchasePrice}
                  onChange={(e) =>
                    setForm({ ...form, purchasePrice: e.target.value })
                  }
                />
              </Field>
              <Field label="Profit % *">
                <input
                  required
                  type="number"
                  step="0.01"
                  min="0"
                  className="input"
                  value={form.profitPercent}
                  onChange={(e) =>
                    setForm({ ...form, profitPercent: e.target.value })
                  }
                />
              </Field>
              <Field label="Down Payment">
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  className="input"
                  value={form.downPayment}
                  onChange={(e) =>
                    setForm({ ...form, downPayment: e.target.value })
                  }
                />
              </Field>
              <Field label="Profit Applies To">
                <select
                  className="input"
                  value={profitMode}
                  onChange={(e) =>
                    setProfitMode(e.target.value as ProfitCalculationMode)
                  }
                >
                  <option value="full_price">Full Purchase Price</option>
                  <option value="remaining_balance">
                    Remaining Balance After Down Payment
                  </option>
                </select>
              </Field>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <Field label="Installments *">
                <input
                  required
                  type="number"
                  min="1"
                  step="1"
                  className="input"
                  value={form.numInstallments}
                  onChange={(e) =>
                    setForm({ ...form, numInstallments: e.target.value })
                  }
                />
              </Field>
              <Field label="Frequency">
                <select
                  className="input"
                  value={form.frequency}
                  onChange={(e) =>
                    setForm({ ...form, frequency: e.target.value })
                  }
                >
                  <option value="monthly">Monthly</option>
                  <option value="weekly">Weekly</option>
                </select>
              </Field>
              <Field label="Start Date">
                <input
                  type="date"
                  className="input"
                  value={form.startDate}
                  onChange={(e) =>
                    setForm({ ...form, startDate: e.target.value })
                  }
                />
              </Field>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 grid grid-cols-2 gap-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-600">Profit Amount:</span>
                <span className="font-medium">
                  {formatCurrency(calc.profit)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Final Sale Price:</span>
                <span className="font-semibold text-emerald-700">
                  {formatCurrency(calc.final)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Remaining:</span>
                <span className="font-medium">
                  {formatCurrency(calc.remaining)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Per Installment:</span>
                <span className="font-semibold text-blue-700">
                  {formatCurrency(calc.inst)}
                </span>
              </div>
            </div>

            <Field label="Notes">
              <textarea
                className="input"
                rows={2}
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
            </Field>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2 text-sm rounded border border-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm rounded bg-slate-900 text-white"
              >
                Create Deal
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />
      <Toast message={toast} onClose={() => setToast(null)} />

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-xs text-slate-600 font-medium">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
