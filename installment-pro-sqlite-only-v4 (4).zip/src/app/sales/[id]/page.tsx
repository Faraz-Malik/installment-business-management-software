"use client";
import { use, useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";
import { saveAsPDF } from "@/lib/pdf";

type Payment = {
  id: number;
  amount: string;
  paidOn: string;
  method: string;
  receiptNumber: string;
  notes: string | null;
};
type SaleDetail = {
  sale: {
    id: number;
    customerName: string;
    customerPhone: string | null;
    customerCnic: string | null;
    customerAddress: string | null;
    guarantorName: string | null;
    guarantorPhone: string | null;
    guarantorPermanentAddress: string | null;
    guarantorCurrentAddress: string | null;
    guarantorOccupation: string | null;
    productName: string;
    purchasePrice: string;
    profitPercent: string;
    profitAmount: string;
    finalPrice: string;
    downPayment: string;
    remainingBalance: string;
    numInstallments: number;
    installmentAmount: string;
    frequency: string;
    startDate: string;
    status: string;
    notes: string | null;
  };
  payments: Payment[];
  totals: { totalPaid: number; remaining: number };
};

export default function SaleDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const [data, setData] = useState<SaleDetail | null>(null);
  const [showPay, setShowPay] = useState(false);
  const [form, setForm] = useState({
    amount: "",
    paidOn: new Date().toISOString().slice(0, 10),
    method: "cash",
    notes: "",
  });
  const [error, setError] = useState<string | null>(null);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [receiptOf, setReceiptOf] = useState<Payment | null>(null);
  const [business, setBusiness] = useState<{
    businessName: string;
    businessPhone: string | null;
    businessAddress: string | null;
    currency: string;
    receiptFooter: string | null;
  } | null>(null);

  const load = useCallback(async () => {
    const [r, s] = await Promise.all([
      fetch(`/api/sales/${id}`).then((x) => x.json()),
      fetch(`/api/settings`).then((x) => x.json()),
    ]);
    setData(r);
    setBusiness(s);
    setForm((f) => ({
      ...f,
      amount: r?.sale?.installmentAmount ?? "",
    }));
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  async function pay(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const r = await fetch(`/api/payments`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ...form, saleId: Number(id) }),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      setError(err.error || "Failed");
      return;
    }
    const created = await r.json();
    setShowPay(false);
    await load();
    setReceiptOf(created);
  }

  function removePayment(p: Payment) {
    setConfirmReq({
      message: `Archive payment ${p.receiptNumber}? It will be hidden from this list and can be restored or permanently deleted from the Payments page.`,
      onConfirm: async () => {
        const r = await fetch(`/api/payments/${p.id}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ archived: true }),
        });
        if (r.ok) await load();
      },
    });
  }

  if (!data) {
    return <div className="text-slate-500 text-sm">Loading…</div>;
  }
  const s = data.sale;

  return (
    <div>
      <PageHeader
        title={`Sale #${s.id} · ${s.productName}`}
        description={`Customer: ${s.customerName}`}
        actions={
          <>
            <Link
              href="/sales"
              className="px-4 py-2 rounded-md border border-slate-300 text-sm"
            >
              ← Back
            </Link>
            {s.status === "active" && (
              <button
                onClick={() => {
                  setError(null);
                  setShowPay(true);
                }}
                className="px-4 py-2 rounded-md bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700"
              >
                + Receive Payment
              </button>
            )}
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg border border-slate-200 p-5 lg:col-span-2">
          <h3 className="font-semibold text-slate-800 mb-3">Deal Summary</h3>
          <dl className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
            <Row k="Purchase Price" v={formatCurrency(s.purchasePrice)} />
            <Row k="Profit %" v={`${s.profitPercent}%`} />
            <Row k="Profit Amount" v={formatCurrency(s.profitAmount)} />
            <Row
              k="Final Sale Price"
              v={formatCurrency(s.finalPrice)}
              highlight="text-emerald-700 font-semibold"
            />
            <Row
              k="Down Payment"
              v={
                <span className="flex items-center gap-2">
                  {formatCurrency(s.downPayment)}
                  {parseFloat(s.downPayment) > 0 && (
                    <button
                      onClick={() =>
                        setReceiptOf({
                          id: 0,
                          amount: s.downPayment,
                          paidOn: s.startDate,
                          method: "Advance / Down Payment",
                          receiptNumber: `ADV-${s.id}`,
                          notes: "Advance payment received at time of sale",
                        })
                      }
                      className="text-xs text-blue-600 hover:underline"
                    >
                      Receipt
                    </button>
                  )}
                </span>
              }
            />
            <Row
              k="Total Paid"
              v={formatCurrency(
                data.totals.totalPaid + parseFloat(s.downPayment),
              )}
              highlight="text-blue-700 font-semibold"
            />
            <Row
              k="Remaining"
              v={formatCurrency(data.totals.remaining)}
              highlight="text-rose-700 font-semibold"
            />
            <Row
              k="Plan"
              v={`${s.numInstallments}× ${formatCurrency(s.installmentAmount)} · ${s.frequency}`}
            />
            <Row k="Start Date" v={formatDate(s.startDate)} />
            <Row
              k="Status"
              v={
                <span
                  className={`inline-block px-2 py-0.5 rounded text-xs ${
                    s.status === "active"
                      ? "bg-blue-100 text-blue-700"
                      : "bg-emerald-100 text-emerald-700"
                  }`}
                >
                  {s.status}
                </span>
              }
            />
          </dl>
          {s.notes && (
            <div className="mt-4 p-3 bg-slate-50 rounded text-sm text-slate-600">
              <strong>Notes:</strong> {s.notes}
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-800 mb-3">Customer</h3>
          <div className="text-sm space-y-1">
            <div>
              <strong>{s.customerName}</strong>
            </div>
            {s.customerPhone && <div>📞 {s.customerPhone}</div>}
            {s.customerCnic && <div>CNIC: {s.customerCnic}</div>}
            {s.customerAddress && <div>🏠 {s.customerAddress}</div>}
          </div>

          {(s.guarantorName || s.guarantorPhone) && (
            <div className="mt-4 pt-4 border-t border-slate-200">
              <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">
                Guarantor — for disputes or non-payment
              </h4>
              <div className="text-sm space-y-1">
                {s.guarantorName && <div><strong>{s.guarantorName}</strong></div>}
                {s.guarantorPhone && <div>📞 {s.guarantorPhone}</div>}
                {s.guarantorOccupation && <div>Occupation: {s.guarantorOccupation}</div>}
                {s.guarantorPermanentAddress && (
                  <div>🏠 Permanent: {s.guarantorPermanentAddress}</div>
                )}
                {s.guarantorCurrentAddress && (
                  <div>📍 Current: {s.guarantorCurrentAddress}</div>
                )}
              </div>
            </div>
          )}
          {!s.guarantorName && !s.guarantorPhone && (
            <div className="mt-4 pt-4 border-t border-slate-200 text-xs text-slate-400">
              No guarantor on file for this customer. Add one from the Customers page for extra protection on future sales.
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 mt-6">
        <div className="px-5 py-3 border-b border-slate-200 flex justify-between">
          <h3 className="font-semibold text-slate-800">Payment History</h3>
          <span className="text-xs text-slate-500">
            {data.payments.length} payment(s)
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="text-left px-4 py-2 font-medium">Receipt #</th>
                <th className="text-left px-4 py-2 font-medium">Date</th>
                <th className="text-left px-4 py-2 font-medium">Method</th>
                <th className="text-right px-4 py-2 font-medium">Amount</th>
                <th className="text-right px-4 py-2 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {data.payments.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-slate-500">
                    No payments yet.
                  </td>
                </tr>
              )}
              {data.payments.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50">
                  <td className="px-4 py-2 font-mono text-xs">
                    {p.receiptNumber}
                  </td>
                  <td className="px-4 py-2">{formatDate(p.paidOn)}</td>
                  <td className="px-4 py-2">{p.method}</td>
                  <td className="px-4 py-2 text-right font-medium text-emerald-700">
                    {formatCurrency(p.amount)}
                  </td>
                  <td className="px-4 py-2 text-right space-x-3">
                    <button
                      onClick={() => setReceiptOf(p)}
                      className="text-blue-600 hover:underline text-xs"
                    >
                      Receipt
                    </button>
                    <button
                      onClick={() => removePayment(p)}
                      className="text-amber-600 hover:underline text-xs"
                    >
                      Archive
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showPay && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <form
            onSubmit={pay}
            className="bg-white rounded-lg w-full max-w-md p-6 space-y-3"
          >
            <h2 className="text-lg font-semibold">Receive Payment</h2>
            {error && (
              <div className="p-2 bg-rose-50 text-rose-700 text-sm rounded">
                {error}
              </div>
            )}
            <div className="text-sm text-slate-600 bg-slate-50 rounded p-2">
              Outstanding:{" "}
              <strong className="text-rose-700">
                {formatCurrency(data.totals.remaining)}
              </strong>
            </div>
            <Field label="Amount *">
              <input
                required
                type="number"
                step="0.01"
                min="0"
                className="input"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Date">
                <input
                  type="date"
                  className="input"
                  value={form.paidOn}
                  onChange={(e) =>
                    setForm({ ...form, paidOn: e.target.value })
                  }
                />
              </Field>
              <Field label="Method">
                <select
                  className="input"
                  value={form.method}
                  onChange={(e) =>
                    setForm({ ...form, method: e.target.value })
                  }
                >
                  <option value="cash">Cash</option>
                  <option value="bank">Bank Transfer</option>
                  <option value="cheque">Cheque</option>
                  <option value="mobile">Mobile Wallet</option>
                </select>
              </Field>
            </div>
            <Field label="Notes">
              <input
                className="input"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
            </Field>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowPay(false)}
                className="px-4 py-2 text-sm rounded border border-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm rounded bg-emerald-600 text-white"
              >
                Save Payment
              </button>
            </div>
          </form>
        </div>
      )}

      {receiptOf && business && (
        <ReceiptModal
          payment={receiptOf}
          sale={s}
          business={business}
          onClose={() => setReceiptOf(null)}
        />
      )}

      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}

function Row({
  k,
  v,
  highlight,
}: {
  k: string;
  v: React.ReactNode;
  highlight?: string;
}) {
  return (
    <>
      <dt className="text-slate-500">{k}</dt>
      <dd className={highlight ?? "text-slate-800"}>{v}</dd>
    </>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-xs text-slate-600 font-medium">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

function ReceiptModal({
  payment,
  sale,
  business,
  onClose,
}: {
  payment: Payment;
  sale: SaleDetail["sale"];
  business: {
    businessName: string;
    businessPhone: string | null;
    businessAddress: string | null;
    currency: string;
    receiptFooter: string | null;
  };
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 print:bg-white print:p-0">
      <div className="bg-white rounded-lg w-full max-w-sm p-6 print:shadow-none print:rounded-none print:max-w-none">
        <div id="receipt" className="text-slate-900 text-sm">
          <div className="text-center border-b border-dashed border-slate-400 pb-2 mb-3">
            <div className="text-lg font-bold">{business.businessName}</div>
            {business.businessAddress && (
              <div className="text-xs">{business.businessAddress}</div>
            )}
            {business.businessPhone && (
              <div className="text-xs">☎ {business.businessPhone}</div>
            )}
          </div>
          <div className="text-center font-semibold mb-2">PAYMENT RECEIPT</div>
          <div className="flex justify-between text-xs mb-2">
            <span>Receipt #: {payment.receiptNumber}</span>
            <span>{formatDate(payment.paidOn)}</span>
          </div>
          <div className="border-t border-dashed border-slate-400 pt-2 space-y-1">
            <Row2 k="Customer" v={sale.customerName} />
            <Row2 k="Product" v={sale.productName} />
            <Row2 k="Method" v={payment.method} />
            <Row2
              k="Amount Paid"
              v={formatCurrency(payment.amount, business.currency)}
              bold
            />
          </div>
          <div className="border-t border-dashed border-slate-400 mt-2 pt-2 space-y-1">
            <Row2
              k="Final Price"
              v={formatCurrency(sale.finalPrice, business.currency)}
            />
            <Row2
              k="Remaining Balance"
              v={formatCurrency(sale.remainingBalance, business.currency)}
              bold
            />
          </div>
          {business.receiptFooter && (
            <div className="mt-3 pt-2 border-t border-dashed border-slate-400 text-center text-xs">
              {business.receiptFooter}
            </div>
          )}
          <div className="mt-3 text-center text-[10px] text-slate-500">
            Thank you for your payment.
          </div>
        </div>
        <div className="flex justify-between gap-2 mt-4 print:hidden">
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-sm rounded border border-slate-300"
          >
            Close
          </button>
          <div className="flex gap-2">
            <button
              onClick={() => saveAsPDF(`Receipt-${payment.receiptNumber}.pdf`)}
              className="px-3 py-1.5 text-sm rounded border border-slate-300"
            >
              ⬇ Save as PDF
            </button>
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 text-sm rounded bg-slate-900 text-white"
            >
              🖨 Print
            </button>
          </div>
        </div>
      </div>
      <style jsx global>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #receipt,
          #receipt * {
            visibility: visible;
          }
          #receipt {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            padding: 12px;
          }
        }
      `}</style>
    </div>
  );
}

function Row2({
  k,
  v,
  bold,
}: {
  k: string;
  v: React.ReactNode;
  bold?: boolean;
}) {
  return (
    <div className="flex justify-between text-xs">
      <span className="text-slate-600">{k}</span>
      <span className={bold ? "font-semibold" : ""}>{v}</span>
    </div>
  );
}
