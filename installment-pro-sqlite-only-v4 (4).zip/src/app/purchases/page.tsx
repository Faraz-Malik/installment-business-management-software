"use client";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";
import { Toast } from "@/components/Toast";
import { ArchiveTabs } from "@/components/ArchiveTabs";

type Purchase = {
  id: number;
  supplierId: number;
  supplierName: string | null;
  itemName: string;
  purchasePrice: string;
  purchaseDate: string;
  paymentStatus: string;
  notes: string | null;
  archivedAt: string | null;
};
type Supplier = { id: number; name: string };

export default function PurchasesPage() {
  const [rows, setRows] = useState<Purchase[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [form, setForm] = useState({
    supplierId: "",
    itemName: "",
    purchasePrice: "",
    purchaseDate: new Date().toISOString().slice(0, 10),
    paymentStatus: "paid",
    notes: "",
  });

  const [view, setView] = useState<"active" | "archived">("active");

  async function load() {
    setLoading(true);
    const [p, s] = await Promise.all([
      fetch(`/api/purchases?archived=${view === "archived"}`).then((r) => r.json()),
      fetch("/api/suppliers").then((r) => r.json()),
    ]);
    setRows(p);
    setSuppliers(s);
    setLoading(false);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const r = await fetch("/api/purchases", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(form),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      setError(err.error || "Failed");
      return;
    }
    setShowForm(false);
    setForm({
      supplierId: "",
      itemName: "",
      purchasePrice: "",
      purchaseDate: new Date().toISOString().slice(0, 10),
      paymentStatus: "paid",
      notes: "",
    });
    await load();
  }

  function archive(id: number) {
    setConfirmReq({
      message: "Archive this purchase? It will be hidden from the active list, and can be restored later.",
      onConfirm: async () => {
        const r = await fetch(`/api/purchases/${id}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ archived: true }),
        });
        if (!r.ok) {
          setToast("Failed to archive");
          return;
        }
        await load();
      },
    });
  }

  async function restore(id: number) {
    const r = await fetch(`/api/purchases/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archived: false }),
    });
    if (!r.ok) {
      setToast("Failed to restore");
      return;
    }
    await load();
  }

  function removePermanently(id: number) {
    setConfirmReq({
      message: "Permanently delete this purchase? This cannot be undone.",
      onConfirm: async () => {
        const r = await fetch(`/api/purchases/${id}`, { method: "DELETE" });
        if (!r.ok) {
          const err = await r.json().catch(() => ({}));
          setToast(err.error || "Failed to delete");
          return;
        }
        await load();
      },
    });
  }

  const filtered = rows.filter((r) =>
    [r.itemName, r.supplierName, r.paymentStatus]
      .filter(Boolean)
      .join(" ")
      .toLowerCase()
      .includes(search.toLowerCase()),
  );

  return (
    <div>
      <PageHeader
        title="Purchases"
        description="Items you bought from suppliers."
        actions={
          <button
            onClick={() => {
              setError(null);
              setShowForm(true);
            }}
            className="px-4 py-2 rounded-md bg-slate-900 text-white text-sm font-medium hover:bg-slate-800"
            disabled={suppliers.length === 0}
            title={
              suppliers.length === 0
                ? "Add a supplier first"
                : "New Purchase"
            }
          >
            + New Purchase
          </button>
        }
      />

      {suppliers.length === 0 && (
        <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded text-sm text-amber-800">
          Add at least one supplier before recording a purchase.
        </div>
      )}

      <div className="bg-white rounded-lg border border-slate-200">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <input
            className="w-full max-w-md border border-slate-300 rounded-md px-3 py-2 text-sm"
            placeholder="Search item, supplier, status…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <ArchiveTabs view={view} onChange={setView} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="text-left px-4 py-2 font-medium">Date</th>
                <th className="text-left px-4 py-2 font-medium">Item</th>
                <th className="text-left px-4 py-2 font-medium">Supplier</th>
                <th className="text-right px-4 py-2 font-medium">Amount</th>
                <th className="text-left px-4 py-2 font-medium">Status</th>
                <th className="text-right px-4 py-2 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading && (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-500">
                    Loading…
                  </td>
                </tr>
              )}
              {!loading && filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-500">
                    No purchases recorded.
                  </td>
                </tr>
              )}
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50">
                  <td className="px-4 py-2">{formatDate(p.purchaseDate)}</td>
                  <td className="px-4 py-2 font-medium text-slate-800">
                    {p.itemName}
                  </td>
                  <td className="px-4 py-2">{p.supplierName ?? "-"}</td>
                  <td className="px-4 py-2 text-right font-medium">
                    {formatCurrency(p.purchasePrice)}
                  </td>
                  <td className="px-4 py-2">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-xs ${
                        p.paymentStatus === "paid"
                          ? "bg-emerald-100 text-emerald-700"
                          : p.paymentStatus === "partial"
                            ? "bg-amber-100 text-amber-700"
                            : "bg-rose-100 text-rose-700"
                      }`}
                    >
                      {p.paymentStatus}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-right space-x-2">
                    {view === "active" ? (
                      <button
                        onClick={() => archive(p.id)}
                        className="text-amber-600 hover:underline text-xs"
                      >
                        Archive
                      </button>
                    ) : (
                      <>
                        <button
                          onClick={() => restore(p.id)}
                          className="text-emerald-600 hover:underline text-xs"
                        >
                          Restore
                        </button>
                        <button
                          onClick={() => removePermanently(p.id)}
                          className="text-rose-600 hover:underline text-xs"
                        >
                          Delete Permanently
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <form
            onSubmit={save}
            className="bg-white rounded-lg w-full max-w-lg p-6 space-y-3"
          >
            <h2 className="text-lg font-semibold">New Purchase</h2>
            {error && (
              <div className="p-2 bg-rose-50 text-rose-700 text-sm rounded">
                {error}
              </div>
            )}
            <Field label="Supplier *">
              <select
                required
                className="input"
                value={form.supplierId}
                onChange={(e) =>
                  setForm({ ...form, supplierId: e.target.value })
                }
              >
                <option value="">Select supplier…</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Item Name *">
              <input
                required
                className="input"
                value={form.itemName}
                onChange={(e) =>
                  setForm({ ...form, itemName: e.target.value })
                }
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Purchase Price *">
                <input
                  required
                  type="number"
                  step="0.01"
                  min="0"
                  className="input"
                  value={form.purchasePrice}
                  onChange={(e) =>
                    setForm({ ...form, purchasePrice: e.target.value })
                  }
                />
              </Field>
              <Field label="Purchase Date">
                <input
                  type="date"
                  className="input"
                  value={form.purchaseDate}
                  onChange={(e) =>
                    setForm({ ...form, purchaseDate: e.target.value })
                  }
                />
              </Field>
            </div>
            <Field label="Payment Status">
              <select
                className="input"
                value={form.paymentStatus}
                onChange={(e) =>
                  setForm({ ...form, paymentStatus: e.target.value })
                }
              >
                <option value="paid">Paid</option>
                <option value="partial">Partial</option>
                <option value="unpaid">Unpaid</option>
              </select>
            </Field>
            <Field label="Notes">
              <textarea
                className="input"
                rows={2}
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
            </Field>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2 text-sm rounded border border-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm rounded bg-slate-900 text-white"
              >
                Record Purchase
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />
      <Toast message={toast} onClose={() => setToast(null)} />

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-xs text-slate-600 font-medium">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
