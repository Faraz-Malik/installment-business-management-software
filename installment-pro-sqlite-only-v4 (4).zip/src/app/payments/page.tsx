"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";
import { Toast } from "@/components/Toast";
import { ArchiveTabs } from "@/components/ArchiveTabs";

type Row = {
  id: number;
  saleId: number;
  customerId: number | null;
  customerName: string | null;
  productName: string | null;
  amount: string;
  paidOn: string;
  method: string;
  receiptNumber: string;
  archivedAt: string | null;
};

export default function PaymentsPage() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [view, setView] = useState<"active" | "archived">("active");
  const [expanded, setExpanded] = useState<Set<number | string>>(new Set());

  function load() {
    setLoading(true);
    fetch(`/api/payments?archived=${view === "archived"}`)
      .then((r) => r.json())
      .then((d) => {
        setRows(d);
        setLoading(false);
      });
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  function archive(id: number) {
    setConfirmReq({
      message: "Archive this payment record? It will be hidden from the active list, and can be restored later. This does not affect the sale's balance.",
      onConfirm: async () => {
        const r = await fetch(`/api/payments/${id}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ archived: true }),
        });
        if (!r.ok) {
          setToast("Failed to archive");
          return;
        }
        load();
      },
    });
  }

  async function restore(id: number) {
    const r = await fetch(`/api/payments/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archived: false }),
    });
    if (!r.ok) {
      setToast("Failed to restore");
      return;
    }
    load();
  }

  function removePermanently(id: number) {
    setConfirmReq({
      message: "Permanently delete this payment record? This will recalculate the sale's remaining balance and cannot be undone.",
      onConfirm: async () => {
        const r = await fetch(`/api/payments/${id}`, { method: "DELETE" });
        if (!r.ok) {
          const err = await r.json().catch(() => ({}));
          setToast(err.error || "Failed to delete");
          return;
        }
        load();
      },
    });
  }

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      const q = search.toLowerCase();
      const matchQ =
        !q ||
        [r.customerName, r.productName, r.receiptNumber, r.method]
          .filter(Boolean)
          .join(" ")
          .toLowerCase()
          .includes(q);
      const matchFrom = !from || r.paidOn >= from;
      const matchTo = !to || r.paidOn <= to;
      return matchQ && matchFrom && matchTo;
    });
  }, [rows, search, from, to]);

  const total = filtered.reduce((s, r) => s + parseFloat(r.amount), 0);

  const grouped = useMemo(() => {
    const map = new Map<
      number | string,
      { customerId: number | string; customerName: string; rows: Row[]; total: number }
    >();
    for (const r of filtered) {
      const key = r.customerId ?? r.customerName ?? "unknown";
      if (!map.has(key)) {
        map.set(key, {
          customerId: key,
          customerName: r.customerName ?? "Unknown Customer",
          rows: [],
          total: 0,
        });
      }
      const g = map.get(key)!;
      g.rows.push(r);
      g.total += parseFloat(r.amount);
    }
    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  }, [filtered]);

  function toggle(key: number | string) {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  return (
    <div>
      <PageHeader
        title="Payments"
        description="All customer installment payments received."
      />

      <div className="bg-white rounded-lg border border-slate-200">
        <div className="p-4 border-b border-slate-200 flex flex-wrap gap-3 items-center">
          <input
            className="flex-1 min-w-[220px] max-w-md border border-slate-300 rounded-md px-3 py-2 text-sm"
            placeholder="Search customer, product, receipt…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <label className="text-xs text-slate-500 flex items-center gap-2">
            From
            <input
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="border border-slate-300 rounded-md px-2 py-1 text-sm"
            />
          </label>
          <label className="text-xs text-slate-500 flex items-center gap-2">
            To
            <input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="border border-slate-300 rounded-md px-2 py-1 text-sm"
            />
          </label>
          <ArchiveTabs view={view} onChange={setView} />
          <div className="ml-auto text-sm">
            <span className="text-slate-500">Total: </span>
            <strong className="text-emerald-700">
              {formatCurrency(total)}
            </strong>
          </div>
        </div>
        <div className="divide-y divide-slate-200">
          {loading && (
            <div className="p-6 text-center text-slate-500 text-sm">Loading…</div>
          )}
          {!loading && grouped.length === 0 && (
            <div className="p-6 text-center text-slate-500 text-sm">
              No payments match your filters.
            </div>
          )}
          {grouped.map((g) => {
            const isOpen = expanded.has(g.customerId);
            return (
              <div key={g.customerId}>
                <button
                  onClick={() => toggle(g.customerId)}
                  className="w-full flex items-center justify-between px-4 py-3 hover:bg-slate-50 text-left"
                >
                  <div className="flex items-center gap-2">
                    <span className={`text-slate-400 transition-transform ${isOpen ? "rotate-90" : ""}`}>
                      ▶
                    </span>
                    <span className="font-medium text-sm">{g.customerName}</span>
                    <span className="text-xs text-slate-400">
                      ({g.rows.length} payment{g.rows.length === 1 ? "" : "s"})
                    </span>
                  </div>
                  <span className="text-sm font-medium text-emerald-700">
                    {formatCurrency(g.total)}
                  </span>
                </button>
                {isOpen && (
                  <div className="overflow-x-auto bg-slate-50/60">
                    <table className="w-full text-sm">
                      <thead className="text-slate-500 text-xs">
                        <tr>
                          <th className="text-left px-4 py-2 font-medium">Receipt #</th>
                          <th className="text-left px-4 py-2 font-medium">Date</th>
                          <th className="text-left px-4 py-2 font-medium">Product</th>
                          <th className="text-left px-4 py-2 font-medium">Method</th>
                          <th className="text-right px-4 py-2 font-medium">Amount</th>
                          <th className="text-right px-4 py-2 font-medium">Sale</th>
                          <th className="text-right px-4 py-2 font-medium">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {g.rows.map((p) => (
                          <tr key={p.id} className="hover:bg-slate-100/60">
                            <td className="px-4 py-2 font-mono text-xs">{p.receiptNumber}</td>
                            <td className="px-4 py-2">{formatDate(p.paidOn)}</td>
                            <td className="px-4 py-2">{p.productName ?? "-"}</td>
                            <td className="px-4 py-2">{p.method}</td>
                            <td className="px-4 py-2 text-right font-medium text-emerald-700">
                              {formatCurrency(p.amount)}
                            </td>
                            <td className="px-4 py-2 text-right">
                              <Link href={`/sales/${p.saleId}`} className="text-blue-600 text-xs hover:underline">
                                Open sale →
                              </Link>
                            </td>
                            <td className="px-4 py-2 text-right space-x-2">
                              {view === "active" ? (
                                <button onClick={() => archive(p.id)} className="text-amber-600 hover:underline text-xs">
                                  Archive
                                </button>
                              ) : (
                                <>
                                  <button onClick={() => restore(p.id)} className="text-emerald-600 hover:underline text-xs">
                                    Restore
                                  </button>
                                  <button onClick={() => removePermanently(p.id)} className="text-rose-600 hover:underline text-xs">
                                    Delete Permanently
                                  </button>
                                </>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />
      <Toast message={toast} onClose={() => setToast(null)} />
    </div>
  );
}
