"use client";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";
import { ArchiveTabs } from "@/components/ArchiveTabs";

type Expense = {
  id: number;
  title: string;
  amount: string;
  category: string | null;
  spentOn: string;
  notes: string | null;
  archivedAt: string | null;
};

export default function ExpensesPage() {
  const [rows, setRows] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [form, setForm] = useState({
    title: "",
    amount: "",
    category: "",
    spentOn: new Date().toISOString().slice(0, 10),
    notes: "",
  });

  const [view, setView] = useState<"active" | "archived">("active");

  async function load() {
    setLoading(true);
    const r = await fetch(`/api/expenses?archived=${view === "archived"}`);
    setRows(await r.json());
    setLoading(false);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const r = await fetch("/api/expenses", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(form),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      setError(err.error || "Failed");
      return;
    }
    setShowForm(false);
    setForm({
      title: "",
      amount: "",
      category: "",
      spentOn: new Date().toISOString().slice(0, 10),
      notes: "",
    });
    await load();
  }

  function archive(id: number) {
    setConfirmReq({
      message: "Archive this expense? It will be hidden from the active list, and can be restored later.",
      onConfirm: async () => {
        await fetch(`/api/expenses?id=${id}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ archived: true }),
        });
        await load();
      },
    });
  }

  async function restore(id: number) {
    await fetch(`/api/expenses?id=${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archived: false }),
    });
    await load();
  }

  function removePermanently(id: number) {
    setConfirmReq({
      message: "Permanently delete this expense? This cannot be undone.",
      onConfirm: async () => {
        await fetch(`/api/expenses?id=${id}`, { method: "DELETE" });
        await load();
      },
    });
  }

  const total = rows.reduce((s, r) => s + parseFloat(r.amount), 0);

  return (
    <div>
      <PageHeader
        title="Expenses"
        description="Track your operating expenses."
        actions={
          <button
            onClick={() => setShowForm(true)}
            className="px-4 py-2 rounded-md bg-slate-900 text-white text-sm font-medium hover:bg-slate-800"
          >
            + New Expense
          </button>
        }
      />

      <div className="bg-white rounded-lg border border-slate-200">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between text-sm gap-4">
          <div className="text-slate-500">{rows.length} record(s)</div>
          <ArchiveTabs view={view} onChange={setView} />
          <div>
            <span className="text-slate-500">Total: </span>
            <strong className="text-orange-700">
              {formatCurrency(total)}
            </strong>
          </div>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600">
            <tr>
              <th className="text-left px-4 py-2 font-medium">Date</th>
              <th className="text-left px-4 py-2 font-medium">Title</th>
              <th className="text-left px-4 py-2 font-medium">Category</th>
              <th className="text-right px-4 py-2 font-medium">Amount</th>
              <th className="text-right px-4 py-2 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-slate-500">
                  Loading…
                </td>
              </tr>
            )}
            {!loading && rows.length === 0 && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-slate-500">
                  No expenses recorded.
                </td>
              </tr>
            )}
            {rows.map((r) => (
              <tr key={r.id} className="hover:bg-slate-50">
                <td className="px-4 py-2">{formatDate(r.spentOn)}</td>
                <td className="px-4 py-2 font-medium">{r.title}</td>
                <td className="px-4 py-2 text-slate-600">
                  {r.category ?? "-"}
                </td>
                <td className="px-4 py-2 text-right font-medium text-orange-700">
                  {formatCurrency(r.amount)}
                </td>
                <td className="px-4 py-2 text-right space-x-2">
                  {view === "active" ? (
                    <button
                      onClick={() => archive(r.id)}
                      className="text-amber-600 text-xs hover:underline"
                    >
                      Archive
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={() => restore(r.id)}
                        className="text-emerald-600 text-xs hover:underline"
                      >
                        Restore
                      </button>
                      <button
                        onClick={() => removePermanently(r.id)}
                        className="text-rose-600 text-xs hover:underline"
                      >
                        Delete Permanently
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <form
            onSubmit={save}
            className="bg-white rounded-lg w-full max-w-md p-6 space-y-3"
          >
            <h2 className="text-lg font-semibold">New Expense</h2>
            {error && (
              <div className="p-2 bg-rose-50 text-rose-700 text-sm rounded">
                {error}
              </div>
            )}
            <Field label="Title *">
              <input
                required
                className="input"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Amount *">
                <input
                  required
                  type="number"
                  step="0.01"
                  min="0"
                  className="input"
                  value={form.amount}
                  onChange={(e) =>
                    setForm({ ...form, amount: e.target.value })
                  }
                />
              </Field>
              <Field label="Date">
                <input
                  type="date"
                  className="input"
                  value={form.spentOn}
                  onChange={(e) =>
                    setForm({ ...form, spentOn: e.target.value })
                  }
                />
              </Field>
            </div>
            <Field label="Category">
              <input
                className="input"
                placeholder="e.g. Rent, Utilities, Salary"
                value={form.category}
                onChange={(e) =>
                  setForm({ ...form, category: e.target.value })
                }
              />
            </Field>
            <Field label="Notes">
              <input
                className="input"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
            </Field>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2 text-sm rounded border border-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm rounded bg-slate-900 text-white"
              >
                Save Expense
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-xs text-slate-600 font-medium">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
