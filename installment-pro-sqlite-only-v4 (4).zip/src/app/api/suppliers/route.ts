import { NextResponse } from "next/server";
import { db } from "@/db";
import { suppliers } from "@/db/schema";
import { desc, isNull, isNotNull } from "drizzle-orm";

export async function GET(req: Request) {
  const showArchived = new URL(req.url).searchParams.get("archived") === "true";
  const rows = await db
    .select()
    .from(suppliers)
    .where(showArchived ? isNotNull(suppliers.archivedAt) : isNull(suppliers.archivedAt))
    .orderBy(desc(suppliers.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  if (!body.name || typeof body.name !== "string") {
    return NextResponse.json({ error: "Name is required" }, { status: 400 });
  }
  const [row] = await db
    .insert(suppliers)
    .values({
      name: body.name.trim(),
      phone: body.phone || null,
      address: body.address || null,
      cnic: body.cnic || null,
      notes: body.notes || null,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
