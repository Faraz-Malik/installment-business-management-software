import { NextResponse } from "next/server";
import { db } from "@/db";
import { suppliers } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .update(suppliers)
    .set({
      name: body.name,
      phone: body.phone || null,
      address: body.address || null,
      cnic: body.cnic || null,
      notes: body.notes || null,
    })
    .where(eq(suppliers.id, Number(id)))
    .returning();
  return NextResponse.json(row);
}

// Archive (soft-delete) or restore. Body: { archived: true | false }
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .update(suppliers)
    .set({ archivedAt: body.archived ? sql`CURRENT_TIMESTAMP` : null })
    .where(eq(suppliers.id, Number(id)))
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const [existing] = await db
    .select({ archivedAt: suppliers.archivedAt })
    .from(suppliers)
    .where(eq(suppliers.id, Number(id)));
  if (!existing) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (!existing.archivedAt) {
    return NextResponse.json(
      { error: "Archive this supplier before permanently deleting it." },
      { status: 400 },
    );
  }
  try {
    await db.delete(suppliers).where(eq(suppliers.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json(
      { error: "Supplier has related purchases and cannot be deleted." },
      { status: 400 },
    );
  }
}
