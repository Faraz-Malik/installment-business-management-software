import { NextResponse } from "next/server";
import { db } from "@/db";
import { investors } from "@/db/schema";
import { desc, isNull, isNotNull } from "drizzle-orm";

export async function GET(req: Request) {
  const showArchived = new URL(req.url).searchParams.get("archived") === "true";
  const rows = await db
    .select()
    .from(investors)
    .where(showArchived ? isNotNull(investors.archivedAt) : isNull(investors.archivedAt))
    .orderBy(desc(investors.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  if (!body.name || typeof body.name !== "string") {
    return NextResponse.json({ error: "Name is required" }, { status: 400 });
  }
  const [row] = await db
    .insert(investors)
    .values({
      name: body.name.trim(),
      cnic: body.cnic || null,
      phone: body.phone || null,
      address: body.address || null,
      notes: body.notes || null,
      status: body.status || "active",
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
