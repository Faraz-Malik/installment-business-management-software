import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  investors,
  investments,
  investmentAgreements,
  investmentTransactions,
} from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { computeInvestmentBalance } from "@/lib/investment";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const investorId = Number(id);

  const [investor] = await db.select().from(investors).where(eq(investors.id, investorId));
  if (!investor) {
    return NextResponse.json({ error: "Investor not found" }, { status: 404 });
  }

  const investmentRows = await db
    .select({
      id: investments.id,
      amount: investments.amount,
      startDate: investments.startDate,
      status: investments.status,
      notes: investments.notes,
      archivedAt: investments.archivedAt,
      agreementId: investmentAgreements.id,
      agreementType: investmentAgreements.type,
      fixedMonthlyAmount: investmentAgreements.fixedMonthlyAmount,
      percentageRate: investmentAgreements.percentageRate,
      paymentFrequency: investmentAgreements.paymentFrequency,
      reinvestmentMode: investmentAgreements.reinvestmentMode,
      lossPolicy: investmentAgreements.lossPolicy,
      agreementStatus: investmentAgreements.status,
    })
    .from(investments)
    .leftJoin(investmentAgreements, eq(investments.agreementId, investmentAgreements.id))
    .where(eq(investments.investorId, investorId));

  const withBalances = await Promise.all(
    investmentRows.map(async (inv: (typeof investmentRows)[number]) => {
      const txRows = await db
        .select({ type: investmentTransactions.type, amount: investmentTransactions.amount })
        .from(investmentTransactions)
        .where(eq(investmentTransactions.investmentId, inv.id));
      const balance = computeInvestmentBalance(
        txRows.map((t: { type: string; amount: number }) => ({
          type: t.type as never,
          amount: t.amount,
        })),
      );
      return { ...inv, balance };
    }),
  );

  const totals = withBalances.reduce(
    (acc, inv) => ({
      principal: acc.principal + inv.balance.principal,
      totalReturnsPaid: acc.totalReturnsPaid + inv.balance.totalReturnsPaid,
    }),
    { principal: 0, totalReturnsPaid: 0 },
  );

  return NextResponse.json({ investor, investments: withBalances, totals });
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .update(investors)
    .set({ archivedAt: body.archived ? sql`CURRENT_TIMESTAMP` : null })
    .where(eq(investors.id, Number(id)))
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const [existing] = await db
    .select({ archivedAt: investors.archivedAt })
    .from(investors)
    .where(eq(investors.id, Number(id)));
  if (!existing) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (!existing.archivedAt) {
    return NextResponse.json(
      { error: "Archive this investor before permanently deleting them." },
      { status: 400 },
    );
  }
  try {
    await db.delete(investors).where(eq(investors.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json(
      { error: "Investor has investments on record and cannot be deleted." },
      { status: 400 },
    );
  }
}
