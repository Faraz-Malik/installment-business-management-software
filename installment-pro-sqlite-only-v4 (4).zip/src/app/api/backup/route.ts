import { NextResponse } from "next/server";
import { pool, db } from "@/db";
import {
  suppliers,
  customers,
  purchases,
  installmentSales,
  payments,
  expenses,
} from "@/db/schema";
import fs from "fs";
import crypto from "crypto";
import path from "path";
import { BACKUP_FORMAT_VERSION, APP_VERSION } from "@/lib/backup-format";
// eslint-disable-next-line @typescript-eslint/no-require-imports
const AdmZip = require("adm-zip");

// ============================================================
// BACKUP (Task 6 — replaces the old plain-JSON export)
// ============================================================
// A plain JSON export doesn't preserve column types precisely and
// can be hand-edited by a user into an inconsistent state before
// restoring, without any way for the app to detect that. Packaging
// the actual SQLite database file instead is authoritative — it's
// byte-for-byte what the app itself uses, so there's no re-encoding
// step that could lose or corrupt anything, and a checksum lets
// restore detect a corrupted/tampered file before touching live
// data.
// ============================================================

export async function GET() {
  const sqlite = pool.sqlite;

  // Ensure everything is flushed from the WAL into the main db file
  // before we copy it — otherwise a backup taken mid-session could
  // miss recent writes that are still sitting in the -wal file.
  sqlite.pragma("wal_checkpoint(TRUNCATE)");

  const dbPath: string =
    process.env.DB_PATH || path.join(/*turbopackIgnore: true*/ process.cwd(), "installment-pro.db");
  const dbBuffer = fs.readFileSync(dbPath);
  const checksum = crypto.createHash("sha256").update(dbBuffer).digest("hex");

  const [supCount, custCount, purCount, saleCount, payCount, expCount] =
    await Promise.all([
      db.select().from(suppliers),
      db.select().from(customers),
      db.select().from(purchases),
      db.select().from(installmentSales),
      db.select().from(payments),
      db.select().from(expenses),
    ]);

  const metadata = {
    backupFormatVersion: BACKUP_FORMAT_VERSION,
    appVersion: APP_VERSION,
    createdAt: new Date().toISOString(),
    checksum,
    recordCounts: {
      suppliers: supCount.length,
      customers: custCount.length,
      purchases: purCount.length,
      installment_sales: saleCount.length,
      payments: payCount.length,
      expenses: expCount.length,
    },
  };

  const zip = new AdmZip();
  zip.addFile("installment-pro.db", dbBuffer);
  zip.addFile(
    "metadata.json",
    Buffer.from(JSON.stringify(metadata, null, 2)),
  );
  const zipBuffer = zip.toBuffer();

  const stamp = new Date().toISOString().slice(0, 10);
  return new NextResponse(zipBuffer, {
    headers: {
      "content-type": "application/zip",
      "content-disposition": `attachment; filename="InstallmentPro-Backup-${stamp}.zip"`,
    },
  });
}
