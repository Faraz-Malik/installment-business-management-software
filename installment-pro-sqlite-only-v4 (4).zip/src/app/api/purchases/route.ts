import { NextResponse } from "next/server";
import { db } from "@/db";
import { purchases, suppliers } from "@/db/schema";
import { desc, eq, isNull, isNotNull } from "drizzle-orm";

export async function GET(req: Request) {
  const showArchived = new URL(req.url).searchParams.get("archived") === "true";
  const rows = await db
    .select({
      id: purchases.id,
      supplierId: purchases.supplierId,
      supplierName: suppliers.name,
      itemName: purchases.itemName,
      purchasePrice: purchases.purchasePrice,
      purchaseDate: purchases.purchaseDate,
      paymentStatus: purchases.paymentStatus,
      notes: purchases.notes,
      createdAt: purchases.createdAt,
    })
    .from(purchases)
    .leftJoin(suppliers, eq(purchases.supplierId, suppliers.id))
    .where(showArchived ? isNotNull(purchases.archivedAt) : isNull(purchases.archivedAt))
    .orderBy(desc(purchases.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  if (!body.supplierId || !body.itemName || !body.purchasePrice) {
    return NextResponse.json(
      { error: "supplierId, itemName, purchasePrice are required" },
      { status: 400 },
    );
  }
  const [row] = await db
    .insert(purchases)
    .values({
      supplierId: Number(body.supplierId),
      itemName: String(body.itemName).trim(),
      purchasePrice: String(body.purchasePrice),
      purchaseDate: body.purchaseDate || new Date().toISOString().slice(0, 10),
      paymentStatus: body.paymentStatus || "paid",
      notes: body.notes || null,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
