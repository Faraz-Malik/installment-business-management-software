import { NextResponse } from "next/server";
import { db } from "@/db";
import { purchases } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

// Archive (soft-delete) or restore. Body: { archived: true | false }
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .update(purchases)
    .set({ archivedAt: body.archived ? sql`CURRENT_TIMESTAMP` : null })
    .where(eq(purchases.id, Number(id)))
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const [existing] = await db
    .select({ archivedAt: purchases.archivedAt })
    .from(purchases)
    .where(eq(purchases.id, Number(id)));
  if (!existing) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (!existing.archivedAt) {
    return NextResponse.json(
      { error: "Archive this purchase before permanently deleting it." },
      { status: 400 },
    );
  }
  try {
    await db.delete(purchases).where(eq(purchases.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json(
      { error: "Purchase is linked to a sale and cannot be deleted." },
      { status: 400 },
    );
  }
}
