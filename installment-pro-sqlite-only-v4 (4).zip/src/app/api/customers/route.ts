import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { desc, isNull, isNotNull } from "drizzle-orm";

export async function GET(req: Request) {
  const showArchived = new URL(req.url).searchParams.get("archived") === "true";
  const rows = await db
    .select()
    .from(customers)
    .where(showArchived ? isNotNull(customers.archivedAt) : isNull(customers.archivedAt))
    .orderBy(desc(customers.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  if (!body.name || typeof body.name !== "string") {
    return NextResponse.json({ error: "Name is required" }, { status: 400 });
  }
  const [row] = await db
    .insert(customers)
    .values({
      name: body.name.trim(),
      cnic: body.cnic || null,
      phone: body.phone || null,
      address: body.address || null,
      guarantorName: body.guarantorName || null,
      guarantorPhone: body.guarantorPhone || null,
      guarantorPermanentAddress: body.guarantorPermanentAddress || null,
      guarantorCurrentAddress: body.guarantorCurrentAddress || null,
      guarantorOccupation: body.guarantorOccupation || null,
      notes: body.notes || null,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
