import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .update(customers)
    .set({
      name: body.name,
      cnic: body.cnic || null,
      phone: body.phone || null,
      address: body.address || null,
      guarantorName: body.guarantorName || null,
      guarantorPhone: body.guarantorPhone || null,
      guarantorPermanentAddress: body.guarantorPermanentAddress || null,
      guarantorCurrentAddress: body.guarantorCurrentAddress || null,
      guarantorOccupation: body.guarantorOccupation || null,
      notes: body.notes || null,
    })
    .where(eq(customers.id, Number(id)))
    .returning();
  return NextResponse.json(row);
}

// Archive (soft-delete) or restore. Body: { archived: true | false }
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .update(customers)
    .set({ archivedAt: body.archived ? sql`CURRENT_TIMESTAMP` : null })
    .where(eq(customers.id, Number(id)))
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const [existing] = await db
    .select({ archivedAt: customers.archivedAt })
    .from(customers)
    .where(eq(customers.id, Number(id)));
  if (!existing) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (!existing.archivedAt) {
    return NextResponse.json(
      { error: "Archive this customer before permanently deleting it." },
      { status: 400 },
    );
  }
  try {
    await db.delete(customers).where(eq(customers.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json(
      { error: "Customer has active sales and cannot be deleted." },
      { status: 400 },
    );
  }
}
