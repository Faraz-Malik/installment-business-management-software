import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  investments,
  investmentAgreements,
  investmentTransactions,
  investors,
} from "@/db/schema";
import { desc, eq, isNull, isNotNull } from "drizzle-orm";

const VALID_TYPES = ["fixed_monthly", "percentage_monthly", "profit_sharing", "hybrid", "manual"];
const VALID_FREQ = ["monthly", "quarterly", "six_monthly", "yearly", "custom"];
const VALID_REINVEST = ["full", "partial", "none"];
const VALID_LOSS = ["none", "capital_ratio", "manual", "carry_forward", "custom"];

export async function GET(req: Request) {
  const showArchived = new URL(req.url).searchParams.get("archived") === "true";
  const rows = await db
    .select({
      id: investments.id,
      investorId: investments.investorId,
      investorName: investors.name,
      amount: investments.amount,
      startDate: investments.startDate,
      status: investments.status,
      agreementType: investmentAgreements.type,
      paymentFrequency: investmentAgreements.paymentFrequency,
      archivedAt: investments.archivedAt,
    })
    .from(investments)
    .leftJoin(investors, eq(investments.investorId, investors.id))
    .leftJoin(investmentAgreements, eq(investments.agreementId, investmentAgreements.id))
    .where(showArchived ? isNotNull(investments.archivedAt) : isNull(investments.archivedAt))
    .orderBy(desc(investments.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const investorId = Number(body.investorId);
  const amount = Number(body.amount);
  const startDate = body.startDate || new Date().toISOString().slice(0, 10);
  const agreement = body.agreement || {};

  if (!investorId || !Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Investor and amount are required." }, { status: 400 });
  }
  if (!VALID_TYPES.includes(agreement.type)) {
    return NextResponse.json({ error: "Invalid agreement type." }, { status: 400 });
  }
  const paymentFrequency = VALID_FREQ.includes(agreement.paymentFrequency)
    ? agreement.paymentFrequency
    : "monthly";
  const reinvestmentMode = VALID_REINVEST.includes(agreement.reinvestmentMode)
    ? agreement.reinvestmentMode
    : "none";
  const lossPolicy = VALID_LOSS.includes(agreement.lossPolicy) ? agreement.lossPolicy : "none";

  const [agreementRow] = await db
    .insert(investmentAgreements)
    .values({
      investorId,
      type: agreement.type,
      fixedMonthlyAmount: agreement.fixedMonthlyAmount ?? null,
      percentageRate: agreement.percentageRate ?? null,
      paymentFrequency,
      reinvestmentMode,
      partialReinvestPercent: agreement.partialReinvestPercent ?? null,
      lossPolicy,
      notes: agreement.notes || null,
    })
    .returning();

  const [investmentRow] = await db
    .insert(investments)
    .values({
      investorId,
      agreementId: agreementRow.id,
      amount,
      startDate,
      notes: body.notes || null,
    })
    .returning();

  await db.insert(investmentTransactions).values({
    investmentId: investmentRow.id,
    type: "contribution",
    amount,
    date: startDate,
    notes: "Initial investment",
  });

  return NextResponse.json(
    { ...investmentRow, agreement: agreementRow },
    { status: 201 },
  );
}
