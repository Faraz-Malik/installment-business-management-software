import { NextResponse } from "next/server";
import { db } from "@/db";
import { investments, investmentTransactions } from "@/db/schema";
import { eq } from "drizzle-orm";

const VALID_TYPES = ["return_payment", "reinvestment", "withdrawal", "settlement_adjustment"];

// Note on the "admin-only" requirement (Improvement 3, Security):
// this app currently has a single administrator account model (see
// the login system) with no multi-user role system built — so
// "logged in" already means "admin" today. If additional non-admin
// user accounts are ever added, this is the endpoint that would
// need a role check added.
export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const investmentId = Number(id);
  const body = await req.json();

  const type = body.type;
  const amount = Number(body.amount);
  const date = body.date || new Date().toISOString().slice(0, 10);

  if (!VALID_TYPES.includes(type)) {
    return NextResponse.json({ error: "Invalid transaction type." }, { status: 400 });
  }
  if (!Number.isFinite(amount) || amount === 0) {
    return NextResponse.json({ error: "A non-zero amount is required." }, { status: 400 });
  }
  // Only settlement_adjustment may be negative (a recorded loss);
  // everything else is a real cash movement and must be positive.
  if (type !== "settlement_adjustment" && amount < 0) {
    return NextResponse.json(
      { error: "This transaction type must be a positive amount." },
      { status: 400 },
    );
  }

  const [investment] = await db.select().from(investments).where(eq(investments.id, investmentId));
  if (!investment) {
    return NextResponse.json({ error: "Investment not found" }, { status: 404 });
  }

  const [row] = await db
    .insert(investmentTransactions)
    .values({
      investmentId,
      type,
      amount,
      date,
      notes: body.notes || null,
    })
    .returning();

  return NextResponse.json(row, { status: 201 });
}
