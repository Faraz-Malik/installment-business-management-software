import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  investments,
  investmentAgreements,
  investmentTransactions,
  investors,
} from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { computeInvestmentBalance, suggestReturnAmount } from "@/lib/investment";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const investmentId = Number(id);

  const [investment] = await db
    .select({
      id: investments.id,
      investorId: investments.investorId,
      investorName: investors.name,
      amount: investments.amount,
      startDate: investments.startDate,
      status: investments.status,
      notes: investments.notes,
      archivedAt: investments.archivedAt,
      agreementId: investmentAgreements.id,
      agreementType: investmentAgreements.type,
      fixedMonthlyAmount: investmentAgreements.fixedMonthlyAmount,
      percentageRate: investmentAgreements.percentageRate,
      paymentFrequency: investmentAgreements.paymentFrequency,
      reinvestmentMode: investmentAgreements.reinvestmentMode,
      partialReinvestPercent: investmentAgreements.partialReinvestPercent,
      lossPolicy: investmentAgreements.lossPolicy,
      agreementStatus: investmentAgreements.status,
      agreementNotes: investmentAgreements.notes,
    })
    .from(investments)
    .leftJoin(investmentAgreements, eq(investments.agreementId, investmentAgreements.id))
    .leftJoin(investors, eq(investments.investorId, investors.id))
    .where(eq(investments.id, investmentId));

  if (!investment) {
    return NextResponse.json({ error: "Investment not found" }, { status: 404 });
  }

  const txRows = await db
    .select()
    .from(investmentTransactions)
    .where(eq(investmentTransactions.investmentId, investmentId))
    .orderBy(desc(investmentTransactions.date), desc(investmentTransactions.id));

  const balance = computeInvestmentBalance(
    txRows.map((t: { type: string; amount: number }) => ({
      type: t.type as never,
      amount: t.amount,
    })),
  );

  const suggestedReturn = suggestReturnAmount(
    { type: investment.agreementType || "manual", fixedMonthlyAmount: investment.fixedMonthlyAmount, percentageRate: investment.percentageRate },
    balance.principal,
  );

  return NextResponse.json({
    investment,
    transactions: txRows,
    balance,
    suggestedReturn,
  });
}

// Archive / restore
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .update(investments)
    .set({ archivedAt: body.archived ? sql`CURRENT_TIMESTAMP` : null })
    .where(eq(investments.id, Number(id)))
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const [existing] = await db
    .select({ archivedAt: investments.archivedAt })
    .from(investments)
    .where(eq(investments.id, Number(id)));
  if (!existing) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (!existing.archivedAt) {
    return NextResponse.json(
      { error: "Archive this investment before permanently deleting it." },
      { status: 400 },
    );
  }
  await db.delete(investments).where(eq(investments.id, Number(id)));
  return NextResponse.json({ ok: true });
}
