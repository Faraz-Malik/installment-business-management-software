import { NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

async function getOrCreate() {
  const existing = await db.select().from(settings).limit(1);
  if (existing.length > 0) return existing[0];
  const [row] = await db
    .insert(settings)
    .values({ businessName: "My Business", currency: "PKR" })
    .returning();
  return row;
}

export async function GET() {
  const row = await getOrCreate();
  return NextResponse.json(row);
}

export async function PUT(req: Request) {
  const current = await getOrCreate();
  const body = await req.json();
  const [row] = await db
    .update(settings)
    .set({
      businessName: body.businessName || current.businessName,
      businessPhone: body.businessPhone ?? current.businessPhone,
      businessAddress: body.businessAddress ?? current.businessAddress,
      currency: body.currency || current.currency,
      taxPercent: body.taxPercent ?? current.taxPercent,
      receiptFooter: body.receiptFooter ?? current.receiptFooter,
      profitCalculationMode:
        body.profitCalculationMode || current.profitCalculationMode,
    })
    .where(eq(settings.id, current.id))
    .returning();
  return NextResponse.json(row);
}
