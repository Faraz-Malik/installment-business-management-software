import { NextResponse } from "next/server";
import { closeConnection } from "@/db";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { BACKUP_FORMAT_VERSION } from "@/lib/backup-format";
// eslint-disable-next-line @typescript-eslint/no-require-imports
const AdmZip = require("adm-zip");

// ============================================================
// RESTORE (Task 6)
// ============================================================
// Validates the uploaded backup ZIP before touching anything:
//   1. Is it a well-formed zip containing the expected files?
//   2. Does the db file's checksum match what metadata claims?
//   3. Is the backup format version one this app understands?
// Only if all three pass does it proceed — and even then, it
// copies the CURRENT database to a restore-point file first, so a
// bad restore is itself recoverable.
// ============================================================

export async function POST(req: Request) {
  const arrayBuffer = await req.arrayBuffer();
  const zipBuffer = Buffer.from(arrayBuffer);

  let zip;
  try {
    zip = new AdmZip(zipBuffer);
  } catch {
    return NextResponse.json(
      { error: "This doesn't look like a valid backup file (not a zip)." },
      { status: 400 },
    );
  }

  const dbEntry = zip.getEntry("installment-pro.db");
  const metaEntry = zip.getEntry("metadata.json");
  if (!dbEntry || !metaEntry) {
    return NextResponse.json(
      { error: "Backup file is missing expected contents." },
      { status: 400 },
    );
  }

  let metadata: {
    backupFormatVersion: number;
    checksum: string;
    createdAt: string;
  };
  let dbBuffer: Buffer;
  try {
    metadata = JSON.parse(metaEntry.getData().toString("utf8"));
    dbBuffer = dbEntry.getData();
  } catch {
    return NextResponse.json(
      {
        error:
          "Backup file is corrupted and could not be read. Restore aborted, nothing was changed.",
      },
      { status: 400 },
    );
  }

  if (
    typeof metadata.backupFormatVersion !== "number" ||
    metadata.backupFormatVersion > BACKUP_FORMAT_VERSION
  ) {
    return NextResponse.json(
      {
        error:
          "This backup was made with a newer, incompatible version of the app.",
      },
      { status: 400 },
    );
  }

  const actualChecksum = crypto
    .createHash("sha256")
    .update(dbBuffer)
    .digest("hex");
  if (actualChecksum !== metadata.checksum) {
    return NextResponse.json(
      {
        error:
          "Backup integrity check failed — the file may be corrupted or was modified. Restore aborted, nothing was changed.",
      },
      { status: 400 },
    );
  }

  const dbPath: string =
    process.env.DB_PATH || path.join(/*turbopackIgnore: true*/ process.cwd(), "installment-pro.db");
  const dbDir = path.dirname(dbPath);

  // Automatic restore point: copy the CURRENT (pre-restore) database
  // before touching anything, so this restore itself is undoable.
  let restorePointPath: string | null = null;
  try {
    const restorePointsDir = path.join(dbDir, "restore-points");
    if (!fs.existsSync(restorePointsDir)) {
      fs.mkdirSync(restorePointsDir, { recursive: true });
    }
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    restorePointPath = path.join(
      restorePointsDir,
      `pre-restore-${stamp}.db`,
    );
    if (fs.existsSync(dbPath)) {
      fs.copyFileSync(dbPath, restorePointPath);
    }
  } catch (e) {
    return NextResponse.json(
      {
        error:
          "Could not create a safety restore point, so the restore was not attempted: " +
          (e as Error).message,
      },
      { status: 500 },
    );
  }

  try {
    // Release better-sqlite3's file handle before overwriting the
    // file — required on Windows, which won't allow replacing a
    // file that's still open the way POSIX systems do.
    closeConnection();

    // Remove any stale WAL/SHM files from the database being
    // replaced — they belong to the old file and would otherwise
    // be (incorrectly) applied against the restored one.
    for (const suffix of ["-wal", "-shm"]) {
      const p = dbPath + suffix;
      if (fs.existsSync(p)) fs.unlinkSync(p);
    }

    fs.writeFileSync(dbPath, dbBuffer);
  } catch (e) {
    return NextResponse.json(
      {
        error:
          "Restore failed while writing the new database: " +
          (e as Error).message +
          (restorePointPath
            ? `. Your previous data is safe at ${restorePointPath}.`
            : ""),
      },
      { status: 500 },
    );
  }

  return NextResponse.json({ ok: true, restorePoint: restorePointPath });
}
