import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  customers,
  installmentSales,
  payments,
  settings,
} from "@/db/schema";
import { eq, sql } from "drizzle-orm";

type Transaction = {
  date: string;
  type: "sale" | "payment";
  description: string;
  debit: number; // increases balance owed
  credit: number; // decreases balance owed
};

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const customerId = searchParams.get("customerId");
  const from = searchParams.get("from");
  const to = searchParams.get("to");

  if (!from || !to) {
    return NextResponse.json(
      { error: "from and to date are required" },
      { status: 400 },
    );
  }

  const [business] = await db.select().from(settings).limit(1);

  let customer: { id: number; name: string; phone: string | null; cnic: string | null } | null =
    null;
  if (customerId) {
    const rows = await db
      .select({
        id: customers.id,
        name: customers.name,
        phone: customers.phone,
        cnic: customers.cnic,
      })
      .from(customers)
      .where(eq(customers.id, Number(customerId)));
    customer = rows[0] ?? null;
    if (!customer) {
      return NextResponse.json({ error: "Customer not found" }, { status: 404 });
    }
  }

  // Sales (debits — increase what the customer owes) and payments
  // (credits — decrease it), scoped to this customer if one was
  // selected, otherwise business-wide.
  const salesWhere = customerId
    ? eq(installmentSales.customerId, Number(customerId))
    : undefined;
  const allSales = await db
    .select({
      id: installmentSales.id,
      customerId: installmentSales.customerId,
      customerName: customers.name,
      productName: installmentSales.productName,
      finalPrice: installmentSales.finalPrice,
      downPayment: installmentSales.downPayment,
      startDate: installmentSales.startDate,
    })
    .from(installmentSales)
    .leftJoin(customers, eq(installmentSales.customerId, customers.id))
    .where(salesWhere);

  const saleIds = allSales.map((s: { id: number }) => s.id);
  const allPayments = saleIds.length
    ? await db
        .select({
          saleId: payments.saleId,
          amount: payments.amount,
          paidOn: payments.paidOn,
          receiptNumber: payments.receiptNumber,
        })
        .from(payments)
        .where(
          sql`${payments.saleId} IN (${sql.join(saleIds, sql`, `)})`,
        )
    : [];

  // Opening balance: net effect of everything strictly before `from`.
  let openingBalance = 0;
  for (const s of allSales) {
    if (s.startDate < from) {
      openingBalance += parseFloat(s.finalPrice) - parseFloat(s.downPayment);
    }
  }
  for (const p of allPayments) {
    if (p.paidOn < from) {
      openingBalance -= parseFloat(p.amount);
    }
  }

  // Transactions within [from, to].
  const transactions: Transaction[] = [];
  for (const s of allSales) {
    if (s.startDate >= from && s.startDate <= to) {
      const debit = parseFloat(s.finalPrice) - parseFloat(s.downPayment);
      transactions.push({
        date: s.startDate,
        type: "sale",
        description: `New installment sale — ${s.productName}${
          !customerId ? ` (${s.customerName ?? "—"})` : ""
        }${parseFloat(s.downPayment) > 0 ? `, down payment recorded separately` : ""}`,
        debit,
        credit: 0,
      });
    }
  }
  for (const p of allPayments) {
    if (p.paidOn >= from && p.paidOn <= to) {
      transactions.push({
        date: p.paidOn,
        type: "payment",
        description: `Payment received — receipt ${p.receiptNumber}`,
        debit: 0,
        credit: parseFloat(p.amount),
      });
    }
  }
  transactions.sort((a, b) => a.date.localeCompare(b.date));

  const totalDebits = transactions.reduce((s, t) => s + t.debit, 0);
  const totalCredits = transactions.reduce((s, t) => s + t.credit, 0);
  const closingBalance = openingBalance + totalDebits - totalCredits;

  return NextResponse.json({
    business,
    customer,
    period: { from, to },
    openingBalance,
    transactions,
    totalDebits,
    totalCredits,
    closingBalance,
    generatedAt: new Date().toISOString(),
  });
}
