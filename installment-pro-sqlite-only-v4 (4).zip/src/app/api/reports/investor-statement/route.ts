import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  investors,
  investments,
  investmentAgreements,
  investmentTransactions,
  settings,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import { computeInvestmentBalance } from "@/lib/investment";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const investorId = Number(searchParams.get("investorId"));
  const from = searchParams.get("from");
  const to = searchParams.get("to");
  // Optional: "all" | "return_payment" | "reinvestment" | "withdrawal" |
  // "settlement_adjustment" — lets one report double as a Payment
  // Statement, Reinvestment Statement, or Settlement Statement.
  const typeFilter = searchParams.get("type") || "all";

  if (!investorId || !from || !to) {
    return NextResponse.json(
      { error: "investorId, from, and to are required" },
      { status: 400 },
    );
  }

  const [business] = await db.select().from(settings).limit(1);
  const [investor] = await db.select().from(investors).where(eq(investors.id, investorId));
  if (!investor) {
    return NextResponse.json({ error: "Investor not found" }, { status: 404 });
  }

  const investmentRows = await db
    .select({
      id: investments.id,
      amount: investments.amount,
      startDate: investments.startDate,
      agreementType: investmentAgreements.type,
    })
    .from(investments)
    .leftJoin(investmentAgreements, eq(investments.agreementId, investmentAgreements.id))
    .where(eq(investments.investorId, investorId));

  const investmentIds = investmentRows.map((i: (typeof investmentRows)[number]) => i.id);
  let allTx: {
    investmentId: number;
    type: string;
    amount: number;
    date: string;
    notes: string | null;
  }[] = [];
  if (investmentIds.length) {
    const rows = await db.select().from(investmentTransactions);
    allTx = rows.filter((t: (typeof rows)[number]) => investmentIds.includes(t.investmentId));
  }

  const inRange = allTx.filter((t) => t.date >= from && t.date <= to);
  const filtered = typeFilter === "all" ? inRange : inRange.filter((t) => t.type === typeFilter);
  filtered.sort((a, b) => a.date.localeCompare(b.date));

  const balancesByInvestment = investmentRows.map((inv: (typeof investmentRows)[number]) => {
    const txForThis = allTx.filter((t) => t.investmentId === inv.id);
    const balance = computeInvestmentBalance(
      txForThis.map((t) => ({ type: t.type as never, amount: t.amount })),
    );
    return { ...inv, balance };
  });

  const totalsInit = { principal: 0, totalReturnsPaid: 0, totalReinvested: 0, totalWithdrawn: 0 };
  const totals = balancesByInvestment.reduce(
    (acc: typeof totalsInit, inv: (typeof balancesByInvestment)[number]) => ({
      principal: acc.principal + inv.balance.principal,
      totalReturnsPaid: acc.totalReturnsPaid + inv.balance.totalReturnsPaid,
      totalReinvested: acc.totalReinvested + inv.balance.totalReinvested,
      totalWithdrawn: acc.totalWithdrawn + inv.balance.totalWithdrawn,
    }),
    totalsInit,
  );

  return NextResponse.json({
    business,
    investor,
    period: { from, to },
    typeFilter,
    investments: balancesByInvestment,
    transactions: filtered,
    totals,
    generatedAt: new Date().toISOString(),
  });
}
