import { NextResponse } from "next/server";
import { db } from "@/db";
import { investmentAgreements } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

// Closing an agreement is the "Annual Settlement" close action — an
// explicit, owner-initiated step. Nothing closes an agreement
// automatically anywhere else in this app.
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json();

  const updates: Record<string, unknown> = {};
  if (body.status === "closed") {
    updates.status = "closed";
    updates.closedAt = sql`CURRENT_TIMESTAMP`;
  } else if (body.status === "active") {
    updates.status = "active";
    updates.closedAt = null;
  }
  if (typeof body.notes === "string") {
    updates.notes = body.notes;
  }

  if (Object.keys(updates).length === 0) {
    return NextResponse.json({ error: "Nothing to update" }, { status: 400 });
  }

  const [row] = await db
    .update(investmentAgreements)
    .set(updates)
    .where(eq(investmentAgreements.id, Number(id)))
    .returning();
  return NextResponse.json(row);
}
