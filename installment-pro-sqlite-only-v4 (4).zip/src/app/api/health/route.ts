import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    // .execute() is a node-postgres-driver-only method; the
    // better-sqlite3 driver this app actually uses exposes
    // .get()/.all()/.run() for raw sql instead.
    db.get(sql`select 1`);
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
