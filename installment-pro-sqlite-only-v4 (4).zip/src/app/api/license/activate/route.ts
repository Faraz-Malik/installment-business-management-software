import { NextResponse } from "next/server";
import { getDeviceId, verifyLicenseKey, saveActivation } from "@/lib/license";

export async function POST(req: Request) {
  let body: { key?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  const key = (body.key || "").trim();
  if (!key) {
    return NextResponse.json(
      { error: "Please enter an activation key." },
      { status: 400 },
    );
  }

  const deviceId = getDeviceId();
  if (!verifyLicenseKey(deviceId, key)) {
    return NextResponse.json(
      { error: "This key does not match this device. Please check it and try again." },
      { status: 401 },
    );
  }

  saveActivation(deviceId, key);
  return NextResponse.json({ ok: true });
}
