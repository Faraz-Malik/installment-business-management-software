import { NextResponse } from "next/server";
import { getDeviceId, isActivated } from "@/lib/license";

export async function GET() {
  return NextResponse.json({
    activated: isActivated(),
    deviceId: getDeviceId(),
  });
}
