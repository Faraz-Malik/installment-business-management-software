import { NextResponse } from "next/server";
import { db } from "@/db";
import { expenses } from "@/db/schema";
import { desc, eq, isNull, isNotNull, sql } from "drizzle-orm";

export async function GET(req: Request) {
  const showArchived = new URL(req.url).searchParams.get("archived") === "true";
  const rows = await db
    .select()
    .from(expenses)
    .where(showArchived ? isNotNull(expenses.archivedAt) : isNull(expenses.archivedAt))
    .orderBy(desc(expenses.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  if (!body.title || !body.amount) {
    return NextResponse.json(
      { error: "Title and amount are required." },
      { status: 400 },
    );
  }
  const [row] = await db
    .insert(expenses)
    .values({
      title: String(body.title).trim(),
      amount: String(body.amount),
      category: body.category || null,
      spentOn: body.spentOn || new Date().toISOString().slice(0, 10),
      notes: body.notes || null,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}

// Archive (soft-delete) or restore. Body: { archived: true | false }, id via query param.
export async function PATCH(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const body = await req.json();
  const [row] = await db
    .update(expenses)
    .set({ archivedAt: body.archived ? sql`CURRENT_TIMESTAMP` : null })
    .where(eq(expenses.id, id))
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const [existing] = await db
    .select({ archivedAt: expenses.archivedAt })
    .from(expenses)
    .where(eq(expenses.id, id));
  if (!existing) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (!existing.archivedAt) {
    return NextResponse.json(
      { error: "Archive this expense before permanently deleting it." },
      { status: 400 },
    );
  }
  await db.delete(expenses).where(eq(expenses.id, id));
  return NextResponse.json({ ok: true });
}
