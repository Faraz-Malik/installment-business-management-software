import { NextResponse } from "next/server";
import { db } from "@/db";
import { leads, customers, installmentSales } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { calculatePricing, type ProfitCalculationMode } from "@/lib/pricing";

// Converts a saved quotation into a real customer + real installment
// sale. The lead's saved numbers are only the STARTING point — every
// field can be reviewed and overridden right here, exactly like the
// New Sale form, so nothing has to be re-typed but nothing is locked
// in either.
export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json().catch(() => ({}));

  const [lead] = await db.select().from(leads).where(eq(leads.id, Number(id)));
  if (!lead) {
    return NextResponse.json({ error: "Lead not found" }, { status: 404 });
  }
  if (lead.convertedToSaleId) {
    return NextResponse.json(
      { error: "This lead has already been converted to a sale." },
      { status: 400 },
    );
  }

  let customerId = body.customerId ? Number(body.customerId) : null;
  if (!customerId) {
    const name = body.name || lead.name;
    if (!name) {
      return NextResponse.json(
        { error: "A customer name is required — pick an existing customer or enter a name." },
        { status: 400 },
      );
    }
    const [newCustomer] = await db
      .insert(customers)
      .values({
        name,
        phone: body.phone || lead.phone,
        cnic: body.cnic || lead.cnic,
        address: body.address || lead.address,
        guarantorName: body.guarantorName || lead.guarantorName,
        guarantorPhone: body.guarantorPhone || lead.guarantorPhone,
        guarantorPermanentAddress:
          body.guarantorPermanentAddress || lead.guarantorPermanentAddress,
        guarantorCurrentAddress:
          body.guarantorCurrentAddress || lead.guarantorCurrentAddress,
        guarantorOccupation: body.guarantorOccupation || lead.guarantorOccupation,
      })
      .returning();
    customerId = newCustomer.id;
  }

  // Same optional Linked Purchase the New Sale form has.
  const purchaseId = body.purchaseId
    ? Number(body.purchaseId)
    : body.purchaseId === null
      ? null
      : (lead.purchaseId ?? null);

  const productName = body.productName || lead.productName || "Item";
  const purchasePrice = body.purchasePrice != null ? Number(body.purchasePrice) : lead.purchasePrice;
  const profitPercent = body.profitPercent != null ? Number(body.profitPercent) : lead.profitPercent;
  const downPayment = body.downPayment != null ? Number(body.downPayment) : lead.downPayment;
  const discount = body.discount != null ? Number(body.discount) : lead.discount;
  const numInstallments = body.numInstallments != null ? Number(body.numInstallments) : lead.numInstallments;
  const frequency = body.frequency || lead.frequency;
  const startDate = body.startDate || new Date().toISOString().slice(0, 10);
  const notes = body.notes !== undefined ? body.notes : lead.notes;
  const mode = (body.profitCalculationMode ||
    lead.profitCalculationMode) as ProfitCalculationMode;

  const { profitAmount, finalPrice, remainingBalance, installmentAmount } =
    calculatePricing({ purchasePrice, profitPercent, downPayment, numInstallments, mode });
  // Manual discount (if any) comes straight off the final price.
  const discountedFinal = +(finalPrice - discount).toFixed(2);
  const discountedRemaining = +(remainingBalance - discount).toFixed(2);
  const discountedInstallment =
    numInstallments > 0 ? +(discountedRemaining / numInstallments).toFixed(2) : 0;

  if (discountedRemaining < 0) {
    return NextResponse.json(
      { error: "Down payment plus discount cannot exceed the final sale price." },
      { status: 400 },
    );
  }

  const [sale] = await db
    .insert(installmentSales)
    .values({
      customerId,
      purchaseId,
      productName,
      purchasePrice: String(purchasePrice),
      profitPercent: String(profitPercent),
      profitAmount: String(profitAmount),
      finalPrice: String(discountedFinal),
      downPayment: String(downPayment),
      remainingBalance: String(discountedRemaining),
      numInstallments,
      installmentAmount: String(discountedInstallment),
      frequency,
      startDate,
      status: discountedRemaining <= 0 ? "completed" : "active",
      notes,
    })
    .returning();

  await db
    .update(leads)
    .set({ convertedToSaleId: sale.id, archivedAt: sql`CURRENT_TIMESTAMP` })
    .where(eq(leads.id, lead.id));

  return NextResponse.json({ ok: true, saleId: sale.id, customerId });
}
