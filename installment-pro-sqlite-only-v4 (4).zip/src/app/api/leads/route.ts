import { NextResponse } from "next/server";
import { db } from "@/db";
import { leads } from "@/db/schema";
import { desc, isNull, isNotNull } from "drizzle-orm";
import { calculatePricing, type ProfitCalculationMode } from "@/lib/pricing";

export async function GET(req: Request) {
  const showArchived = new URL(req.url).searchParams.get("archived") === "true";
  const rows = await db
    .select()
    .from(leads)
    .where(showArchived ? isNotNull(leads.archivedAt) : isNull(leads.archivedAt))
    .orderBy(desc(leads.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const purchasePrice = Number(body.purchasePrice);
  const profitPercent = Number(body.profitPercent);
  const downPayment = Number(body.downPayment || 0);
  const discount = Number(body.discount || 0);
  const numInstallments = Number(body.numInstallments);
  const mode = (body.profitCalculationMode || "full_price") as ProfitCalculationMode;

  if (
    !Number.isFinite(purchasePrice) ||
    purchasePrice <= 0 ||
    !Number.isFinite(profitPercent) ||
    profitPercent < 0 ||
    !Number.isInteger(numInstallments) ||
    numInstallments <= 0
  ) {
    return NextResponse.json({ error: "Invalid quotation input." }, { status: 400 });
  }

  // Validate it (same engine the real sale uses) before saving, so a
  // saved lead is always a coherent quotation.
  calculatePricing({ purchasePrice, profitPercent, downPayment, numInstallments, mode });

  const [row] = await db
    .insert(leads)
    .values({
      name: body.name || null,
      phone: body.phone || null,
      cnic: body.cnic || null,
      address: body.address || null,
      guarantorName: body.guarantorName || null,
      guarantorPhone: body.guarantorPhone || null,
      guarantorPermanentAddress: body.guarantorPermanentAddress || null,
      guarantorCurrentAddress: body.guarantorCurrentAddress || null,
      guarantorOccupation: body.guarantorOccupation || null,
      productName: body.productName || null,
      notes: body.notes || null,
      purchasePrice,
      profitPercent,
      downPayment,
      discount,
      numInstallments,
      frequency: body.frequency || "monthly",
      profitCalculationMode: mode,
      purchaseId: body.purchaseId ? Number(body.purchaseId) : null,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
