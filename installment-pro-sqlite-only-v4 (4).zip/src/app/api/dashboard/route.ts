import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  customers,
  suppliers,
  installmentSales,
  payments,
  purchases,
  expenses,
} from "@/db/schema";
import { sql, eq, and, lt } from "drizzle-orm";

export async function GET() {
  const [{ customerCount }] = await db
    .select({ customerCount: sql<number>`COUNT(*)` })
    .from(customers);
  const [{ supplierCount }] = await db
    .select({ supplierCount: sql<number>`COUNT(*)` })
    .from(suppliers);

  const [{ totalInvestment }] = await db
    .select({
      totalInvestment: sql<string>`COALESCE(SUM(${purchases.purchasePrice}), 0)`,
    })
    .from(purchases);

  const [{ totalExpectedProfit }] = await db
    .select({
      totalExpectedProfit: sql<string>`COALESCE(SUM(${installmentSales.profitAmount}), 0)`,
    })
    .from(installmentSales);

  const [{ totalFinalPrice }] = await db
    .select({
      totalFinalPrice: sql<string>`COALESCE(SUM(${installmentSales.finalPrice}), 0)`,
    })
    .from(installmentSales);

  const [{ totalDown }] = await db
    .select({
      totalDown: sql<string>`COALESCE(SUM(${installmentSales.downPayment}), 0)`,
    })
    .from(installmentSales);

  const [{ receivedPayments }] = await db
    .select({
      receivedPayments: sql<string>`COALESCE(SUM(${payments.amount}), 0)`,
    })
    .from(payments);

  const pending =
    parseFloat(totalFinalPrice) -
    parseFloat(totalDown) -
    parseFloat(receivedPayments);

  const [{ totalExpenses }] = await db
    .select({
      totalExpenses: sql<string>`COALESCE(SUM(${expenses.amount}), 0)`,
    })
    .from(expenses);

  // Overdue: active sales whose start date + numInstallments * frequency has passed
  // Simplified: count active sales with remaining > 0 and startDate older than N months of installments have elapsed based on paid count.
  const activeSales = await db
    .select({
      id: installmentSales.id,
      startDate: installmentSales.startDate,
      numInstallments: installmentSales.numInstallments,
      installmentAmount: installmentSales.installmentAmount,
      frequency: installmentSales.frequency,
      remaining: installmentSales.remainingBalance,
      totalPaid:
        sql<string>`COALESCE((SELECT SUM(${payments.amount}) FROM ${payments} WHERE ${payments.saleId} = ${installmentSales.id}), 0)`.as(
          "total_paid",
        ),
    })
    .from(installmentSales)
    .where(eq(installmentSales.status, "active"));

  const now = new Date();
  let overdueCount = 0;
  for (const s of activeSales) {
    const start = new Date(s.startDate);
    const monthsElapsed =
      (now.getFullYear() - start.getFullYear()) * 12 +
      (now.getMonth() - start.getMonth());
    const periodsElapsed =
      s.frequency === "weekly"
        ? Math.floor((now.getTime() - start.getTime()) / (7 * 86400000))
        : monthsElapsed;
    const shouldBePaid = Math.min(
      periodsElapsed * parseFloat(s.installmentAmount),
      parseFloat(s.installmentAmount) * s.numInstallments,
    );
    const actuallyPaid = parseFloat(s.totalPaid);
    if (actuallyPaid + 0.01 < shouldBePaid) overdueCount++;
  }

  // Monthly collection: this calendar month
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1)
    .toISOString()
    .slice(0, 10);
  const [{ monthlyCollection }] = await db
    .select({
      monthlyCollection: sql<string>`COALESCE(SUM(${payments.amount}), 0)`,
    })
    .from(payments)
    .where(and(sql`${payments.paidOn} >= ${monthStart}`, lt(payments.paidOn, sql`date('now', '+1 day')`)));

  return NextResponse.json({
    customerCount,
    supplierCount,
    totalInvestment: parseFloat(totalInvestment),
    totalExpectedProfit: parseFloat(totalExpectedProfit),
    receivedPayments: parseFloat(receivedPayments) + parseFloat(totalDown),
    pendingPayments: Math.max(0, pending),
    overdueCount,
    monthlyCollection: parseFloat(monthlyCollection),
    totalExpenses: parseFloat(totalExpenses),
  });
}
