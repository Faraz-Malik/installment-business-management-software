import { NextResponse } from "next/server";
import { db } from "@/db";
import { payments, installmentSales, customers } from "@/db/schema";
import { desc, eq, sql, isNull, isNotNull } from "drizzle-orm";

export async function GET(req: Request) {
  const showArchived = new URL(req.url).searchParams.get("archived") === "true";
  const rows = await db
    .select({
      id: payments.id,
      saleId: payments.saleId,
      customerId: installmentSales.customerId,
      customerName: customers.name,
      productName: installmentSales.productName,
      amount: payments.amount,
      paidOn: payments.paidOn,
      method: payments.method,
      receiptNumber: payments.receiptNumber,
      notes: payments.notes,
      createdAt: payments.createdAt,
    })
    .from(payments)
    .leftJoin(installmentSales, eq(payments.saleId, installmentSales.id))
    .leftJoin(customers, eq(installmentSales.customerId, customers.id))
    .where(showArchived ? isNotNull(payments.archivedAt) : isNull(payments.archivedAt))
    .orderBy(desc(payments.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const saleId = Number(body.saleId);
  const amount = Number(body.amount);
  const paidOn = body.paidOn || new Date().toISOString().slice(0, 10);
  const method = body.method || "cash";
  const notes = body.notes || null;

  if (!saleId || !Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json(
      { error: "Sale and positive amount are required." },
      { status: 400 },
    );
  }

  const [sale] = await db
    .select()
    .from(installmentSales)
    .where(eq(installmentSales.id, saleId));

  if (!sale) {
    return NextResponse.json({ error: "Sale not found." }, { status: 404 });
  }

  const [{ totalPaid }] = await db
    .select({
      totalPaid: sql<string>`COALESCE(SUM(${payments.amount}), 0)`,
    })
    .from(payments)
    .where(eq(payments.saleId, saleId));

  const alreadyPaid = parseFloat(totalPaid);
  const finalPrice = parseFloat(sale.finalPrice);
  const downPayment = parseFloat(sale.downPayment);
  const outstanding = finalPrice - downPayment - alreadyPaid;

  if (amount > outstanding + 0.01) {
    return NextResponse.json(
      {
        error: `Amount exceeds outstanding balance (${outstanding.toFixed(2)}).`,
      },
      { status: 400 },
    );
  }

  const receiptNumber = `RCP-${Date.now().toString().slice(-8)}-${saleId}`;

  const [row] = await db
    .insert(payments)
    .values({
      saleId,
      amount: String(amount),
      paidOn,
      method,
      receiptNumber,
      notes,
    })
    .returning();

  const newRemaining = +(outstanding - amount).toFixed(2);
  await db
    .update(installmentSales)
    .set({
      remainingBalance: String(Math.max(0, newRemaining)),
      status: newRemaining <= 0.009 ? "completed" : "active",
    })
    .where(eq(installmentSales.id, saleId));

  return NextResponse.json(row, { status: 201 });
}
