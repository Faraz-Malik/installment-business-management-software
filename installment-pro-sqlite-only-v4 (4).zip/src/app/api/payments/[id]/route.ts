import { NextResponse } from "next/server";
import { db } from "@/db";
import { payments, installmentSales } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

// Archive (soft-delete) or restore. Body: { archived: true | false }
// Deliberately does NOT touch the sale's balance/status — archiving
// only hides the payment from the active list, it doesn't reverse
// the payment. Only a permanent DELETE recomputes the balance.
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .update(payments)
    .set({ archivedAt: body.archived ? sql`CURRENT_TIMESTAMP` : null })
    .where(eq(payments.id, Number(id)))
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const paymentId = Number(id);

  const [payment] = await db
    .select()
    .from(payments)
    .where(eq(payments.id, paymentId));
  if (!payment) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (!payment.archivedAt) {
    return NextResponse.json(
      { error: "Archive this payment before permanently deleting it." },
      { status: 400 },
    );
  }

  await db.delete(payments).where(eq(payments.id, paymentId));

  // recompute sale remaining
  const [sale] = await db
    .select()
    .from(installmentSales)
    .where(eq(installmentSales.id, payment.saleId));
  if (sale) {
    const [{ totalPaid }] = await db
      .select({
        totalPaid: sql<string>`COALESCE(SUM(${payments.amount}), 0)`,
      })
      .from(payments)
      .where(eq(payments.saleId, payment.saleId));
    const remaining =
      parseFloat(sale.finalPrice) -
      parseFloat(sale.downPayment) -
      parseFloat(totalPaid);
    await db
      .update(installmentSales)
      .set({
        remainingBalance: String(Math.max(0, remaining)),
        status: remaining <= 0.009 ? "completed" : "active",
      })
      .where(eq(installmentSales.id, payment.saleId));
  }

  return NextResponse.json({ ok: true });
}
