import { NextResponse } from "next/server";
import { db } from "@/db";
import { ownerCapital } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  const rows = await db.select().from(ownerCapital).orderBy(desc(ownerCapital.date));
  const current = rows.reduce((sum: number, r: (typeof rows)[number]) => {
    if (r.type === "withdrawal") return sum - r.amount;
    return sum + r.amount;
  }, 0);
  return NextResponse.json({ entries: rows, currentCapital: +current.toFixed(2) });
}

export async function POST(req: Request) {
  const body = await req.json();
  const type = body.type;
  const amount = Number(body.amount);
  if (!["initial", "additional", "withdrawal"].includes(type) || !Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Invalid entry." }, { status: 400 });
  }
  const [row] = await db
    .insert(ownerCapital)
    .values({
      type,
      amount,
      date: body.date || new Date().toISOString().slice(0, 10),
      notes: body.notes || null,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
