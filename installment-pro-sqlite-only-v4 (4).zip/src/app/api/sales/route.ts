import { NextResponse } from "next/server";
import { db } from "@/db";
import { installmentSales, customers, payments, settings } from "@/db/schema";
import { desc, eq, sql, isNull, isNotNull } from "drizzle-orm";
import { calculatePricing, type ProfitCalculationMode } from "@/lib/pricing";

export async function GET(req: Request) {
  const showArchived = new URL(req.url).searchParams.get("archived") === "true";
  const rows = await db
    .select({
      id: installmentSales.id,
      customerId: installmentSales.customerId,
      customerName: customers.name,
      productName: installmentSales.productName,
      purchasePrice: installmentSales.purchasePrice,
      profitPercent: installmentSales.profitPercent,
      profitAmount: installmentSales.profitAmount,
      finalPrice: installmentSales.finalPrice,
      downPayment: installmentSales.downPayment,
      remainingBalance: installmentSales.remainingBalance,
      numInstallments: installmentSales.numInstallments,
      installmentAmount: installmentSales.installmentAmount,
      frequency: installmentSales.frequency,
      startDate: installmentSales.startDate,
      status: installmentSales.status,
      createdAt: installmentSales.createdAt,
      totalPaid:
        sql<string>`COALESCE((SELECT SUM(${payments.amount}) FROM ${payments} WHERE ${payments.saleId} = ${installmentSales.id}), 0)`.as(
          "total_paid",
        ),
    })
    .from(installmentSales)
    .leftJoin(customers, eq(installmentSales.customerId, customers.id))
    .where(
      showArchived
        ? isNotNull(installmentSales.archivedAt)
        : isNull(installmentSales.archivedAt),
    )
    .orderBy(desc(installmentSales.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const customerId = Number(body.customerId);
  const productName = String(body.productName || "").trim();
  const purchasePrice = Number(body.purchasePrice);
  const profitPercent = Number(body.profitPercent);
  const downPayment = Number(body.downPayment || 0);
  const numInstallments = Number(body.numInstallments);
  const frequency = body.frequency || "monthly";
  const startDate = body.startDate || new Date().toISOString().slice(0, 10);
  const purchaseId = body.purchaseId ? Number(body.purchaseId) : null;
  const notes = body.notes || null;

  if (
    !customerId ||
    !productName ||
    !Number.isFinite(purchasePrice) ||
    purchasePrice <= 0 ||
    !Number.isFinite(profitPercent) ||
    profitPercent < 0 ||
    !Number.isInteger(numInstallments) ||
    numInstallments <= 0
  ) {
    return NextResponse.json(
      { error: "Invalid input for installment sale." },
      { status: 400 },
    );
  }

  const VALID_MODES = ["full_price", "remaining_balance"];
  const [businessSettings] = await db.select().from(settings).limit(1);
  const mode = (
    VALID_MODES.includes(body.profitCalculationMode)
      ? body.profitCalculationMode
      : businessSettings?.profitCalculationMode || "full_price"
  ) as ProfitCalculationMode;

  const { profitAmount, finalPrice, remainingBalance, installmentAmount } =
    calculatePricing({
      purchasePrice,
      profitPercent,
      downPayment,
      numInstallments,
      mode,
    });
  const remaining = remainingBalance;
  if (remaining < 0) {
    return NextResponse.json(
      { error: "Down payment cannot exceed final sale price." },
      { status: 400 },
    );
  }

  const [row] = await db
    .insert(installmentSales)
    .values({
      customerId,
      purchaseId,
      productName,
      purchasePrice: String(purchasePrice),
      profitPercent: String(profitPercent),
      profitAmount: String(profitAmount),
      finalPrice: String(finalPrice),
      downPayment: String(downPayment),
      remainingBalance: String(remaining),
      numInstallments,
      installmentAmount: String(installmentAmount),
      frequency,
      startDate,
      status: remaining === 0 ? "completed" : "active",
      notes,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
