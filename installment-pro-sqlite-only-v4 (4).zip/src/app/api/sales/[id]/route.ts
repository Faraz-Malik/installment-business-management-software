import { NextResponse } from "next/server";
import { db } from "@/db";
import { installmentSales, customers, payments } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const saleId = Number(id);
  const [sale] = await db
    .select({
      id: installmentSales.id,
      customerId: installmentSales.customerId,
      customerName: customers.name,
      customerPhone: customers.phone,
      customerCnic: customers.cnic,
      customerAddress: customers.address,
      guarantorName: customers.guarantorName,
      guarantorPhone: customers.guarantorPhone,
      guarantorPermanentAddress: customers.guarantorPermanentAddress,
      guarantorCurrentAddress: customers.guarantorCurrentAddress,
      guarantorOccupation: customers.guarantorOccupation,
      productName: installmentSales.productName,
      purchasePrice: installmentSales.purchasePrice,
      profitPercent: installmentSales.profitPercent,
      profitAmount: installmentSales.profitAmount,
      finalPrice: installmentSales.finalPrice,
      downPayment: installmentSales.downPayment,
      remainingBalance: installmentSales.remainingBalance,
      numInstallments: installmentSales.numInstallments,
      installmentAmount: installmentSales.installmentAmount,
      frequency: installmentSales.frequency,
      startDate: installmentSales.startDate,
      status: installmentSales.status,
      notes: installmentSales.notes,
      createdAt: installmentSales.createdAt,
    })
    .from(installmentSales)
    .leftJoin(customers, eq(installmentSales.customerId, customers.id))
    .where(eq(installmentSales.id, saleId));

  if (!sale) {
    return NextResponse.json({ error: "Sale not found" }, { status: 404 });
  }

  const paymentRows = await db
    .select()
    .from(payments)
    .where(eq(payments.saleId, saleId))
    .orderBy(desc(payments.paidOn));

  // Totals are computed from ALL payments (archiving a payment doesn't
  // reverse it financially — see payments/[id]/route.ts PATCH). Only the
  // displayed list is filtered to active (non-archived) payments.
  const totalPaid = paymentRows.reduce(
    (sum: number, p: { amount: string | number }) =>
      sum + parseFloat(String(p.amount)),
    0,
  );
  const remaining = parseFloat(sale.finalPrice) - parseFloat(sale.downPayment) - totalPaid;
  const visiblePayments = paymentRows.filter(
    (p: { archivedAt: string | null }) => !p.archivedAt,
  );

  return NextResponse.json({
    sale,
    payments: visiblePayments,
    totals: {
      totalPaid,
      remaining: Math.max(0, remaining),
    },
  });
}

// Archive (soft-delete) or restore. Body: { archived: true | false }
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .update(installmentSales)
    .set({ archivedAt: body.archived ? sql`CURRENT_TIMESTAMP` : null })
    .where(eq(installmentSales.id, Number(id)))
    .returning();
  return NextResponse.json(row);
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const [existing] = await db
    .select({ archivedAt: installmentSales.archivedAt })
    .from(installmentSales)
    .where(eq(installmentSales.id, Number(id)));
  if (!existing) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (!existing.archivedAt) {
    return NextResponse.json(
      { error: "Archive this installment sale before permanently deleting it." },
      { status: 400 },
    );
  }
  await db.delete(installmentSales).where(eq(installmentSales.id, Number(id)));
  return NextResponse.json({ ok: true });
}
