import { NextResponse } from "next/server";
import { db } from "@/db";
import { agreementTemplates } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const rows = await db.select().from(agreementTemplates).orderBy(desc(agreementTemplates.id));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  if (!body.name || !body.type) {
    return NextResponse.json({ error: "Name and type are required" }, { status: 400 });
  }
  const [row] = await db
    .insert(agreementTemplates)
    .values({
      name: body.name.trim(),
      type: body.type,
      fixedMonthlyAmount: body.fixedMonthlyAmount ?? null,
      percentageRate: body.percentageRate ?? null,
      paymentFrequency: body.paymentFrequency || "monthly",
      reinvestmentMode: body.reinvestmentMode || "none",
      partialReinvestPercent: body.partialReinvestPercent ?? null,
      lossPolicy: body.lossPolicy || "none",
      notes: body.notes || null,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.delete(agreementTemplates).where(eq(agreementTemplates.id, id));
  return NextResponse.json({ ok: true });
}
