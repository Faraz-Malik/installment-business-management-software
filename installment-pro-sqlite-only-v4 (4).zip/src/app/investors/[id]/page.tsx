"use client";
import { Fragment, use, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { Toast } from "@/components/Toast";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";

type InvestmentRow = {
  id: number;
  amount: number;
  startDate: string;
  status: string;
  agreementType: string | null;
  paymentFrequency: string | null;
  reinvestmentMode: string | null;
  lossPolicy: string | null;
  agreementStatus: string | null;
  balance: { principal: number; totalReturnsPaid: number; totalReinvested: number; totalWithdrawn: number };
};

type Data = {
  investor: { id: number; name: string; phone: string | null; cnic: string | null; address: string | null; notes: string | null; archivedAt: string | null };
  investments: InvestmentRow[];
  totals: { principal: number; totalReturnsPaid: number };
};

const COMMON_TYPES = [
  { value: "fixed_monthly", label: "Fixed Monthly Return", hint: "A set amount every period, e.g. Rs. 15,000/month" },
  { value: "percentage_monthly", label: "Percentage Return", hint: "A % of their balance, e.g. 3%/month" },
];
const MORE_TYPES = [
  { value: "profit_sharing", label: "Profit Sharing" },
  { value: "hybrid", label: "Hybrid Agreement" },
  { value: "manual", label: "Manual Agreement" },
];
const AGREEMENT_TYPES = [...COMMON_TYPES, ...MORE_TYPES];
const FREQUENCIES = ["monthly", "quarterly", "six_monthly", "yearly", "custom"];
const REINVEST_MODES = ["none", "partial", "full"];
const LOSS_POLICIES = ["none", "capital_ratio", "manual", "carry_forward", "custom"];

export default function InvestorDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const [data, setData] = useState<Data | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showMoreTypes, setShowMoreTypes] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [templates, setTemplates] = useState<{ id: number; name: string }[]>([]);
  const [expandedInv, setExpandedInv] = useState<Set<number>>(new Set());
  const [txCache, setTxCache] = useState<Record<number, { type: string; amount: number; date: string; notes: string | null }[]>>({});
  const [txLoading, setTxLoading] = useState<Set<number>>(new Set());

  const [form, setForm] = useState({
    amount: "",
    startDate: new Date().toISOString().slice(0, 10),
    agreementType: "fixed_monthly",
    fixedMonthlyAmount: "",
    percentageRate: "",
    paymentFrequency: "monthly",
    reinvestmentMode: "none",
    partialReinvestPercent: "",
    lossPolicy: "none",
    notes: "",
  });

  async function load() {
    const [r, t] = await Promise.all([
      fetch(`/api/investors/${id}`).then((res) => res.json()),
      fetch("/api/agreement-templates").then((res) => res.json()),
    ]);
    setData(r);
    setTemplates(t);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function saveInvestment(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const r = await fetch("/api/investments", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        investorId: Number(id),
        amount: parseFloat(form.amount),
        startDate: form.startDate,
        notes: form.notes,
        agreement: {
          type: form.agreementType,
          fixedMonthlyAmount: form.fixedMonthlyAmount ? parseFloat(form.fixedMonthlyAmount) : null,
          percentageRate: form.percentageRate ? parseFloat(form.percentageRate) : null,
          paymentFrequency: form.paymentFrequency,
          reinvestmentMode: form.reinvestmentMode,
          partialReinvestPercent: form.partialReinvestPercent ? parseFloat(form.partialReinvestPercent) : null,
          lossPolicy: form.lossPolicy,
        },
      }),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      setError(err.error || "Failed to create investment");
      return;
    }
    setShowForm(false);
    setToast("Investment created");
    await load();
  }

  async function toggleInvestment(invId: number) {
    setExpandedInv((prev) => {
      const next = new Set(prev);
      if (next.has(invId)) next.delete(invId);
      else next.add(invId);
      return next;
    });
    if (!txCache[invId]) {
      setTxLoading((prev) => new Set(prev).add(invId));
      const r = await fetch(`/api/investments/${invId}`);
      const d = await r.json();
      setTxCache((prev) => ({ ...prev, [invId]: d.transactions }));
      setTxLoading((prev) => {
        const next = new Set(prev);
        next.delete(invId);
        return next;
      });
    }
  }

  if (!data) return <div className="text-slate-500 text-sm">Loading…</div>;

  const isArchived = !!data.investor.archivedAt;

  function archiveInvestor() {
    setConfirmReq({
      message: `Archive investor "${data?.investor.name}"? Their investments and history stay intact — this only hides them from your active list.`,
      onConfirm: async () => {
        await fetch(`/api/investors/${id}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ archived: true }),
        });
        router.push("/investors");
      },
    });
  }
  async function restoreInvestor() {
    await fetch(`/api/investors/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archived: false }),
    });
    await load();
    setToast("Investor restored");
  }
  function deleteInvestorPermanently() {
    setConfirmReq({
      message: `Permanently delete investor "${data?.investor.name}"? This cannot be undone.`,
      onConfirm: async () => {
        const r = await fetch(`/api/investors/${id}`, { method: "DELETE" });
        if (!r.ok) {
          const err = await r.json().catch(() => ({}));
          setToast(err.error || "Failed to delete");
          return;
        }
        router.push("/investors");
      },
    });
  }

  return (
    <div>
      <PageHeader
        title={data.investor.name}
        description={`${data.investor.phone || ""} ${data.investor.cnic ? "· CNIC: " + data.investor.cnic : ""}${isArchived ? " · Archived" : ""}`}
        actions={
          <div className="flex gap-2">
            <Link href={`/investors/${id}/statement`} className="px-4 py-2 rounded-md border border-slate-300 text-sm">
              📄 Statement
            </Link>
            {!isArchived ? (
              <>
                <button onClick={() => setShowForm(true)} className="px-4 py-2 rounded-md bg-slate-900 text-white text-sm font-medium">
                  + New Investment
                </button>
                <button onClick={archiveInvestor} className="px-4 py-2 rounded-md border border-amber-300 text-amber-700 text-sm">
                  Archive
                </button>
              </>
            ) : (
              <>
                <button onClick={restoreInvestor} className="px-4 py-2 rounded-md border border-emerald-300 text-emerald-700 text-sm">
                  Restore
                </button>
                <button onClick={deleteInvestorPermanently} className="px-4 py-2 rounded-md border border-rose-300 text-rose-700 text-sm">
                  Delete Permanently
                </button>
              </>
            )}
          </div>
        }
      />

      <div className="bg-slate-900 text-white rounded-lg p-4 mb-4 text-sm">
        {data.totals.principal > 0 ? (
          <>
            <strong>{data.investor.name}</strong> currently has{" "}
            <strong className="text-emerald-400">{formatCurrency(data.totals.principal)}</strong> invested,
            and has been paid <strong className="text-amber-400">{formatCurrency(data.totals.totalReturnsPaid)}</strong>{" "}
            so far across {data.investments.length} investment{data.investments.length === 1 ? "" : "s"}.
          </>
        ) : (
          <>No investments recorded yet for <strong>{data.investor.name}</strong>.</>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-50 rounded-lg p-4">
          <div className="text-xs text-slate-500">Total Principal (all investments)</div>
          <div className="text-xl font-semibold">{formatCurrency(data.totals.principal)}</div>
        </div>
        <div className="bg-slate-50 rounded-lg p-4">
          <div className="text-xs text-slate-500">Total Returns Paid</div>
          <div className="text-xl font-semibold text-emerald-700">{formatCurrency(data.totals.totalReturnsPaid)}</div>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <form onSubmit={saveInvestment} className="bg-white rounded-lg w-full max-w-lg p-6 space-y-3 my-8">
            <h2 className="font-semibold text-slate-800">New Investment</h2>
            {error && <div className="p-2 bg-rose-50 text-rose-700 text-sm rounded">{error}</div>}

            {templates.length > 0 && (
              <select
                className="input"
                onChange={(e) => {
                  const t = templates.find((x) => String(x.id) === e.target.value) as (typeof templates[number] & Record<string, unknown>) | undefined;
                  if (t) {
                    setForm((f) => ({
                      ...f,
                      agreementType: String(t.type ?? f.agreementType),
                      fixedMonthlyAmount: t.fixedMonthlyAmount != null ? String(t.fixedMonthlyAmount) : "",
                      percentageRate: t.percentageRate != null ? String(t.percentageRate) : "",
                      paymentFrequency: String(t.paymentFrequency ?? f.paymentFrequency),
                      reinvestmentMode: String(t.reinvestmentMode ?? f.reinvestmentMode),
                      lossPolicy: String(t.lossPolicy ?? f.lossPolicy),
                    }));
                  }
                }}
              >
                <option value="">— Start from a template (optional) —</option>
                {templates.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            )}

            <div className="grid grid-cols-2 gap-3">
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Investment Amount *</span>
                <input required type="number" className="input mt-1" value={form.amount}
                  onChange={(e) => setForm({ ...form, amount: e.target.value })} />
              </label>
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Start Date</span>
                <input type="date" className="input mt-1" value={form.startDate}
                  onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
              </label>
              <div className="block col-span-2">
                <span className="text-xs text-slate-600 font-medium">Agreement Type</span>
                <div className="grid grid-cols-2 gap-2 mt-1">
                  {COMMON_TYPES.map((t) => (
                    <button
                      key={t.value}
                      type="button"
                      onClick={() => setForm({ ...form, agreementType: t.value })}
                      className={`text-left p-2.5 rounded-md border text-xs ${
                        form.agreementType === t.value
                          ? "border-slate-900 bg-slate-50 font-medium"
                          : "border-slate-300 text-slate-600"
                      }`}
                    >
                      <div className="font-medium text-sm text-slate-800">{t.label}</div>
                      <div className="text-slate-500 mt-0.5">{t.hint}</div>
                    </button>
                  ))}
                </div>
                <button
                  type="button"
                  onClick={() => setShowMoreTypes(!showMoreTypes)}
                  className="text-xs font-medium text-blue-600 hover:underline mt-2"
                >
                  {showMoreTypes ? "− Hide" : "+ Show"} other agreement types (Profit Sharing, Hybrid, Manual)
                </button>
                {showMoreTypes && (
                  <select className="input mt-2" value={form.agreementType}
                    onChange={(e) => setForm({ ...form, agreementType: e.target.value })}>
                    <option value="">— Choose —</option>
                    {MORE_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                )}
              </div>
              {form.agreementType === "fixed_monthly" && (
                <label className="block col-span-2">
                  <span className="text-xs text-slate-600 font-medium">Fixed Monthly Amount</span>
                  <input type="number" className="input mt-1" value={form.fixedMonthlyAmount}
                    onChange={(e) => setForm({ ...form, fixedMonthlyAmount: e.target.value })} />
                </label>
              )}
              {form.agreementType === "percentage_monthly" && (
                <label className="block col-span-2">
                  <span className="text-xs text-slate-600 font-medium">Percentage Rate (%)</span>
                  <input type="number" step="0.1" className="input mt-1" value={form.percentageRate}
                    onChange={(e) => setForm({ ...form, percentageRate: e.target.value })} />
                </label>
              )}
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Payment Frequency</span>
                <select className="input mt-1" value={form.paymentFrequency}
                  onChange={(e) => setForm({ ...form, paymentFrequency: e.target.value })}>
                  {FREQUENCIES.map((f) => <option key={f} value={f}>{f.replace("_", " ")}</option>)}
                </select>
              </label>
            </div>

            <button
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="text-xs font-medium text-blue-600 hover:underline pt-1"
            >
              {showAdvanced ? "− Hide" : "+ Show"} advanced options (reinvestment, loss policy, notes)
            </button>

            {showAdvanced && (
              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="text-xs text-slate-600 font-medium">Reinvestment</span>
                  <select className="input mt-1" value={form.reinvestmentMode}
                    onChange={(e) => setForm({ ...form, reinvestmentMode: e.target.value })}>
                    {REINVEST_MODES.map((r) => <option key={r} value={r}>{r}</option>)}
                  </select>
                </label>
                {form.reinvestmentMode === "partial" && (
                  <label className="block">
                    <span className="text-xs text-slate-600 font-medium">Reinvest Percent (%)</span>
                    <input type="number" className="input mt-1" value={form.partialReinvestPercent}
                      onChange={(e) => setForm({ ...form, partialReinvestPercent: e.target.value })} />
                  </label>
                )}
                <label className="block col-span-2">
                  <span className="text-xs text-slate-600 font-medium">Loss Policy</span>
                  <select className="input mt-1" value={form.lossPolicy}
                    onChange={(e) => setForm({ ...form, lossPolicy: e.target.value })}>
                    {LOSS_POLICIES.map((l) => <option key={l} value={l}>{l.replace("_", " ")}</option>)}
                  </select>
                </label>
                <label className="block col-span-2">
                  <span className="text-xs text-slate-600 font-medium">Notes</span>
                  <textarea className="input mt-1" rows={2} value={form.notes}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })} />
                </label>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 text-sm rounded border border-slate-300">Cancel</button>
              <button type="submit" className="px-4 py-2 text-sm rounded bg-slate-900 text-white">Create Investment</button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-lg border border-slate-200">
        <div className="p-4 border-b border-slate-200"><h3 className="font-semibold">Investments</h3></div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-left text-slate-500 text-xs">
              <th className="px-4 py-2"></th>
              <th className="px-4 py-2">Started</th>
              <th className="px-4 py-2">Agreement</th>
              <th className="px-4 py-2 text-right">Principal</th>
              <th className="px-4 py-2 text-right">Returns Paid</th>
              <th className="px-4 py-2">Status</th>
              <th className="px-4 py-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.investments.length === 0 && (
              <tr><td colSpan={7} className="p-6 text-center text-slate-500">No investments yet.</td></tr>
            )}
            {data.investments.map((inv) => {
              const isOpen = expandedInv.has(inv.id);
              const isLoading = txLoading.has(inv.id);
              const txs = txCache[inv.id];
              return (
                <Fragment key={inv.id}>
                  <tr className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer" onClick={() => toggleInvestment(inv.id)}>
                    <td className="px-4 py-2 text-slate-400">
                      <span className={`inline-block transition-transform ${isOpen ? "rotate-90" : ""}`}>▶</span>
                    </td>
                    <td className="px-4 py-2">{formatDate(inv.startDate)}</td>
                    <td className="px-4 py-2 capitalize">{(inv.agreementType || "").replace("_", " ")}</td>
                    <td className="px-4 py-2 text-right font-medium">{formatCurrency(inv.balance.principal)}</td>
                    <td className="px-4 py-2 text-right text-emerald-700">{formatCurrency(inv.balance.totalReturnsPaid)}</td>
                    <td className="px-4 py-2 capitalize">{inv.agreementStatus}</td>
                    <td className="px-4 py-2 text-right" onClick={(e) => e.stopPropagation()}>
                      <Link href={`/investments/${inv.id}`} className="text-blue-600 hover:underline text-xs">Manage →</Link>
                    </td>
                  </tr>
                  {isOpen && (
                    <tr>
                      <td colSpan={7} className="bg-slate-50/60 px-4 py-3">
                        {isLoading && <div className="text-xs text-slate-500">Loading history…</div>}
                        {!isLoading && txs && txs.length === 0 && (
                          <div className="text-xs text-slate-500">No transactions recorded yet for this investment.</div>
                        )}
                        {!isLoading && txs && txs.length > 0 && (
                          <table className="w-full text-xs">
                            <thead className="text-slate-500">
                              <tr>
                                <th className="text-left py-1">Date</th>
                                <th className="text-left py-1">Type</th>
                                <th className="text-right py-1">Amount</th>
                                <th className="text-left py-1">Notes</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200">
                              {txs.map((t, i) => (
                                <tr key={i}>
                                  <td className="py-1">{formatDate(t.date)}</td>
                                  <td className="py-1 capitalize">{t.type.replace("_", " ")}</td>
                                  <td className="py-1 text-right">{formatCurrency(t.amount)}</td>
                                  <td className="py-1 text-slate-500">{t.notes || "—"}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        )}
                      </td>
                    </tr>
                  )}
                </Fragment>
              );
            })}
          </tbody>
        </table>
      </div>

      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />
      <Toast message={toast} onClose={() => setToast(null)} />

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}
