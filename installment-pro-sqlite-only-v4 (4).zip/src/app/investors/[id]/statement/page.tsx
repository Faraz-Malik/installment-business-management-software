"use client";
import { use, useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { saveAsPDF } from "@/lib/pdf";

type Statement = {
  business: { businessName: string; businessAddress: string | null; businessPhone: string | null; currency: string };
  investor: { name: string; phone: string | null; cnic: string | null };
  period: { from: string; to: string };
  typeFilter: string;
  totals: { principal: number; totalReturnsPaid: number; totalReinvested: number; totalWithdrawn: number };
  transactions: { date: string; type: string; amount: number; notes: string | null }[];
  generatedAt: string;
};

const TX_LABELS: Record<string, string> = {
  return_payment: "Return Payment",
  reinvestment: "Reinvestment",
  withdrawal: "Withdrawal",
  settlement_adjustment: "Settlement Adjustment",
  contribution: "Contribution",
};

function isoMonthsAgo(m: number) {
  const d = new Date();
  d.setMonth(d.getMonth() - m);
  return d.toISOString().slice(0, 10);
}

export default function InvestorStatementPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [from, setFrom] = useState(isoMonthsAgo(12));
  const [to, setTo] = useState(new Date().toISOString().slice(0, 10));
  const [typeFilter, setTypeFilter] = useState("all");
  const [statement, setStatement] = useState<Statement | null>(null);
  const [loading, setLoading] = useState(false);

  async function generate() {
    setLoading(true);
    const params2 = new URLSearchParams({ investorId: id, from, to, type: typeFilter });
    const r = await fetch(`/api/reports/investor-statement?${params2}`);
    if (r.ok) setStatement(await r.json());
    setLoading(false);
  }

  return (
    <div>
      <PageHeader title="Investor Statement" description="Investment, payment, reinvestment, or settlement statement — pick a filter below." />

      <div className="bg-white rounded-lg border border-slate-200 p-5 mb-6 print:hidden">
        <div className="grid grid-cols-4 gap-3 items-end">
          <label className="block">
            <span className="text-xs text-slate-600 font-medium">From</span>
            <input type="date" className="input mt-1" value={from} onChange={(e) => setFrom(e.target.value)} />
          </label>
          <label className="block">
            <span className="text-xs text-slate-600 font-medium">To</span>
            <input type="date" className="input mt-1" value={to} onChange={(e) => setTo(e.target.value)} />
          </label>
          <label className="block">
            <span className="text-xs text-slate-600 font-medium">Show</span>
            <select className="input mt-1" value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
              <option value="all">All Transactions (Investment Statement)</option>
              <option value="return_payment">Return Payments Only (Payment Statement)</option>
              <option value="reinvestment">Reinvestments Only (Reinvestment Statement)</option>
              <option value="settlement_adjustment">Settlement Adjustments Only (Settlement Statement)</option>
            </select>
          </label>
          <button onClick={generate} disabled={loading} className="px-4 py-2 rounded-md bg-slate-900 text-white text-sm font-medium">
            {loading ? "Generating…" : "Generate"}
          </button>
        </div>
      </div>

      {statement && (
        <>
          <div className="mb-4 print:hidden">
            <button onClick={() => saveAsPDF(`Investor-Statement-${statement.investor.name}.pdf`)} className="px-4 py-2 text-sm rounded border border-slate-300 mr-2">⬇ Save as PDF</button>
            <button onClick={() => window.print()} className="px-4 py-2 text-sm rounded bg-slate-900 text-white">🖨 Print</button>
          </div>
          <div id="statement" className="bg-white rounded-lg border border-slate-200 p-8">
            <div className="flex justify-between items-start border-b-2 border-slate-800 pb-4 mb-4">
              <div>
                <div className="text-xl font-bold">{statement.business.businessName}</div>
                {statement.business.businessAddress && <div className="text-xs text-slate-500">{statement.business.businessAddress}</div>}
              </div>
              <div className="text-right">
                <div className="text-lg font-semibold">INVESTOR STATEMENT</div>
                <div className="text-xs text-slate-500">Period: {formatDate(statement.period.from)} — {formatDate(statement.period.to)}</div>
                <div className="text-xs text-slate-400">Generated: {new Date(statement.generatedAt).toLocaleString()}</div>
              </div>
            </div>
            <div className="mb-4 text-sm">
              <span className="text-slate-500">Investor: </span><strong>{statement.investor.name}</strong>
              {statement.investor.phone && <span> · {statement.investor.phone}</span>}
              {statement.investor.cnic && <span> · CNIC: {statement.investor.cnic}</span>}
            </div>
            <div className="grid grid-cols-4 gap-3 mb-6 text-sm">
              <div className="bg-slate-50 rounded p-3"><div className="text-xs text-slate-500">Current Principal</div><div className="font-semibold">{formatCurrency(statement.totals.principal)}</div></div>
              <div className="bg-slate-50 rounded p-3"><div className="text-xs text-slate-500">Returns Paid</div><div className="font-semibold text-emerald-700">{formatCurrency(statement.totals.totalReturnsPaid)}</div></div>
              <div className="bg-slate-50 rounded p-3"><div className="text-xs text-slate-500">Reinvested</div><div className="font-semibold">{formatCurrency(statement.totals.totalReinvested)}</div></div>
              <div className="bg-slate-50 rounded p-3"><div className="text-xs text-slate-500">Withdrawn</div><div className="font-semibold text-rose-700">{formatCurrency(statement.totals.totalWithdrawn)}</div></div>
            </div>
            <table className="w-full text-sm">
              <thead><tr className="border-b-2 border-slate-300 text-left"><th className="py-2">Date</th><th className="py-2">Type</th><th className="py-2 text-right">Amount</th><th className="py-2">Notes</th></tr></thead>
              <tbody>
                {statement.transactions.length === 0 && <tr><td colSpan={4} className="py-6 text-center text-slate-400">No transactions in this period.</td></tr>}
                {statement.transactions.map((t, i) => (
                  <tr key={i} className="border-b border-slate-100">
                    <td className="py-2">{formatDate(t.date)}</td>
                    <td className="py-2">{TX_LABELS[t.type] || t.type}</td>
                    <td className="py-2 text-right">{formatCurrency(t.amount)}</td>
                    <td className="py-2 text-slate-500">{t.notes || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="text-xs text-slate-400 mt-4">This is a system-generated statement. Page 1.</div>
          </div>
        </>
      )}

      <style jsx global>{`
        @media print {
          body * { visibility: hidden; }
          #statement, #statement * { visibility: visible; }
          #statement { position: absolute; left: 0; top: 0; width: 100%; }
          @page { margin: 1.5cm; }
        }
      `}</style>
      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}
