"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";
import { Toast } from "@/components/Toast";
import { ArchiveTabs } from "@/components/ArchiveTabs";

type Investor = {
  id: number;
  name: string;
  cnic: string | null;
  phone: string | null;
  address: string | null;
  status: string;
  archivedAt: string | null;
};

const empty = { name: "", cnic: "", phone: "", address: "", notes: "" };

export default function InvestorsPage() {
  const [rows, setRows] = useState<Investor[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(empty);
  const [error, setError] = useState<string | null>(null);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [view, setView] = useState<"active" | "archived">("active");

  async function load() {
    setLoading(true);
    const r = await fetch(`/api/investors?archived=${view === "archived"}`);
    setRows(await r.json());
    setLoading(false);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const r = await fetch("/api/investors", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(form),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      setError(err.error || "Failed to save");
      return;
    }
    setShowForm(false);
    setForm(empty);
    await load();
  }

  function archive(inv: Investor) {
    setConfirmReq({
      message: `Archive investor "${inv.name}"?`,
      onConfirm: async () => {
        await fetch(`/api/investors/${inv.id}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ archived: true }),
        });
        await load();
      },
    });
  }
  async function restore(inv: Investor) {
    await fetch(`/api/investors/${inv.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archived: false }),
    });
    await load();
  }
  function removePermanently(inv: Investor) {
    setConfirmReq({
      message: `Permanently delete investor "${inv.name}"? This cannot be undone.`,
      onConfirm: async () => {
        const r = await fetch(`/api/investors/${inv.id}`, { method: "DELETE" });
        if (!r.ok) {
          const err = await r.json().catch(() => ({}));
          setToast(err.error || "Failed to delete");
          return;
        }
        await load();
      },
    });
  }

  return (
    <div>
      <PageHeader
        title="Investors"
        description="Manage investor profiles, agreements, and investments."
        actions={
          <button
            onClick={() => setShowForm(true)}
            className="px-4 py-2 rounded-md bg-slate-900 text-white text-sm font-medium"
          >
            + New Investor
          </button>
        }
      />

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <form onSubmit={save} className="bg-white rounded-lg w-full max-w-md p-6 space-y-3">
            <h2 className="font-semibold text-slate-800">New Investor</h2>
            {error && <div className="p-2 bg-rose-50 text-rose-700 text-sm rounded">{error}</div>}
            <input required placeholder="Name" className="input" value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input placeholder="CNIC" className="input" value={form.cnic}
              onChange={(e) => setForm({ ...form, cnic: e.target.value })} />
            <input placeholder="Phone" className="input" value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <input placeholder="Address" className="input" value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })} />
            <textarea placeholder="Notes" className="input" rows={2} value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 text-sm rounded border border-slate-300">Cancel</button>
              <button type="submit" className="px-4 py-2 text-sm rounded bg-slate-900 text-white">Save</button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-lg border border-slate-200">
        <div className="p-4 border-b border-slate-200 flex justify-end">
          <ArchiveTabs view={view} onChange={setView} />
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-left text-slate-500 text-xs">
              <th className="px-4 py-2">Name</th>
              <th className="px-4 py-2">Phone</th>
              <th className="px-4 py-2">CNIC</th>
              <th className="px-4 py-2">Status</th>
              <th className="px-4 py-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={5} className="p-6 text-center text-slate-500">Loading…</td></tr>}
            {!loading && rows.length === 0 && <tr><td colSpan={5} className="p-6 text-center text-slate-500">No investors yet.</td></tr>}
            {rows.map((inv) => (
              <tr key={inv.id} className="border-b border-slate-100">
                <td className="px-4 py-2">
                  <Link href={`/investors/${inv.id}`} className="text-blue-600 hover:underline font-medium">{inv.name}</Link>
                </td>
                <td className="px-4 py-2">{inv.phone || "—"}</td>
                <td className="px-4 py-2">{inv.cnic || "—"}</td>
                <td className="px-4 py-2 capitalize">{inv.status}</td>
                <td className="px-4 py-2 text-right space-x-2">
                  {view === "active" ? (
                    <button onClick={() => archive(inv)} className="text-amber-600 hover:underline text-xs">Archive</button>
                  ) : (
                    <>
                      <button onClick={() => restore(inv)} className="text-emerald-600 hover:underline text-xs">Restore</button>
                      <button onClick={() => removePermanently(inv)} className="text-rose-600 hover:underline text-xs">Delete Permanently</button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />
      <Toast message={toast} onClose={() => setToast(null)} />

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}
