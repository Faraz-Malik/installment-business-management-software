"use client";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";
import { Toast } from "@/components/Toast";
import { ArchiveTabs } from "@/components/ArchiveTabs";

type Supplier = {
  id: number;
  name: string;
  phone: string | null;
  address: string | null;
  cnic: string | null;
  notes: string | null;
  archivedAt: string | null;
};

const empty = {
  name: "",
  phone: "",
  address: "",
  cnic: "",
  notes: "",
};

export default function SuppliersPage() {
  const [rows, setRows] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Supplier | null>(null);
  const [form, setForm] = useState(empty);
  const [search, setSearch] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [view, setView] = useState<"active" | "archived">("active");

  async function load() {
    setLoading(true);
    const r = await fetch(`/api/suppliers?archived=${view === "archived"}`);
    setRows(await r.json());
    setLoading(false);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  function openNew() {
    setEditing(null);
    setForm(empty);
    setShowForm(true);
    setError(null);
  }
  function openEdit(s: Supplier) {
    setEditing(s);
    setForm({
      name: s.name,
      phone: s.phone ?? "",
      address: s.address ?? "",
      cnic: s.cnic ?? "",
      notes: s.notes ?? "",
    });
    setShowForm(true);
    setError(null);
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const url = editing ? `/api/suppliers/${editing.id}` : "/api/suppliers";
    const method = editing ? "PUT" : "POST";
    const r = await fetch(url, {
      method,
      headers: { "content-type": "application/json" },
      body: JSON.stringify(form),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      setError(err.error || "Failed to save");
      return;
    }
    setShowForm(false);
    await load();
  }

  function archive(s: Supplier) {
    setConfirmReq({
      message: `Archive supplier "${s.name}"? It will be hidden from the active list, and can be restored later.`,
      onConfirm: async () => {
        const r = await fetch(`/api/suppliers/${s.id}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ archived: true }),
        });
        if (!r.ok) {
          setToast("Failed to archive");
          return;
        }
        await load();
      },
    });
  }

  async function restore(s: Supplier) {
    const r = await fetch(`/api/suppliers/${s.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archived: false }),
    });
    if (!r.ok) {
      setToast("Failed to restore");
      return;
    }
    await load();
  }

  function removePermanently(s: Supplier) {
    setConfirmReq({
      message: `Permanently delete supplier "${s.name}"? This cannot be undone.`,
      onConfirm: async () => {
        const r = await fetch(`/api/suppliers/${s.id}`, { method: "DELETE" });
        if (!r.ok) {
          const err = await r.json().catch(() => ({}));
          setToast(err.error || "Failed to delete");
          return;
        }
        await load();
      },
    });
  }

  const filtered = rows.filter((r) =>
    [r.name, r.phone, r.cnic, r.address]
      .filter(Boolean)
      .join(" ")
      .toLowerCase()
      .includes(search.toLowerCase()),
  );

  return (
    <div>
      <PageHeader
        title="Suppliers"
        description="Vendors you purchase products from."
        actions={
          <button
            onClick={openNew}
            className="px-4 py-2 rounded-md bg-slate-900 text-white text-sm font-medium hover:bg-slate-800"
          >
            + New Supplier
          </button>
        }
      />

      <div className="bg-white rounded-lg border border-slate-200">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <input
            className="w-full max-w-md border border-slate-300 rounded-md px-3 py-2 text-sm"
            placeholder="Search by name, phone, CNIC…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <ArchiveTabs view={view} onChange={setView} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="text-left px-4 py-2 font-medium">Name</th>
                <th className="text-left px-4 py-2 font-medium">Phone</th>
                <th className="text-left px-4 py-2 font-medium">CNIC</th>
                <th className="text-left px-4 py-2 font-medium">Address</th>
                <th className="text-right px-4 py-2 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading && (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-slate-500">
                    Loading…
                  </td>
                </tr>
              )}
              {!loading && filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-slate-500">
                    No suppliers found.
                  </td>
                </tr>
              )}
              {filtered.map((s) => (
                <tr key={s.id} className="hover:bg-slate-50">
                  <td className="px-4 py-2 font-medium text-slate-800">
                    {s.name}
                  </td>
                  <td className="px-4 py-2">{s.phone ?? "-"}</td>
                  <td className="px-4 py-2">{s.cnic ?? "-"}</td>
                  <td className="px-4 py-2 text-slate-600">
                    {s.address ?? "-"}
                  </td>
                  <td className="px-4 py-2 text-right space-x-2">
                    {view === "active" ? (
                      <>
                        <button
                          onClick={() => openEdit(s)}
                          className="text-blue-600 hover:underline text-xs"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => archive(s)}
                          className="text-amber-600 hover:underline text-xs"
                        >
                          Archive
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => restore(s)}
                          className="text-emerald-600 hover:underline text-xs"
                        >
                          Restore
                        </button>
                        <button
                          onClick={() => removePermanently(s)}
                          className="text-rose-600 hover:underline text-xs"
                        >
                          Delete Permanently
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <form
            onSubmit={save}
            className="bg-white rounded-lg w-full max-w-lg p-6 space-y-4"
          >
            <h2 className="text-lg font-semibold">
              {editing ? "Edit Supplier" : "New Supplier"}
            </h2>
            {error && (
              <div className="p-2 bg-rose-50 text-rose-700 text-sm rounded">
                {error}
              </div>
            )}
            <Field label="Name *">
              <input
                required
                className="input"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Phone">
                <input
                  className="input"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                />
              </Field>
              <Field label="CNIC">
                <input
                  className="input"
                  value={form.cnic}
                  onChange={(e) => setForm({ ...form, cnic: e.target.value })}
                />
              </Field>
            </div>
            <Field label="Address">
              <input
                className="input"
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
              />
            </Field>
            <Field label="Notes">
              <textarea
                className="input"
                rows={2}
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
              />
            </Field>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2 text-sm rounded border border-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm rounded bg-slate-900 text-white"
              >
                {editing ? "Save Changes" : "Create"}
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />
      <Toast message={toast} onClose={() => setToast(null)} />

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-xs text-slate-600 font-medium">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
