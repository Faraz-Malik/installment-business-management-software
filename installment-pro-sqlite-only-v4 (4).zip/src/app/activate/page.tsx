"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function ActivatePage() {
  const router = useRouter();
  const [deviceId, setDeviceId] = useState("");
  const [key, setKey] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch("/api/license/status")
      .then((r) => r.json())
      .then((d) => {
        if (d.activated) {
          router.push("/login");
          router.refresh();
        } else {
          setDeviceId(d.deviceId);
        }
      });
  }, [router]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const r = await fetch("/api/license/activate", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ key }),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      setError(err.error || "Activation failed");
      setLoading(false);
      return;
    }
    router.push("/login");
    router.refresh();
  }

  function copyDeviceId() {
    navigator.clipboard?.writeText(deviceId);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="text-2xl font-bold tracking-tight text-white">
            Installment<span className="text-emerald-400">Pro</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Business Management Suite
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-2xl p-8 space-y-5">
          <div>
            <h1 className="text-lg font-semibold text-slate-900">
              Activate This Computer
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              This software must be activated once, on this computer, before
              use.
            </p>
          </div>

          <div className="bg-slate-50 rounded-md p-3">
            <div className="text-xs font-medium text-slate-600 mb-1">
              Your Device ID
            </div>
            <div className="flex items-center gap-2">
              <code className="flex-1 text-sm font-mono text-slate-900 tracking-wide">
                {deviceId || "Loading…"}
              </code>
              <button
                type="button"
                onClick={copyDeviceId}
                className="text-xs px-2 py-1 rounded border border-slate-300 hover:bg-slate-100"
              >
                {copied ? "Copied" : "Copy"}
              </button>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Send this ID to your software provider to receive your
              Activation Key.
            </p>
          </div>

          {error && (
            <div className="p-2.5 bg-rose-50 text-rose-700 text-sm rounded-md">
              {error}
            </div>
          )}

          <form onSubmit={submit} className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">
                Activation Key
              </label>
              <input
                autoFocus
                required
                placeholder="XXXX-XXXX-XXXX-XXXX-XXXX"
                value={key}
                onChange={(e) => setKey(e.target.value)}
                className="w-full border border-slate-300 rounded-md px-3 py-2 text-sm font-mono tracking-wide focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-md bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 disabled:opacity-60"
            >
              {loading ? "Activating…" : "Activate"}
            </button>
          </form>
        </div>

        <div className="text-center text-xs text-slate-500 mt-4">
          One-time setup · Offline · No internet required
        </div>
      </div>
    </div>
  );
}
