"use client";
import { useEffect, useRef, useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";

type Settings = {
  id: number;
  businessName: string;
  businessPhone: string | null;
  businessAddress: string | null;
  currency: string;
  taxPercent: string;
  receiptFooter: string | null;
  profitCalculationMode: string;
};

export default function SettingsPage() {
  const [data, setData] = useState<Settings | null>(null);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);
  const [restoreMsg, setRestoreMsg] = useState<string | null>(null);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [pwForm, setPwForm] = useState({ currentPassword: "", newPassword: "", confirmPassword: "" });
  const [pwMsg, setPwMsg] = useState<{ text: string; ok: boolean } | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then(setData);
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!data) return;
    const r = await fetch("/api/settings", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(data),
    });
    if (r.ok) {
      setSavedMsg("Settings saved.");
      setTimeout(() => setSavedMsg(null), 2500);
    }
  }

  async function restore(file: File) {
    setRestoreMsg(null);
    const bytes = await file.arrayBuffer();
    const r = await fetch("/api/restore", {
      method: "POST",
      headers: { "content-type": "application/zip" },
      body: bytes,
    });
    const res = await r.json();
    if (r.ok) {
      setRestoreMsg(
        "✅ Restore successful. A safety copy of your previous data was saved automatically. Reload the page to see the restored data.",
      );
    } else {
      setRestoreMsg(`❌ ${res.error || "Restore failed"}`);
    }
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    setPwMsg(null);
    if (pwForm.newPassword !== pwForm.confirmPassword) {
      setPwMsg({ text: "New passwords do not match.", ok: false });
      return;
    }
    const r = await fetch("/api/auth/change-password", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        currentPassword: pwForm.currentPassword,
        newPassword: pwForm.newPassword,
      }),
    });
    const res = await r.json().catch(() => ({}));
    if (r.ok) {
      setPwMsg({ text: "Password changed successfully.", ok: true });
      setPwForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
    } else {
      setPwMsg({ text: res.error || "Failed to change password", ok: false });
    }
  }

  if (!data) return <div className="text-slate-500 text-sm">Loading…</div>;

  return (
    <div>
      <PageHeader
        title="Settings"
        description="Business information, backup, and restore."
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <form
          onSubmit={save}
          className="bg-white rounded-lg border border-slate-200 p-5 space-y-3"
        >
          <h2 className="font-semibold text-slate-800">Business Profile</h2>
          {savedMsg && (
            <div className="p-2 bg-emerald-50 text-emerald-700 text-sm rounded">
              {savedMsg}
            </div>
          )}
          <Field label="Business Name *">
            <input
              className="input"
              required
              value={data.businessName}
              onChange={(e) =>
                setData({ ...data, businessName: e.target.value })
              }
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Phone">
              <input
                className="input"
                value={data.businessPhone ?? ""}
                onChange={(e) =>
                  setData({ ...data, businessPhone: e.target.value })
                }
              />
            </Field>
            <Field label="Currency">
              <input
                className="input"
                value={data.currency}
                onChange={(e) =>
                  setData({ ...data, currency: e.target.value })
                }
              />
            </Field>
          </div>
          <Field label="Address">
            <input
              className="input"
              value={data.businessAddress ?? ""}
              onChange={(e) =>
                setData({ ...data, businessAddress: e.target.value })
              }
            />
          </Field>
          <Field label="Receipt Footer">
            <textarea
              className="input"
              rows={2}
              value={data.receiptFooter ?? ""}
              onChange={(e) =>
                setData({ ...data, receiptFooter: e.target.value })
              }
            />
          </Field>
          <div className="pt-2">
            <button
              type="submit"
              className="px-4 py-2 text-sm rounded bg-slate-900 text-white"
            >
              Save Settings
            </button>
          </div>
        </form>

        <div className="bg-white rounded-lg border border-slate-200 p-5 space-y-4">
          <h2 className="font-semibold text-slate-800">Backup & Restore</h2>
          <p className="text-sm text-slate-600">
            Download a complete backup (a .zip containing your database, a
            checksum, and version info) or restore from a previously
            downloaded backup. Restore verifies the backup&apos;s integrity
            first and automatically saves a safety copy of your current data
            before replacing it.
          </p>
          <div className="flex flex-col gap-3">
            <a
              href="/api/backup"
              className="inline-block text-center px-4 py-2 text-sm rounded bg-emerald-600 text-white hover:bg-emerald-700"
            >
              ⬇ Download Backup
            </a>

            <div>
              <input
                ref={fileRef}
                type="file"
                accept=".zip,application/zip"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) {
                    setConfirmReq({
                      message: "This will replace ALL existing data. A safety copy of your current data will be saved automatically first. Continue?",
                      onConfirm: () => restore(f),
                    });
                    e.target.value = "";
                  }
                }}
              />
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="w-full px-4 py-2 text-sm rounded border border-slate-300 hover:bg-slate-50"
              >
                ⬆ Restore from Backup
              </button>
            </div>

            {restoreMsg && (
              <div
                className={`p-2 text-sm rounded ${
                  restoreMsg.startsWith("✅")
                    ? "bg-emerald-50 text-emerald-700"
                    : "bg-rose-50 text-rose-700"
                }`}
              >
                {restoreMsg}
              </div>
            )}
          </div>

          <div className="border-t border-slate-200 pt-4 text-xs text-slate-500">
            <p>
              Tip: For thermal printer receipts, use your browser&apos;s print
              dialog on the payment receipt view. Only the receipt content is
              printed.
            </p>
          </div>
        </div>

        <form
          onSubmit={changePassword}
          className="bg-white rounded-lg border border-slate-200 p-5 space-y-3"
        >
          <h2 className="font-semibold text-slate-800">Change Password</h2>
          {pwMsg && (
            <div
              className={`p-2 text-sm rounded ${
                pwMsg.ok
                  ? "bg-emerald-50 text-emerald-700"
                  : "bg-rose-50 text-rose-700"
              }`}
            >
              {pwMsg.text}
            </div>
          )}
          <Field label="Current Password *">
            <input
              type="password"
              required
              className="input"
              value={pwForm.currentPassword}
              onChange={(e) =>
                setPwForm({ ...pwForm, currentPassword: e.target.value })
              }
            />
          </Field>
          <Field label="New Password *">
            <input
              type="password"
              required
              minLength={6}
              className="input"
              value={pwForm.newPassword}
              onChange={(e) =>
                setPwForm({ ...pwForm, newPassword: e.target.value })
              }
            />
          </Field>
          <Field label="Confirm New Password *">
            <input
              type="password"
              required
              minLength={6}
              className="input"
              value={pwForm.confirmPassword}
              onChange={(e) =>
                setPwForm({ ...pwForm, confirmPassword: e.target.value })
              }
            />
          </Field>
          <div className="pt-2">
            <button
              type="submit"
              className="px-4 py-2 text-sm rounded bg-slate-900 text-white"
            >
              Update Password
            </button>
          </div>
        </form>
      </div>

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-xs text-slate-600 font-medium">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
