"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { calculatePricing, type ProfitCalculationMode } from "@/lib/pricing";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";
import { Toast } from "@/components/Toast";
import { ArchiveTabs } from "@/components/ArchiveTabs";

type Lead = {
  id: number;
  name: string | null;
  phone: string | null;
  cnic: string | null;
  address: string | null;
  guarantorName: string | null;
  guarantorPhone: string | null;
  guarantorPermanentAddress: string | null;
  guarantorCurrentAddress: string | null;
  guarantorOccupation: string | null;
  productName: string | null;
  notes: string | null;
  purchasePrice: number;
  profitPercent: number;
  downPayment: number;
  discount: number;
  numInstallments: number;
  frequency: string;
  profitCalculationMode: string;
  purchaseId: number | null;
  convertedToSaleId: number | null;
  createdAt: string;
  archivedAt: string | null;
};
type Customer = { id: number; name: string };
type Purchase = { id: number; itemName: string; supplierName: string | null };

function addInterval(dateStr: string, count: number, frequency: string): string {
  const d = new Date(dateStr);
  if (frequency === "weekly") d.setDate(d.getDate() + count * 7);
  else d.setMonth(d.getMonth() + count); // monthly (default fallback too)
  return d.toISOString().slice(0, 10);
}

export default function CalculatorPage() {
  const router = useRouter();
  const [defaultMode, setDefaultMode] = useState<ProfitCalculationMode>("full_price");
  const [leads, setLeads] = useState<Lead[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [view, setView] = useState<"active" | "archived">("active");
  const [loading, setLoading] = useState(true);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [showVisitor, setShowVisitor] = useState(false);
  const [convertLead, setConvertLead] = useState<Lead | null>(null);
  const [convertForm, setConvertForm] = useState({
    customerId: "",
    name: "",
    phone: "",
    cnic: "",
    address: "",
    guarantorName: "",
    guarantorPhone: "",
    guarantorPermanentAddress: "",
    guarantorCurrentAddress: "",
    guarantorOccupation: "",
    productName: "",
    purchasePrice: "",
    profitPercent: "",
    profitMode: "full_price" as ProfitCalculationMode,
    downPayment: "",
    discount: "",
    numInstallments: "",
    frequency: "monthly",
    startDate: new Date().toISOString().slice(0, 10),
    purchaseId: "",
    notes: "",
  });

  const [form, setForm] = useState({
    productPrice: "100000",
    advancePayment: "0",
    profitPercent: "20",
    profitMode: "full_price" as ProfitCalculationMode,
    frequency: "monthly",
    numInstallments: "10",
    discount: "0",
    purchaseId: "",
    // Visitor mode
    name: "",
    phone: "",
    productName: "",
    notes: "",
    cnic: "",
    address: "",
    guarantorName: "",
    guarantorPhone: "",
    guarantorPermanentAddress: "",
    guarantorCurrentAddress: "",
    guarantorOccupation: "",
  });
  const [showGuarantor, setShowGuarantor] = useState(false);

  async function load() {
    setLoading(true);
    const [biz, l, p, c] = await Promise.all([
      fetch("/api/settings").then((r) => r.json()),
      fetch(`/api/leads?archived=${view === "archived"}`).then((r) => r.json()),
      fetch("/api/purchases").then((r) => r.json()),
      fetch("/api/customers").then((r) => r.json()),
    ]);
    setCustomers(c);
    if (biz?.profitCalculationMode) {
      setDefaultMode(biz.profitCalculationMode);
      setForm((f) => ({ ...f, profitMode: biz.profitCalculationMode }));
    }
    setLeads(l);
    setPurchases(p);
    setLoading(false);
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view]);

  const calc = useMemo(() => {
    const pp = parseFloat(form.productPrice) || 0;
    const pct = parseFloat(form.profitPercent) || 0;
    const down = parseFloat(form.advancePayment) || 0;
    const n = parseInt(form.numInstallments) || 0;
    const discount = parseFloat(form.discount) || 0;
    const result = calculatePricing({
      purchasePrice: pp,
      profitPercent: pct,
      downPayment: down,
      numInstallments: n,
      mode: form.profitMode,
    });
    const finalAfterDiscount = +(result.finalPrice - discount).toFixed(2);
    const remainingAfterDiscount = +(result.remainingBalance - discount).toFixed(2);
    const installmentAfterDiscount =
      n > 0 ? +(remainingAfterDiscount / n).toFixed(2) : 0;
    const completionDate =
      n > 0 ? addInterval(new Date().toISOString().slice(0, 10), n, form.frequency) : "—";
    return {
      financedAmount: result.financedAmount,
      profit: result.profitAmount,
      final: finalAfterDiscount,
      remaining: remainingAfterDiscount,
      installment: installmentAfterDiscount,
      completionDate,
    };
  }, [form]);

  async function saveLead() {
    const r = await fetch("/api/leads", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        name: form.name || null,
        phone: form.phone || null,
        cnic: form.cnic || null,
        address: form.address || null,
        guarantorName: form.guarantorName || null,
        guarantorPhone: form.guarantorPhone || null,
        guarantorPermanentAddress: form.guarantorPermanentAddress || null,
        guarantorCurrentAddress: form.guarantorCurrentAddress || null,
        guarantorOccupation: form.guarantorOccupation || null,
        productName: form.productName || null,
        notes: form.notes || null,
        purchasePrice: parseFloat(form.productPrice) || 0,
        profitPercent: parseFloat(form.profitPercent) || 0,
        downPayment: parseFloat(form.advancePayment) || 0,
        discount: parseFloat(form.discount) || 0,
        numInstallments: parseInt(form.numInstallments) || 0,
        frequency: form.frequency,
        profitCalculationMode: form.profitMode,
        purchaseId: form.purchaseId || null,
      }),
    });
    if (!r.ok) {
      setToast("Failed to save quotation");
      return;
    }
    setToast("Quotation saved");
    await load();
  }

  function openConvertReview(lead: Lead) {
    setConvertLead(lead);
    setConvertForm({
      customerId: "",
      name: lead.name || "",
      phone: lead.phone || "",
      cnic: lead.cnic || "",
      address: lead.address || "",
      guarantorName: lead.guarantorName || "",
      guarantorPhone: lead.guarantorPhone || "",
      guarantorPermanentAddress: lead.guarantorPermanentAddress || "",
      guarantorCurrentAddress: lead.guarantorCurrentAddress || "",
      guarantorOccupation: lead.guarantorOccupation || "",
      productName: lead.productName || "",
      purchasePrice: String(lead.purchasePrice),
      profitPercent: String(lead.profitPercent),
      profitMode: lead.profitCalculationMode as ProfitCalculationMode,
      downPayment: String(lead.downPayment),
      discount: String(lead.discount),
      numInstallments: String(lead.numInstallments),
      frequency: lead.frequency,
      startDate: new Date().toISOString().slice(0, 10),
      purchaseId: lead.purchaseId ? String(lead.purchaseId) : "",
      notes: lead.notes || "",
    });
  }

  const convertCalc = useMemo(() => {
    if (!convertLead) return null;
    const pp = parseFloat(convertForm.purchasePrice) || 0;
    const pct = parseFloat(convertForm.profitPercent) || 0;
    const down = parseFloat(convertForm.downPayment) || 0;
    const n = parseInt(convertForm.numInstallments) || 0;
    const discount = parseFloat(convertForm.discount) || 0;
    const result = calculatePricing({
      purchasePrice: pp, profitPercent: pct, downPayment: down,
      numInstallments: n, mode: convertForm.profitMode,
    });
    const final = +(result.finalPrice - discount).toFixed(2);
    const remaining = +(result.remainingBalance - discount).toFixed(2);
    const inst = n > 0 ? +(remaining / n).toFixed(2) : 0;
    return { profit: result.profitAmount, final, remaining, inst };
  }, [convertLead, convertForm]);

  async function submitConversion(e: React.FormEvent) {
    e.preventDefault();
    if (!convertLead) return;
    const r = await fetch(`/api/leads/${convertLead.id}/convert`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        customerId: convertForm.customerId || undefined,
        name: convertForm.name || undefined,
        phone: convertForm.phone || undefined,
        cnic: convertForm.cnic || undefined,
        address: convertForm.address || undefined,
        guarantorName: convertForm.guarantorName || undefined,
        guarantorPhone: convertForm.guarantorPhone || undefined,
        guarantorPermanentAddress: convertForm.guarantorPermanentAddress || undefined,
        guarantorCurrentAddress: convertForm.guarantorCurrentAddress || undefined,
        guarantorOccupation: convertForm.guarantorOccupation || undefined,
        productName: convertForm.productName,
        purchasePrice: parseFloat(convertForm.purchasePrice) || 0,
        profitPercent: parseFloat(convertForm.profitPercent) || 0,
        profitCalculationMode: convertForm.profitMode,
        downPayment: parseFloat(convertForm.downPayment) || 0,
        discount: parseFloat(convertForm.discount) || 0,
        numInstallments: parseInt(convertForm.numInstallments) || 0,
        frequency: convertForm.frequency,
        startDate: convertForm.startDate,
        purchaseId: convertForm.purchaseId || null,
        notes: convertForm.notes || null,
      }),
    });
    const res = await r.json().catch(() => ({}));
    if (!r.ok) {
      setToast(res.error || "Conversion failed");
      return;
    }
    setToast("Converted to sale — opening it now.");
    setConvertLead(null);
    await load();
    router.push(`/sales/${res.saleId}`);
  }

  function archive(lead: Lead) {
    setConfirmReq({
      message: "Archive this quotation?",
      onConfirm: async () => {
        await fetch(`/api/leads/${lead.id}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ archived: true }),
        });
        await load();
      },
    });
  }
  async function restore(lead: Lead) {
    await fetch(`/api/leads/${lead.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archived: false }),
    });
    await load();
  }
  function removePermanently(lead: Lead) {
    setConfirmReq({
      message: "Permanently delete this quotation? This cannot be undone.",
      onConfirm: async () => {
        const r = await fetch(`/api/leads/${lead.id}`, { method: "DELETE" });
        if (!r.ok) {
          const err = await r.json().catch(() => ({}));
          setToast(err.error || "Failed to delete");
          return;
        }
        await load();
      },
    });
  }

  return (
    <div>
      <PageHeader
        title="Fast Deal Calculator"
        description="Answer 'what if' questions instantly — nothing is saved unless you choose to."
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Inputs */}
        <div className="bg-white rounded-lg border border-slate-200 p-5 space-y-3">
          <h2 className="font-semibold text-slate-800 mb-1">Deal Terms</h2>
          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Product Price</span>
              <input className="input mt-1" type="number" value={form.productPrice}
                onChange={(e) => setForm({ ...form, productPrice: e.target.value })} />
            </label>
            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Advance Payment</span>
              <input className="input mt-1" type="number" value={form.advancePayment}
                onChange={(e) => setForm({ ...form, advancePayment: e.target.value })} />
            </label>
            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Profit %</span>
              <input className="input mt-1" type="number" value={form.profitPercent}
                onChange={(e) => setForm({ ...form, profitPercent: e.target.value })} />
            </label>
            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Profit Mode</span>
              <select className="input mt-1" value={form.profitMode}
                onChange={(e) => setForm({ ...form, profitMode: e.target.value as ProfitCalculationMode })}>
                <option value="full_price">On Full Price</option>
                <option value="remaining_balance">On Remaining Balance</option>
              </select>
            </label>
            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Installment Frequency</span>
              <select className="input mt-1" value={form.frequency}
                onChange={(e) => setForm({ ...form, frequency: e.target.value })}>
                <option value="monthly">Monthly</option>
                <option value="weekly">Weekly</option>
              </select>
            </label>
            <label className="block">
              <span className="text-xs text-slate-600 font-medium"># of Installments</span>
              <input className="input mt-1" type="number" value={form.numInstallments}
                onChange={(e) => setForm({ ...form, numInstallments: e.target.value })} />
            </label>
            <label className="block col-span-2">
              <span className="text-xs text-slate-600 font-medium">Manual Discount (optional)</span>
              <input className="input mt-1" type="number" value={form.discount}
                onChange={(e) => setForm({ ...form, discount: e.target.value })} />
            </label>
            <label className="block col-span-2">
              <span className="text-xs text-slate-600 font-medium">Linked Purchase (optional)</span>
              <select className="input mt-1" value={form.purchaseId}
                onChange={(e) => setForm({ ...form, purchaseId: e.target.value })}>
                <option value="">— None —</option>
                {purchases.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.itemName}{p.supplierName ? ` (${p.supplierName})` : ""}
                  </option>
                ))}
              </select>
              <p className="text-xs text-slate-500 mt-1">
                Optional, same as on the New Sale form. If left blank, the sale this converts to will have no supplier linked — you can still pick one later on the sale itself.
              </p>
            </label>
          </div>

          <div className="pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setShowVisitor(!showVisitor)}
              className="text-xs font-medium text-blue-600 hover:underline"
            >
              {showVisitor ? "− Hide" : "+ Add"} visitor details (optional)
            </button>
            {showVisitor && (
              <div className="grid grid-cols-2 gap-3 mt-3">
                <label className="block">
                  <span className="text-xs text-slate-600 font-medium">Visitor Name</span>
                  <input className="input mt-1" value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </label>
                <label className="block">
                  <span className="text-xs text-slate-600 font-medium">Phone</span>
                  <input className="input mt-1" value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                </label>
                <label className="block">
                  <span className="text-xs text-slate-600 font-medium">CNIC</span>
                  <input className="input mt-1" value={form.cnic}
                    onChange={(e) => setForm({ ...form, cnic: e.target.value })} />
                </label>
                <label className="block">
                  <span className="text-xs text-slate-600 font-medium">Address</span>
                  <input className="input mt-1" value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })} />
                </label>
                <label className="block">
                  <span className="text-xs text-slate-600 font-medium">Interested Product</span>
                  <input className="input mt-1" value={form.productName}
                    onChange={(e) => setForm({ ...form, productName: e.target.value })} />
                </label>
                <label className="block">
                  <span className="text-xs text-slate-600 font-medium">Notes</span>
                  <input className="input mt-1" value={form.notes}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })} />
                </label>

                <div className="col-span-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowGuarantor(!showGuarantor)}
                    className="text-xs font-medium text-blue-600 hover:underline"
                  >
                    {showGuarantor ? "− Hide" : "+ Add"} guarantor details (optional, same as Customers form)
                  </button>
                </div>
                {showGuarantor && (
                  <>
                    <label className="block">
                      <span className="text-xs text-slate-600 font-medium">Guarantor Name</span>
                      <input className="input mt-1" value={form.guarantorName}
                        onChange={(e) => setForm({ ...form, guarantorName: e.target.value })} />
                    </label>
                    <label className="block">
                      <span className="text-xs text-slate-600 font-medium">Guarantor Phone</span>
                      <input className="input mt-1" value={form.guarantorPhone}
                        onChange={(e) => setForm({ ...form, guarantorPhone: e.target.value })} />
                    </label>
                    <label className="block">
                      <span className="text-xs text-slate-600 font-medium">Guarantor Permanent Address</span>
                      <input className="input mt-1" value={form.guarantorPermanentAddress}
                        onChange={(e) => setForm({ ...form, guarantorPermanentAddress: e.target.value })} />
                    </label>
                    <label className="block">
                      <span className="text-xs text-slate-600 font-medium">Guarantor Current Address</span>
                      <input className="input mt-1" value={form.guarantorCurrentAddress}
                        onChange={(e) => setForm({ ...form, guarantorCurrentAddress: e.target.value })} />
                    </label>
                    <label className="block col-span-2">
                      <span className="text-xs text-slate-600 font-medium">Guarantor Occupation / Profession</span>
                      <input className="input mt-1" value={form.guarantorOccupation}
                        onChange={(e) => setForm({ ...form, guarantorOccupation: e.target.value })} />
                    </label>
                  </>
                )}
              </div>
            )}
          </div>

          <button
            onClick={saveLead}
            className="w-full mt-2 px-4 py-2 text-sm rounded bg-slate-900 text-white"
          >
            💾 Save as Lead
          </button>
        </div>

        {/* Live result */}
        <div className="bg-slate-900 text-white rounded-lg p-5">
          <h2 className="font-semibold mb-4 text-slate-200">Result — live, nothing saved yet</h2>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div><div className="text-slate-400 text-xs">Financed Amount</div><div className="text-lg font-semibold">{formatCurrency(calc.financedAmount)}</div></div>
            <div><div className="text-slate-400 text-xs">Profit</div><div className="text-lg font-semibold text-emerald-400">{formatCurrency(calc.profit)}</div></div>
            <div><div className="text-slate-400 text-xs">Total Selling Price</div><div className="text-lg font-semibold">{formatCurrency(calc.final)}</div></div>
            <div><div className="text-slate-400 text-xs">Remaining Balance</div><div className="text-lg font-semibold">{formatCurrency(calc.remaining)}</div></div>
            <div><div className="text-slate-400 text-xs">Installment Amount</div><div className="text-lg font-semibold text-amber-400">{formatCurrency(calc.installment)}</div></div>
            <div><div className="text-slate-400 text-xs">Expected Completion</div><div className="text-lg font-semibold">{calc.completionDate !== "—" ? formatDate(calc.completionDate) : "—"}</div></div>
          </div>
        </div>
      </div>

      {/* Saved leads */}
      <div className="bg-white rounded-lg border border-slate-200">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-semibold text-slate-800">Saved Quotations</h3>
          <ArchiveTabs view={view} onChange={setView} />
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-left text-slate-500 text-xs">
              <th className="px-4 py-2">Name</th>
              <th className="px-4 py-2">Product</th>
              <th className="px-4 py-2 text-right">Final Price</th>
              <th className="px-4 py-2 text-right">Installment</th>
              <th className="px-4 py-2">Saved</th>
              <th className="px-4 py-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={6} className="p-6 text-center text-slate-500">Loading…</td></tr>
            )}
            {!loading && leads.length === 0 && (
              <tr><td colSpan={6} className="p-6 text-center text-slate-500">No saved quotations yet.</td></tr>
            )}
            {leads.map((l) => {
              const r = calculatePricing({
                purchasePrice: l.purchasePrice,
                profitPercent: l.profitPercent,
                downPayment: l.downPayment,
                numInstallments: l.numInstallments,
                mode: l.profitCalculationMode as ProfitCalculationMode,
              });
              const finalAfterDiscount = r.finalPrice - l.discount;
              const instAfterDiscount =
                l.numInstallments > 0
                  ? (r.remainingBalance - l.discount) / l.numInstallments
                  : 0;
              return (
                <tr key={l.id} className="border-b border-slate-100">
                  <td className="px-4 py-2">{l.name || "—"}{l.phone && <div className="text-xs text-slate-400">{l.phone}</div>}</td>
                  <td className="px-4 py-2">
                    {l.productName || "—"}
                    {l.purchaseId && (
                      <div className="text-xs text-slate-400">
                        {purchases.find((p) => p.id === l.purchaseId)?.supplierName
                          ? `Supplier: ${purchases.find((p) => p.id === l.purchaseId)?.supplierName}`
                          : "Linked to a purchase"}
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-2 text-right">{formatCurrency(finalAfterDiscount)}</td>
                  <td className="px-4 py-2 text-right">{formatCurrency(instAfterDiscount)}</td>
                  <td className="px-4 py-2 text-xs text-slate-500">{formatDate(l.createdAt)}</td>
                  <td className="px-4 py-2 text-right space-x-2">
                    {l.convertedToSaleId ? (
                      <Link href={`/sales/${l.convertedToSaleId}`} className="text-blue-600 hover:underline text-xs">
                        View Sale →
                      </Link>
                    ) : view === "active" ? (
                      <>
                        <button onClick={() => openConvertReview(l)} className="text-emerald-600 hover:underline text-xs font-medium">
                          Convert to Sale
                        </button>
                        <button onClick={() => archive(l)} className="text-amber-600 hover:underline text-xs">
                          Archive
                        </button>
                      </>
                    ) : (
                      <>
                        <button onClick={() => restore(l)} className="text-emerald-600 hover:underline text-xs">Restore</button>
                        <button onClick={() => removePermanently(l)} className="text-rose-600 hover:underline text-xs">Delete Permanently</button>
                      </>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {convertLead && convertCalc && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <form onSubmit={submitConversion} className="bg-white rounded-lg w-full max-w-2xl p-6 space-y-3 my-8">
            <h2 className="font-semibold text-slate-800">Review Before Creating Sale</h2>
            <p className="text-xs text-slate-500 -mt-2">
              Everything here started from your saved quotation — review and adjust anything before it becomes a real sale.
            </p>

            <div className="grid grid-cols-2 gap-3">
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Customer</span>
                <select className="input mt-1" value={convertForm.customerId}
                  onChange={(e) => setConvertForm({ ...convertForm, customerId: e.target.value })}>
                  <option value="">— Create new from quotation —</option>
                  {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </label>
              {!convertForm.customerId && (
                <div className="grid grid-cols-2 gap-2">
                  <label className="block">
                    <span className="text-xs text-slate-600 font-medium">New Customer Name *</span>
                    <input required className="input mt-1" value={convertForm.name}
                      onChange={(e) => setConvertForm({ ...convertForm, name: e.target.value })} />
                  </label>
                  <label className="block">
                    <span className="text-xs text-slate-600 font-medium">Phone</span>
                    <input className="input mt-1" value={convertForm.phone}
                      onChange={(e) => setConvertForm({ ...convertForm, phone: e.target.value })} />
                  </label>
                  <label className="block">
                    <span className="text-xs text-slate-600 font-medium">CNIC</span>
                    <input className="input mt-1" value={convertForm.cnic}
                      onChange={(e) => setConvertForm({ ...convertForm, cnic: e.target.value })} />
                  </label>
                  <label className="block">
                    <span className="text-xs text-slate-600 font-medium">Address</span>
                    <input className="input mt-1" value={convertForm.address}
                      onChange={(e) => setConvertForm({ ...convertForm, address: e.target.value })} />
                  </label>
                  <label className="block">
                    <span className="text-xs text-slate-600 font-medium">Guarantor Name</span>
                    <input className="input mt-1" value={convertForm.guarantorName}
                      onChange={(e) => setConvertForm({ ...convertForm, guarantorName: e.target.value })} />
                  </label>
                  <label className="block">
                    <span className="text-xs text-slate-600 font-medium">Guarantor Phone</span>
                    <input className="input mt-1" value={convertForm.guarantorPhone}
                      onChange={(e) => setConvertForm({ ...convertForm, guarantorPhone: e.target.value })} />
                  </label>
                  <label className="block">
                    <span className="text-xs text-slate-600 font-medium">Guarantor Permanent Address</span>
                    <input className="input mt-1" value={convertForm.guarantorPermanentAddress}
                      onChange={(e) => setConvertForm({ ...convertForm, guarantorPermanentAddress: e.target.value })} />
                  </label>
                  <label className="block">
                    <span className="text-xs text-slate-600 font-medium">Guarantor Current Address</span>
                    <input className="input mt-1" value={convertForm.guarantorCurrentAddress}
                      onChange={(e) => setConvertForm({ ...convertForm, guarantorCurrentAddress: e.target.value })} />
                  </label>
                  <label className="block col-span-2">
                    <span className="text-xs text-slate-600 font-medium">Guarantor Occupation / Profession</span>
                    <input className="input mt-1" value={convertForm.guarantorOccupation}
                      onChange={(e) => setConvertForm({ ...convertForm, guarantorOccupation: e.target.value })} />
                  </label>
                </div>
              )}
            </div>

            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Product Name</span>
              <input className="input mt-1" value={convertForm.productName}
                onChange={(e) => setConvertForm({ ...convertForm, productName: e.target.value })} />
            </label>

            <div className="grid grid-cols-3 gap-3">
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Purchase Price</span>
                <input type="number" className="input mt-1" value={convertForm.purchasePrice}
                  onChange={(e) => setConvertForm({ ...convertForm, purchasePrice: e.target.value })} />
              </label>
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Profit %</span>
                <input type="number" className="input mt-1" value={convertForm.profitPercent}
                  onChange={(e) => setConvertForm({ ...convertForm, profitPercent: e.target.value })} />
              </label>
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Down Payment</span>
                <input type="number" className="input mt-1" value={convertForm.downPayment}
                  onChange={(e) => setConvertForm({ ...convertForm, downPayment: e.target.value })} />
              </label>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Profit Applies To</span>
                <select className="input mt-1" value={convertForm.profitMode}
                  onChange={(e) => setConvertForm({ ...convertForm, profitMode: e.target.value as ProfitCalculationMode })}>
                  <option value="full_price">Full Purchase Price</option>
                  <option value="remaining_balance">Remaining Balance</option>
                </select>
              </label>
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Installments</span>
                <input type="number" className="input mt-1" value={convertForm.numInstallments}
                  onChange={(e) => setConvertForm({ ...convertForm, numInstallments: e.target.value })} />
              </label>
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Frequency</span>
                <select className="input mt-1" value={convertForm.frequency}
                  onChange={(e) => setConvertForm({ ...convertForm, frequency: e.target.value })}>
                  <option value="monthly">Monthly</option>
                  <option value="weekly">Weekly</option>
                </select>
              </label>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Start Date</span>
                <input type="date" className="input mt-1" value={convertForm.startDate}
                  onChange={(e) => setConvertForm({ ...convertForm, startDate: e.target.value })} />
              </label>
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Discount</span>
                <input type="number" className="input mt-1" value={convertForm.discount}
                  onChange={(e) => setConvertForm({ ...convertForm, discount: e.target.value })} />
              </label>
              <label className="block">
                <span className="text-xs text-slate-600 font-medium">Linked Purchase</span>
                <select className="input mt-1" value={convertForm.purchaseId}
                  onChange={(e) => setConvertForm({ ...convertForm, purchaseId: e.target.value })}>
                  <option value="">— None —</option>
                  {purchases.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.itemName}{p.supplierName ? ` (${p.supplierName})` : ""}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Notes</span>
              <textarea className="input mt-1" rows={2} value={convertForm.notes}
                onChange={(e) => setConvertForm({ ...convertForm, notes: e.target.value })} />
            </label>

            <div className="bg-slate-900 text-white rounded-lg p-4 grid grid-cols-4 gap-3 text-sm">
              <div><div className="text-slate-400 text-xs">Profit</div><div className="font-semibold text-emerald-400">{formatCurrency(convertCalc.profit)}</div></div>
              <div><div className="text-slate-400 text-xs">Final Price</div><div className="font-semibold">{formatCurrency(convertCalc.final)}</div></div>
              <div><div className="text-slate-400 text-xs">Remaining</div><div className="font-semibold">{formatCurrency(convertCalc.remaining)}</div></div>
              <div><div className="text-slate-400 text-xs">Per Installment</div><div className="font-semibold text-amber-400">{formatCurrency(convertCalc.inst)}</div></div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setConvertLead(null)} className="px-4 py-2 text-sm rounded border border-slate-300">Cancel</button>
              <button type="submit" className="px-4 py-2 text-sm rounded bg-slate-900 text-white">Create Sale</button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />
      <Toast message={toast} onClose={() => setToast(null)} />

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}
