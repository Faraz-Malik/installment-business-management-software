import { db } from "@/db";
import {
  customers,
  suppliers,
  installmentSales,
  payments,
  purchases,
  expenses,
  settings,
} from "@/db/schema";
import { sql, eq, desc } from "drizzle-orm";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { ReportPrintActions } from "@/components/ReportPrintActions";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function ReportsPage() {
  const [{ totalInvestment }] = await db
    .select({
      totalInvestment: sql<string>`COALESCE(SUM(${purchases.purchasePrice}), 0)`,
    })
    .from(purchases);
  const [{ totalExpectedReturn }] = await db
    .select({
      totalExpectedReturn: sql<string>`COALESCE(SUM(${installmentSales.finalPrice}), 0)`,
    })
    .from(installmentSales);
  const [{ totalProfit }] = await db
    .select({
      totalProfit: sql<string>`COALESCE(SUM(${installmentSales.profitAmount}), 0)`,
    })
    .from(installmentSales);
  const [{ totalReceived }] = await db
    .select({
      totalReceived: sql<string>`COALESCE(SUM(${payments.amount}), 0)`,
    })
    .from(payments);
  const [{ totalDown }] = await db
    .select({
      totalDown: sql<string>`COALESCE(SUM(${installmentSales.downPayment}), 0)`,
    })
    .from(installmentSales);
  const [{ totalExpenses }] = await db
    .select({
      totalExpenses: sql<string>`COALESCE(SUM(${expenses.amount}), 0)`,
    })
    .from(expenses);

  // Customer breakdown
  type CustomerRow = {
    id: number;
    name: string;
    phone: string | null;
    active: number;
    completed: number;
    outstanding: string | number;
  };
  const customerRows: CustomerRow[] = await db
    .select({
      id: customers.id,
      name: customers.name,
      phone: customers.phone,
      active: sql<number>`COALESCE((SELECT COUNT(*) FROM ${installmentSales} WHERE ${installmentSales.customerId} = ${customers.id} AND ${installmentSales.status} = 'active'), 0)`,
      completed: sql<number>`COALESCE((SELECT COUNT(*) FROM ${installmentSales} WHERE ${installmentSales.customerId} = ${customers.id} AND ${installmentSales.status} = 'completed'), 0)`,
      outstanding: sql<string>`COALESCE((SELECT SUM(${installmentSales.remainingBalance}) FROM ${installmentSales} WHERE ${installmentSales.customerId} = ${customers.id} AND ${installmentSales.status} = 'active'), 0)`,
    })
    .from(customers)
    .orderBy(desc(customers.id));

  // Supplier breakdown
  type SupplierRow = {
    id: number;
    name: string;
    totalPurchases: number;
    totalSpent: string | number;
  };
  const supplierRows: SupplierRow[] = await db
    .select({
      id: suppliers.id,
      name: suppliers.name,
      totalPurchases: sql<number>`COALESCE((SELECT COUNT(*) FROM ${purchases} WHERE ${purchases.supplierId} = ${suppliers.id}), 0)`,
      totalSpent: sql<string>`COALESCE((SELECT SUM(${purchases.purchasePrice}) FROM ${purchases} WHERE ${purchases.supplierId} = ${suppliers.id}), 0)`,
    })
    .from(suppliers)
    .orderBy(desc(suppliers.id));

  // Overdue sales - JS logic (simplified)
  type ActiveSaleForOverdue = {
    id: number;
    customerName: string | null;
    productName: string;
    startDate: string;
    numInstallments: number;
    installmentAmount: string;
    frequency: string;
    downPayment: string;
    remainingBalance: string;
    totalPaid: string;
  };
  const activeSales: ActiveSaleForOverdue[] = await db
    .select({
      id: installmentSales.id,
      customerName: customers.name,
      productName: installmentSales.productName,
      startDate: installmentSales.startDate,
      numInstallments: installmentSales.numInstallments,
      installmentAmount: installmentSales.installmentAmount,
      frequency: installmentSales.frequency,
      downPayment: installmentSales.downPayment,
      remainingBalance: installmentSales.remainingBalance,
      totalPaid:
        sql<string>`COALESCE((SELECT SUM(${payments.amount}) FROM ${payments} WHERE ${payments.saleId} = ${installmentSales.id}), 0)`.as(
          "total_paid",
        ),
    })
    .from(installmentSales)
    .leftJoin(customers, eq(installmentSales.customerId, customers.id))
    .where(eq(installmentSales.status, "active"))
    .orderBy(desc(installmentSales.id));

  const now = new Date();
  const overdue = activeSales
    .map((s) => {
      const start = new Date(s.startDate);
      const monthsElapsed = Math.max(
        0,
        (now.getFullYear() - start.getFullYear()) * 12 +
          (now.getMonth() - start.getMonth()),
      );
      const periodsElapsed =
        s.frequency === "weekly"
          ? Math.max(
              0,
              Math.floor((now.getTime() - start.getTime()) / (7 * 86400000)),
            )
          : monthsElapsed;
      const expectedPaid = Math.min(
        periodsElapsed * parseFloat(s.installmentAmount),
        parseFloat(s.installmentAmount) * s.numInstallments,
      );
      const paid = parseFloat(s.totalPaid);
      const shortfall = expectedPaid - paid;
      return { ...s, expectedPaid, paid, shortfall };
    })
    .filter((s) => s.shortfall > 0.01);

  const settingsRow = (await db.select().from(settings).limit(1))[0];
  const currency = settingsRow?.currency ?? "PKR";

  const receivedIncludingDown =
    parseFloat(totalReceived) + parseFloat(totalDown);
  const outstanding =
    parseFloat(totalExpectedReturn) - receivedIncludingDown;
  const realizedProfit = Math.max(
    0,
    Math.min(
      parseFloat(totalProfit),
      receivedIncludingDown - parseFloat(totalInvestment),
    ),
  );
  const netProfit = realizedProfit - parseFloat(totalExpenses);

  const bizRows = [
    { label: "Total Investment (purchases)", value: parseFloat(totalInvestment), tone: "text-slate-800" },
    { label: "Total Expected Return", value: parseFloat(totalExpectedReturn), tone: "text-blue-700" },
    { label: "Expected Profit", value: parseFloat(totalProfit), tone: "text-emerald-700" },
    { label: "Total Received", value: receivedIncludingDown, tone: "text-emerald-700" },
    { label: "Outstanding (customers)", value: Math.max(0, outstanding), tone: "text-rose-700" },
    { label: "Total Expenses", value: parseFloat(totalExpenses), tone: "text-orange-700" },
    { label: "Realized Profit", value: realizedProfit, tone: "text-emerald-700" },
    { label: "Net Profit (after expenses)", value: netProfit, tone: netProfit >= 0 ? "text-emerald-700" : "text-rose-700" },
  ];

  return (
    <div>
      <PageHeader
        title="Reports"
        description="Business, customer, and supplier analytics."
        actions={
          <div className="flex items-center gap-2">
            <Link
              href="/reports/statement"
              className="px-4 py-2 rounded-md border border-slate-300 text-sm hover:bg-slate-50 print:hidden"
            >
              📄 Generate Statement
            </Link>
            <ReportPrintActions />
          </div>
        }
      />

      <div id="report-content">
      {/* Business Report */}
      <section className="mb-8">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500 mb-2">
          Business Overview
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {bizRows.map((r) => (
            <div
              key={r.label}
              className="bg-white rounded-lg border border-slate-200 p-4"
            >
              <div className="text-xs text-slate-500">{r.label}</div>
              <div className={`text-lg font-semibold mt-1 ${r.tone}`}>
                {formatCurrency(r.value, currency)}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Overdue */}
      <section className="mb-8">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500 mb-2">
          Overdue Installments ({overdue.length})
        </h2>
        <div className="bg-white rounded-lg border border-slate-200 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="text-left px-4 py-2 font-medium">Customer</th>
                <th className="text-left px-4 py-2 font-medium">Product</th>
                <th className="text-left px-4 py-2 font-medium">Start</th>
                <th className="text-right px-4 py-2 font-medium">Expected</th>
                <th className="text-right px-4 py-2 font-medium">Paid</th>
                <th className="text-right px-4 py-2 font-medium">Shortfall</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {overdue.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-500">
                    🎉 No overdue installments.
                  </td>
                </tr>
              )}
              {overdue.map((s) => (
                <tr key={s.id}>
                  <td className="px-4 py-2 font-medium">{s.customerName}</td>
                  <td className="px-4 py-2">{s.productName}</td>
                  <td className="px-4 py-2">{formatDate(s.startDate)}</td>
                  <td className="px-4 py-2 text-right">
                    {formatCurrency(s.expectedPaid, currency)}
                  </td>
                  <td className="px-4 py-2 text-right">
                    {formatCurrency(s.paid, currency)}
                  </td>
                  <td className="px-4 py-2 text-right font-semibold text-rose-700">
                    {formatCurrency(s.shortfall, currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Customers */}
      <section className="mb-8">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500 mb-2">
          Customer Report
        </h2>
        <div className="bg-white rounded-lg border border-slate-200 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="text-left px-4 py-2 font-medium">Customer</th>
                <th className="text-left px-4 py-2 font-medium">Phone</th>
                <th className="text-right px-4 py-2 font-medium">Active</th>
                <th className="text-right px-4 py-2 font-medium">Completed</th>
                <th className="text-right px-4 py-2 font-medium">
                  Outstanding
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {customerRows.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-slate-500">
                    No customers.
                  </td>
                </tr>
              )}
              {customerRows.map((c) => (
                <tr key={c.id}>
                  <td className="px-4 py-2 font-medium">{c.name}</td>
                  <td className="px-4 py-2">{c.phone ?? "-"}</td>
                  <td className="px-4 py-2 text-right">{c.active}</td>
                  <td className="px-4 py-2 text-right">{c.completed}</td>
                  <td className="px-4 py-2 text-right text-rose-700 font-medium">
                    {formatCurrency(c.outstanding, currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Suppliers */}
      <section>
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500 mb-2">
          Supplier Report
        </h2>
        <div className="bg-white rounded-lg border border-slate-200 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="text-left px-4 py-2 font-medium">Supplier</th>
                <th className="text-right px-4 py-2 font-medium">Purchases</th>
                <th className="text-right px-4 py-2 font-medium">Total Spent</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {supplierRows.length === 0 && (
                <tr>
                  <td colSpan={3} className="p-6 text-center text-slate-500">
                    No suppliers.
                  </td>
                </tr>
              )}
              {supplierRows.map((s) => (
                <tr key={s.id}>
                  <td className="px-4 py-2 font-medium">{s.name}</td>
                  <td className="px-4 py-2 text-right">{s.totalPurchases}</td>
                  <td className="px-4 py-2 text-right font-medium">
                    {formatCurrency(s.totalSpent, currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      </div>
    </div>
  );
}
