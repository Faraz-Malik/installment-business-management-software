"use client";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { saveAsPDF } from "@/lib/pdf";

type Customer = { id: number; name: string };
type Transaction = {
  date: string;
  type: "sale" | "payment";
  description: string;
  debit: number;
  credit: number;
};
type Statement = {
  business: {
    businessName: string;
    businessPhone: string | null;
    businessAddress: string | null;
    currency: string;
    receiptFooter: string | null;
  };
  customer: { id: number; name: string; phone: string | null; cnic: string | null } | null;
  period: { from: string; to: string };
  openingBalance: number;
  transactions: Transaction[];
  totalDebits: number;
  totalCredits: number;
  closingBalance: number;
  generatedAt: string;
};

function isoDaysAgo(days: number) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().slice(0, 10);
}
function isoToday() {
  return new Date().toISOString().slice(0, 10);
}
function isoMonthsAgo(months: number) {
  const d = new Date();
  d.setMonth(d.getMonth() - months);
  return d.toISOString().slice(0, 10);
}
function isoYearsAgo(years: number) {
  const d = new Date();
  d.setFullYear(d.getFullYear() - years);
  return d.toISOString().slice(0, 10);
}

const PRESETS: { label: string; from: () => string }[] = [
  { label: "Daily", from: () => isoToday() },
  { label: "Weekly", from: () => isoDaysAgo(7) },
  { label: "Monthly", from: () => isoMonthsAgo(1) },
  { label: "Quarterly", from: () => isoMonthsAgo(3) },
  { label: "Six-Month", from: () => isoMonthsAgo(6) },
  { label: "Annual", from: () => isoYearsAgo(1) },
];

export default function StatementPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customerId, setCustomerId] = useState("");
  const [from, setFrom] = useState(isoMonthsAgo(1));
  const [to, setTo] = useState(isoToday());
  const [statement, setStatement] = useState<Statement | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/customers")
      .then((r) => r.json())
      .then(setCustomers);
  }, []);

  async function generate() {
    setLoading(true);
    setError(null);
    const params = new URLSearchParams({ from, to });
    if (customerId) params.set("customerId", customerId);
    const r = await fetch(`/api/reports/statement?${params}`);
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      setError(err.error || "Failed to generate statement");
      setStatement(null);
      setLoading(false);
      return;
    }
    setStatement(await r.json());
    setLoading(false);
  }

  return (
    <div>
      <PageHeader
        title="Statements"
        description="Professional, bank-style account statements for a customer or the whole business."
      />

      <div className="bg-white rounded-lg border border-slate-200 p-5 mb-6 print:hidden">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
          <label className="block">
            <span className="text-xs text-slate-600 font-medium">Customer</span>
            <select
              className="input mt-1"
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value)}
            >
              <option value="">— Business Overview (all customers) —</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="text-xs text-slate-600 font-medium">From</span>
            <input
              type="date"
              className="input mt-1"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
            />
          </label>
          <label className="block">
            <span className="text-xs text-slate-600 font-medium">To</span>
            <input
              type="date"
              className="input mt-1"
              value={to}
              onChange={(e) => setTo(e.target.value)}
            />
          </label>
          <button
            onClick={generate}
            disabled={loading}
            className="px-4 py-2 rounded-md bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 disabled:opacity-60"
          >
            {loading ? "Generating…" : "Generate Statement"}
          </button>
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {PRESETS.map((p) => (
            <button
              key={p.label}
              onClick={() => {
                setFrom(p.from());
                setTo(isoToday());
              }}
              className="px-3 py-1 text-xs rounded border border-slate-300 hover:bg-slate-50"
            >
              {p.label}
            </button>
          ))}
        </div>
        {error && (
          <div className="mt-3 p-2 bg-rose-50 text-rose-700 text-sm rounded">
            {error}
          </div>
        )}
      </div>

      {statement && (
        <>
          <div className="mb-4 print:hidden">
            <button
              onClick={() =>
                saveAsPDF(
                  `Statement-${statement.customer?.name ?? "Business"}-${statement.period.from}-to-${statement.period.to}.pdf`,
                )
              }
              className="px-4 py-2 text-sm rounded border border-slate-300 hover:bg-slate-50 mr-2"
            >
              ⬇ Save as PDF
            </button>
            <button
              onClick={() => window.print()}
              className="px-4 py-2 text-sm rounded bg-slate-900 text-white"
            >
              🖨 Print
            </button>
          </div>

          <div id="statement" className="bg-white rounded-lg border border-slate-200 p-8 print:border-0 print:rounded-none">
            <div className="flex justify-between items-start border-b-2 border-slate-800 pb-4 mb-4">
              <div>
                <div className="text-xl font-bold text-slate-900">
                  {statement.business.businessName}
                </div>
                {statement.business.businessAddress && (
                  <div className="text-xs text-slate-500">
                    {statement.business.businessAddress}
                  </div>
                )}
                {statement.business.businessPhone && (
                  <div className="text-xs text-slate-500">
                    ☎ {statement.business.businessPhone}
                  </div>
                )}
              </div>
              <div className="text-right">
                <div className="text-lg font-semibold text-slate-800">
                  ACCOUNT STATEMENT
                </div>
                <div className="text-xs text-slate-500">
                  Period: {formatDate(statement.period.from)} — {formatDate(statement.period.to)}
                </div>
                <div className="text-xs text-slate-400">
                  Generated: {new Date(statement.generatedAt).toLocaleString()}
                </div>
              </div>
            </div>

            {statement.customer && (
              <div className="mb-4 text-sm">
                <span className="text-slate-500">Statement for: </span>
                <strong>{statement.customer.name}</strong>
                {statement.customer.phone && <span> · {statement.customer.phone}</span>}
                {statement.customer.cnic && <span> · CNIC: {statement.customer.cnic}</span>}
              </div>
            )}

            <div className="grid grid-cols-3 gap-4 mb-6 text-sm">
              <div className="bg-slate-50 rounded p-3">
                <div className="text-xs text-slate-500">Opening Balance</div>
                <div className="text-lg font-semibold">
                  {formatCurrency(statement.openingBalance, statement.business.currency)}
                </div>
              </div>
              <div className="bg-slate-50 rounded p-3">
                <div className="text-xs text-slate-500">Total Payments Received</div>
                <div className="text-lg font-semibold text-emerald-700">
                  {formatCurrency(statement.totalCredits, statement.business.currency)}
                </div>
              </div>
              <div className="bg-slate-50 rounded p-3">
                <div className="text-xs text-slate-500">Closing Balance</div>
                <div className="text-lg font-semibold text-rose-700">
                  {formatCurrency(statement.closingBalance, statement.business.currency)}
                </div>
              </div>
            </div>

            <table className="w-full text-sm mb-6">
              <thead className="border-b-2 border-slate-300">
                <tr>
                  <th className="text-left py-2 font-medium text-slate-600">Date</th>
                  <th className="text-left py-2 font-medium text-slate-600">Description</th>
                  <th className="text-right py-2 font-medium text-slate-600">Debit</th>
                  <th className="text-right py-2 font-medium text-slate-600">Credit</th>
                  <th className="text-right py-2 font-medium text-slate-600">Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="py-2 text-slate-500" colSpan={4}>
                    Opening Balance
                  </td>
                  <td className="py-2 text-right font-medium">
                    {formatCurrency(statement.openingBalance, statement.business.currency)}
                  </td>
                </tr>
                {(() => {
                  let running = statement.openingBalance;
                  return statement.transactions.map((t, i) => {
                    running += t.debit - t.credit;
                    return (
                      <tr key={i}>
                        <td className="py-2">{formatDate(t.date)}</td>
                        <td className="py-2">{t.description}</td>
                        <td className="py-2 text-right">
                          {t.debit > 0 ? formatCurrency(t.debit, statement.business.currency) : "-"}
                        </td>
                        <td className="py-2 text-right text-emerald-700">
                          {t.credit > 0 ? formatCurrency(t.credit, statement.business.currency) : "-"}
                        </td>
                        <td className="py-2 text-right font-medium">
                          {formatCurrency(running, statement.business.currency)}
                        </td>
                      </tr>
                    );
                  });
                })()}
                {statement.transactions.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-slate-400">
                      No transactions in this period.
                    </td>
                  </tr>
                )}
              </tbody>
              <tfoot className="border-t-2 border-slate-800">
                <tr>
                  <td colSpan={2} className="py-2 font-semibold">
                    Closing Balance
                  </td>
                  <td className="py-2 text-right font-semibold">
                    {formatCurrency(statement.totalDebits, statement.business.currency)}
                  </td>
                  <td className="py-2 text-right font-semibold text-emerald-700">
                    {formatCurrency(statement.totalCredits, statement.business.currency)}
                  </td>
                  <td className="py-2 text-right font-semibold text-rose-700">
                    {formatCurrency(statement.closingBalance, statement.business.currency)}
                  </td>
                </tr>
              </tfoot>
            </table>

            {statement.business.receiptFooter && (
              <div className="text-xs text-slate-500 border-t border-slate-200 pt-3">
                {statement.business.receiptFooter}
              </div>
            )}
            <div className="text-xs text-slate-400 mt-2">
              This is a system-generated statement. Page 1.
            </div>
          </div>
        </>
      )}

      <style jsx global>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #statement,
          #statement * {
            visibility: visible;
          }
          #statement {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
          @page {
            margin: 1.5cm;
          }
        }
      `}</style>
      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}
