import { db } from "@/db";
import {
  customers,
  suppliers,
  installmentSales,
  payments,
  purchases,
  expenses,
  settings,
} from "@/db/schema";
import { sql, eq, desc } from "drizzle-orm";
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

async function getStats() {
  const [{ customerCount }] = await db
    .select({ customerCount: sql<number>`COUNT(*)` })
    .from(customers);
  const [{ supplierCount }] = await db
    .select({ supplierCount: sql<number>`COUNT(*)` })
    .from(suppliers);
  const [{ totalInvestment }] = await db
    .select({
      totalInvestment: sql<string>`COALESCE(SUM(${purchases.purchasePrice}), 0)`,
    })
    .from(purchases);
  const [{ totalExpectedProfit }] = await db
    .select({
      totalExpectedProfit: sql<string>`COALESCE(SUM(${installmentSales.profitAmount}), 0)`,
    })
    .from(installmentSales);
  const [{ totalFinalPrice }] = await db
    .select({
      totalFinalPrice: sql<string>`COALESCE(SUM(${installmentSales.finalPrice}), 0)`,
    })
    .from(installmentSales);
  const [{ totalDown }] = await db
    .select({
      totalDown: sql<string>`COALESCE(SUM(${installmentSales.downPayment}), 0)`,
    })
    .from(installmentSales);
  const [{ receivedPayments }] = await db
    .select({
      receivedPayments: sql<string>`COALESCE(SUM(${payments.amount}), 0)`,
    })
    .from(payments);
  const [{ totalExpenses }] = await db
    .select({
      totalExpenses: sql<string>`COALESCE(SUM(${expenses.amount}), 0)`,
    })
    .from(expenses);

  const [{ activeSales }] = await db
    .select({ activeSales: sql<number>`COUNT(*)` })
    .from(installmentSales)
    .where(eq(installmentSales.status, "active"));

  const [{ completedSales }] = await db
    .select({ completedSales: sql<number>`COUNT(*)` })
    .from(installmentSales)
    .where(eq(installmentSales.status, "completed"));

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1)
    .toISOString()
    .slice(0, 10);
  const [{ monthlyCollection }] = await db
    .select({
      monthlyCollection: sql<string>`COALESCE(SUM(${payments.amount}), 0)`,
    })
    .from(payments)
    .where(sql`${payments.paidOn} >= ${monthStart}`);

  const totalReceived =
    parseFloat(receivedPayments) + parseFloat(totalDown);
  const pending = parseFloat(totalFinalPrice) - totalReceived;

  return {
    customerCount,
    supplierCount,
    totalInvestment: parseFloat(totalInvestment),
    totalExpectedProfit: parseFloat(totalExpectedProfit),
    totalReceived,
    pending: Math.max(0, pending),
    monthlyCollection: parseFloat(monthlyCollection),
    totalExpenses: parseFloat(totalExpenses),
    activeSales,
    completedSales,
  };
}

type RecentPaymentRow = {
  id: number;
  amount: string | number;
  paidOn: string;
  receiptNumber: string;
  customerName: string | null;
  productName: string | null;
};

async function getRecentPayments(): Promise<RecentPaymentRow[]> {
  const rows = await db
    .select({
      id: payments.id,
      amount: payments.amount,
      paidOn: payments.paidOn,
      receiptNumber: payments.receiptNumber,
      customerName: customers.name,
      productName: installmentSales.productName,
    })
    .from(payments)
    .leftJoin(installmentSales, eq(payments.saleId, installmentSales.id))
    .leftJoin(customers, eq(installmentSales.customerId, customers.id))
    .orderBy(desc(payments.id))
    .limit(6);
  return rows;
}

type ActiveSaleRow = {
  id: number;
  productName: string;
  customerName: string | null;
  remainingBalance: string | number;
  installmentAmount: string | number;
  startDate: string;
};

async function getActiveSales(): Promise<ActiveSaleRow[]> {
  const rows = await db
    .select({
      id: installmentSales.id,
      productName: installmentSales.productName,
      customerName: customers.name,
      remainingBalance: installmentSales.remainingBalance,
      installmentAmount: installmentSales.installmentAmount,
      startDate: installmentSales.startDate,
    })
    .from(installmentSales)
    .leftJoin(customers, eq(installmentSales.customerId, customers.id))
    .where(eq(installmentSales.status, "active"))
    .orderBy(desc(installmentSales.id))
    .limit(6);
  return rows;
}

async function getCurrency() {
  const rows = await db.select().from(settings).limit(1);
  return rows[0]?.currency ?? "PKR";
}

export default async function DashboardPage() {
  const [stats, recentPayments, activeSales, currency] = await Promise.all([
    getStats(),
    getRecentPayments(),
    getActiveSales(),
    getCurrency(),
  ]);

  const cards = [
    {
      label: "Customers",
      value: stats.customerCount.toString(),
      accent: "bg-blue-50 text-blue-700",
      icon: "👥",
    },
    {
      label: "Suppliers",
      value: stats.supplierCount.toString(),
      accent: "bg-purple-50 text-purple-700",
      icon: "🏭",
    },
    {
      label: "Active Deals",
      value: stats.activeSales.toString(),
      accent: "bg-amber-50 text-amber-700",
      icon: "📄",
    },
    {
      label: "Completed Deals",
      value: stats.completedSales.toString(),
      accent: "bg-emerald-50 text-emerald-700",
      icon: "✅",
    },
  ];

  const money = [
    {
      label: "Total Investment",
      value: formatCurrency(stats.totalInvestment, currency),
      sub: "Cash paid to suppliers",
      tone: "text-slate-800",
    },
    {
      label: "Expected Profit",
      value: formatCurrency(stats.totalExpectedProfit, currency),
      sub: "Profit from all deals",
      tone: "text-emerald-700",
    },
    {
      label: "Received Payments",
      value: formatCurrency(stats.totalReceived, currency),
      sub: "Down + installments",
      tone: "text-blue-700",
    },
    {
      label: "Pending Payments",
      value: formatCurrency(stats.pending, currency),
      sub: "Outstanding from customers",
      tone: "text-rose-700",
    },
    {
      label: "This Month Collection",
      value: formatCurrency(stats.monthlyCollection, currency),
      sub: "Payments in current month",
      tone: "text-indigo-700",
    },
    {
      label: "Total Expenses",
      value: formatCurrency(stats.totalExpenses, currency),
      sub: "Operating expenses",
      tone: "text-orange-700",
    },
  ];

  return (
    <div>
      <PageHeader
        title="Dashboard"
        description="Overview of your installment business at a glance."
        actions={
          <Link
            href="/sales"
            className="px-4 py-2 rounded-md bg-slate-900 text-white text-sm font-medium hover:bg-slate-800"
          >
            + New Installment Sale
          </Link>
        }
      />

      {/* KPI cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {cards.map((c) => (
          <div
            key={c.label}
            className="bg-white rounded-lg border border-slate-200 p-4 flex items-center gap-3"
          >
            <div
              className={`w-12 h-12 rounded-md flex items-center justify-center text-2xl ${c.accent}`}
            >
              {c.icon}
            </div>
            <div>
              <div className="text-xs uppercase tracking-wide text-slate-500">
                {c.label}
              </div>
              <div className="text-2xl font-semibold text-slate-900">
                {c.value}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Money cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {money.map((m) => (
          <div
            key={m.label}
            className="bg-white rounded-lg border border-slate-200 p-5"
          >
            <div className="text-xs uppercase tracking-wide text-slate-500">
              {m.label}
            </div>
            <div className={`text-xl font-semibold mt-1 ${m.tone}`}>
              {m.value}
            </div>
            <div className="text-xs text-slate-400 mt-1">{m.sub}</div>
          </div>
        ))}
      </div>

      {/* Recent activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg border border-slate-200">
          <div className="px-5 py-3 border-b border-slate-200 flex items-center justify-between">
            <h2 className="font-semibold text-slate-800">Recent Payments</h2>
            <Link
              href="/payments"
              className="text-xs text-blue-600 hover:underline"
            >
              View all →
            </Link>
          </div>
          <div className="divide-y divide-slate-100">
            {recentPayments.length === 0 && (
              <div className="p-6 text-sm text-slate-500 text-center">
                No payments recorded yet.
              </div>
            )}
            {recentPayments.map((p) => (
              <div
                key={p.id}
                className="px-5 py-3 flex items-center justify-between"
              >
                <div>
                  <div className="font-medium text-sm text-slate-800">
                    {p.customerName ?? "—"}
                  </div>
                  <div className="text-xs text-slate-500">
                    {p.productName ?? "—"} · {p.receiptNumber}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-emerald-700 text-sm">
                    {formatCurrency(p.amount, currency)}
                  </div>
                  <div className="text-xs text-slate-400">
                    {formatDate(p.paidOn)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg border border-slate-200">
          <div className="px-5 py-3 border-b border-slate-200 flex items-center justify-between">
            <h2 className="font-semibold text-slate-800">Active Deals</h2>
            <Link
              href="/sales"
              className="text-xs text-blue-600 hover:underline"
            >
              View all →
            </Link>
          </div>
          <div className="divide-y divide-slate-100">
            {activeSales.length === 0 && (
              <div className="p-6 text-sm text-slate-500 text-center">
                No active installment sales.
              </div>
            )}
            {activeSales.map((s) => (
              <Link
                key={s.id}
                href={`/sales/${s.id}`}
                className="px-5 py-3 flex items-center justify-between hover:bg-slate-50"
              >
                <div>
                  <div className="font-medium text-sm text-slate-800">
                    {s.productName}
                  </div>
                  <div className="text-xs text-slate-500">
                    {s.customerName} · started {formatDate(s.startDate)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-rose-700 text-sm">
                    {formatCurrency(s.remainingBalance, currency)}
                  </div>
                  <div className="text-xs text-slate-400">
                    {formatCurrency(s.installmentAmount, currency)} / period
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
