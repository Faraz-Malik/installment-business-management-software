"use client";
import { use, useEffect, useState } from "react";
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { formatCurrency, formatDate } from "@/lib/format";
import { ConfirmDialog, type ConfirmRequest } from "@/components/ConfirmDialog";
import { Toast } from "@/components/Toast";

type Investment = {
  id: number;
  investorId: number;
  investorName: string | null;
  amount: number;
  startDate: string;
  status: string;
  notes: string | null;
  agreementId: number;
  agreementType: string;
  fixedMonthlyAmount: number | null;
  percentageRate: number | null;
  paymentFrequency: string;
  reinvestmentMode: string;
  lossPolicy: string;
  agreementStatus: string;
};
type Tx = { id: number; type: string; amount: number; date: string; notes: string | null };
type Balance = { principal: number; totalReturnsPaid: number; totalReinvested: number; totalWithdrawn: number };

const TX_LABELS: Record<string, string> = {
  return_payment: "Return Payment",
  reinvestment: "Reinvestment",
  withdrawal: "Withdrawal",
  settlement_adjustment: "Settlement Adjustment",
  contribution: "Initial Contribution",
};

export default function InvestmentDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [investment, setInvestment] = useState<Investment | null>(null);
  const [transactions, setTransactions] = useState<Tx[]>([]);
  const [balance, setBalance] = useState<Balance | null>(null);
  const [suggestedReturn, setSuggestedReturn] = useState<number | null>(null);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [txForm, setTxForm] = useState({ type: "return_payment", amount: "", date: new Date().toISOString().slice(0, 10), notes: "" });

  async function load() {
    const r = await fetch(`/api/investments/${id}`);
    const d = await r.json();
    setInvestment(d.investment);
    setTransactions(d.transactions);
    setBalance(d.balance);
    setSuggestedReturn(d.suggestedReturn);
    if (d.suggestedReturn != null) {
      setTxForm((f) => (f.amount === "" ? { ...f, amount: String(d.suggestedReturn) } : f));
    }
  }
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function recordTx(e: React.FormEvent) {
    e.preventDefault();
    const r = await fetch(`/api/investments/${id}/transactions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        type: txForm.type,
        amount: parseFloat(txForm.amount),
        date: txForm.date,
        notes: txForm.notes || null,
      }),
    });
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      setToast(err.error || "Failed to record transaction");
      return;
    }
    setTxForm({ type: "return_payment", amount: "", date: new Date().toISOString().slice(0, 10), notes: "" });
    await load();
  }

  function closeAgreement() {
    setConfirmReq({
      message: "Close and finalize this investment? The record and its full history stay — this just marks it as done, so no further returns are expected against it.",
      onConfirm: async () => {
        await fetch(`/api/investment-agreements/${investment?.agreementId}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ status: "closed" }),
        });
        setToast("Agreement closed");
        await load();
      },
    });
  }

  if (!investment || !balance) return <div className="text-slate-500 text-sm">Loading…</div>;

  return (
    <div>
      <PageHeader
        title={`${investment.investorName || "Investor"} — Investment #${investment.id}`}
        description={`Started ${formatDate(investment.startDate)} · ${investment.agreementType.replace("_", " ")} · ${investment.paymentFrequency.replace("_", " ")}`}
        actions={
          <div className="flex gap-2 items-center">
            <Link href={`/investors/${investment.investorId}`} className="text-sm text-blue-600 hover:underline">← Back to investor</Link>
            {investment.agreementStatus === "active" && (
              <button onClick={closeAgreement} className="px-4 py-2 rounded-md border border-rose-300 text-rose-700 text-sm">
                Close & Finalize This Investment
              </button>
            )}
          </div>
        }
      />

      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-slate-50 rounded-lg p-4"><div className="text-xs text-slate-500">Principal</div><div className="text-lg font-semibold">{formatCurrency(balance.principal)}</div></div>
        <div className="bg-slate-50 rounded-lg p-4"><div className="text-xs text-slate-500">Returns Paid</div><div className="text-lg font-semibold text-emerald-700">{formatCurrency(balance.totalReturnsPaid)}</div></div>
        <div className="bg-slate-50 rounded-lg p-4"><div className="text-xs text-slate-500">Reinvested</div><div className="text-lg font-semibold">{formatCurrency(balance.totalReinvested)}</div></div>
        <div className="bg-slate-50 rounded-lg p-4"><div className="text-xs text-slate-500">Withdrawn</div><div className="text-lg font-semibold text-rose-700">{formatCurrency(balance.totalWithdrawn)}</div></div>
      </div>

      {investment.agreementStatus === "active" && (
        <form onSubmit={recordTx} className="bg-white rounded-lg border border-slate-200 p-5 mb-6">
          <h3 className="font-semibold text-slate-800 mb-3">Record a Transaction</h3>
          {suggestedReturn != null && (
            <p className="text-xs text-slate-500 mb-3">
              The amount below is pre-filled with the usual return for this period (<strong>{formatCurrency(suggestedReturn)}</strong>) — change it if this period is different.
            </p>
          )}
          <div className="grid grid-cols-4 gap-3">
            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Type</span>
              <select className="input mt-1" value={txForm.type} onChange={(e) => setTxForm({ ...txForm, type: e.target.value })}>
                <option value="return_payment">Return Payment</option>
                <option value="reinvestment">Reinvestment</option>
                <option value="withdrawal">Withdrawal</option>
                <option value="settlement_adjustment">Settlement Adjustment</option>
              </select>
            </label>
            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Amount</span>
              <input required type="number" className="input mt-1" value={txForm.amount}
                onChange={(e) => setTxForm({ ...txForm, amount: e.target.value })} />
            </label>
            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Date</span>
              <input type="date" className="input mt-1" value={txForm.date}
                onChange={(e) => setTxForm({ ...txForm, date: e.target.value })} />
            </label>
            <label className="block">
              <span className="text-xs text-slate-600 font-medium">Notes</span>
              <input className="input mt-1" value={txForm.notes}
                onChange={(e) => setTxForm({ ...txForm, notes: e.target.value })} />
            </label>
          </div>
          <button type="submit" className="mt-3 px-4 py-2 text-sm rounded bg-slate-900 text-white">Record</button>
        </form>
      )}

      <div className="bg-white rounded-lg border border-slate-200">
        <div className="p-4 border-b border-slate-200"><h3 className="font-semibold">Transaction History</h3></div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-left text-slate-500 text-xs">
              <th className="px-4 py-2">Date</th>
              <th className="px-4 py-2">Type</th>
              <th className="px-4 py-2 text-right">Amount</th>
              <th className="px-4 py-2">Notes</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((t) => (
              <tr key={t.id} className="border-b border-slate-100">
                <td className="px-4 py-2">{formatDate(t.date)}</td>
                <td className="px-4 py-2">{TX_LABELS[t.type] || t.type}</td>
                <td className="px-4 py-2 text-right">{formatCurrency(t.amount)}</td>
                <td className="px-4 py-2 text-slate-500">{t.notes || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ConfirmDialog request={confirmReq} onClose={() => setConfirmReq(null)} />
      <Toast message={toast} onClose={() => setToast(null)} />

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border: 1px solid rgb(203 213 225);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}
