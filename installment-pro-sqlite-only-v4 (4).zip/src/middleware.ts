import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { SESSION_COOKIE, verifySessionToken } from "@/lib/auth";
import { isActivated } from "@/lib/license";

// Runs as real Node.js code (not the Edge runtime), so it can use
// the `crypto` module directly in auth.ts and license.ts. Node.js-
// runtime middleware support requires this file to live at
// src/middleware.ts in a project using a src/ directory — putting
// it at the project root instead means Next silently never
// registers it at all.
export const runtime = "nodejs";

// /api/health is intentionally excluded: electron/main.js polls this
// route, unauthenticated, to detect that the internal server has
// finished starting up. Gating it behind login or activation would
// make the app never finish launching.
// /api/license/status is also always reachable — it's a read-only
// check with no side effects, and gating it caused a real bug: the
// activate page's own client-side check of "am I already activated"
// would get redirected instead of getting a JSON answer.
const ALWAYS_PUBLIC = ["/api/health", "/api/license/status"];
// Reachable only while NOT activated.
const ACTIVATION_PATHS = ["/activate", "/api/license/activate"];
// Reachable only while activated but not logged in.
const LOGIN_PATHS = ["/login", "/api/auth/login"];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (
    ALWAYS_PUBLIC.includes(pathname) ||
    pathname.startsWith("/_next/") ||
    pathname.startsWith("/favicon")
  ) {
    return NextResponse.next();
  }

  // Gate 1: activation. Checked before login — an unactivated install
  // shouldn't even reach the login screen.
  const activated = isActivated();
  if (!activated) {
    if (ACTIVATION_PATHS.includes(pathname)) {
      return NextResponse.next();
    }
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "Not activated" }, { status: 403 });
    }
    return NextResponse.redirect(new URL("/activate", req.url));
  }
  // Already activated — don't let them back into the activation screen.
  if (ACTIVATION_PATHS.includes(pathname)) {
    return NextResponse.redirect(new URL("/login", req.url));
  }

  // Gate 2: login session.
  if (LOGIN_PATHS.includes(pathname)) {
    if (pathname === "/login") {
      const session = verifySessionToken(req.cookies.get(SESSION_COOKIE)?.value);
      if (session) {
        return NextResponse.redirect(new URL("/", req.url));
      }
    }
    return NextResponse.next();
  }

  const session = verifySessionToken(req.cookies.get(SESSION_COOKIE)?.value);
  if (!session) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    return NextResponse.redirect(new URL("/login", req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image).*)",
  ],
};
