# 📖 InstallmentPro — User Manual

**Welcome!** This guide explains how to use InstallmentPro to manage your installment business.

---

## 🚀 Getting Started

1. Double-click the **InstallmentPro** icon on your desktop
2. Wait 5-10 seconds for the app to open
3. You'll see the **Dashboard** with sidebar menu on the left

---

## ⚙️ First Time Setup (Do This Once)

1. Click **Settings** (in left sidebar)
2. Fill in:
   - **Business Name** (e.g., "ABC Electronics")
   - **Phone Number**
   - **Currency** (e.g., PKR, USD, INR)
   - **Address**
   - **Receipt Footer** (e.g., "Thank you for your business!")
3. Click **Save Settings**

---

## 📋 Daily Workflow

### 1️⃣ Add a Supplier (People you buy from)

1. Click **Suppliers** in sidebar
2. Click **+ New Supplier**
3. Fill: Name, Phone, Address, CNIC (optional)
4. Click **Create**

### 2️⃣ Record a Purchase (Item you bought from supplier)

1. Click **Purchases** in sidebar
2. Click **+ New Purchase**
3. Select supplier, enter item name, purchase price
4. Click **Record Purchase**

### 3️⃣ Add a Customer (People who buy on installments)

1. Click **Customers** in sidebar
2. Click **+ New Customer**
3. Fill: Name, CNIC, Phone, Address, Guarantor info
4. Click **Create**

### 4️⃣ Create an Installment Sale

1. Click **Installment Sales** in sidebar
2. Click **+ New Installment Sale**
3. Select the customer
4. Optionally link the purchase (auto-fills item + price)
5. Enter:
   - **Purchase Price** (what you paid)
   - **Profit %** (e.g., 30%)
   - **Down Payment** (money received today)
   - **Number of Installments** (e.g., 10)
   - **Frequency** (monthly or weekly)
6. See the automatic calculation:
   - Profit Amount
   - Final Sale Price
   - Remaining Amount
   - Per Installment amount
7. Click **Create Deal**

### 5️⃣ Receive a Payment

1. Click **Installment Sales**
2. Click **Open →** next to the customer's deal
3. Click **+ Receive Payment**
4. Enter amount and date
5. Click **Save Payment**
6. A receipt appears — click **🖨 Print** to print

---

## 📊 Reports

Click **Reports** in sidebar to see:
- Total investment, expected profit, realized profit
- Overdue installments (customers who are late)
- Customer report (active/completed deals, outstanding amounts)
- Supplier report (total spent per supplier)

---

## 💾 IMPORTANT: Backup Your Data Weekly!

**⚠️ Do this EVERY Monday morning:**

1. Click **Settings** in sidebar
2. Click **⬇ Download Backup**
3. Save the file (called something like `backup_2026-01-15.json`)
4. Copy it to:
   - A USB drive, OR
   - Email it to yourself, OR
   - Google Drive / OneDrive

**If your computer breaks, this file saves you!**

---

## 🔄 Restoring from Backup

If you need to restore data (e.g., new computer, data lost):

1. Install InstallmentPro on the new computer
2. Click **Settings** → **⬆ Restore from Backup**
3. Select your backup file
4. Confirm the warning
5. All data is restored! ✅

---

## 🖨 Printing Receipts

- Every payment automatically has a **Receipt** button
- Click it → Preview appears → Click **🖨 Print**
- Works with any printer including thermal receipt printers

---

## ❓ Common Questions

**Q: Does this need internet?**
A: No! It works completely offline.

**Q: Where is my data saved?**
A: `C:\Users\[YourName]\AppData\Roaming\InstallmentPro\installment-pro.db`

**Q: Can I use this on multiple computers?**
A: Yes — install on each computer, but data doesn't automatically sync. Use Backup/Restore to move data.

**Q: What if I delete a payment by mistake?**
A: There's a Delete button, but a confirmation appears first. Deleted data cannot be recovered — only restored from backup.

**Q: Can I edit an installment sale after creating it?**
A: Currently you can only delete and recreate. Ask your developer if you need this feature.

---

## 📞 Support

For any issues, contact:
- **Your Developer**: [Your name & phone]
- **WhatsApp**: [Your number]

---

**Thank you for using InstallmentPro!** 🎉
