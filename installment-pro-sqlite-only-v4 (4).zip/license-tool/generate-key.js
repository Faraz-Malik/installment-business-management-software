#!/usr/bin/env node
// ============================================================
// InstallmentPro — Activation Key Generator
// ============================================================
// FOR THE DEVELOPER'S USE ONLY. Do not include this folder in
// anything given to a client.
//
// This MUST use the exact same LICENSE_SECRET as
// src/lib/license.ts in the main project. If the two ever differ,
// every key this generates will be rejected by the app.
//
// Usage: double-click Generate-Key.bat, or run:
//   node generate-key.js
// then paste the Device ID the client sent you.
// ============================================================

const crypto = require("crypto");
const readline = require("readline");

// Keep this identical to LICENSE_SECRET in src/lib/license.ts
const LICENSE_SECRET =
  "835b2e4f3e295f1ec30d57bdefe6a2298843c55cd9b6aeadc4397dd38be9cee4";

function computeExpectedKey(deviceId) {
  const hash = crypto
    .createHmac("sha256", LICENSE_SECRET)
    .update(deviceId.trim().toUpperCase())
    .digest("hex")
    .toUpperCase();
  const raw = hash.slice(0, 20);
  return raw.match(/.{1,4}/g).join("-");
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

console.log("");
console.log("=======================================================");
console.log("  InstallmentPro — Activation Key Generator");
console.log("  (Developer use only — do not share this tool)");
console.log("=======================================================");
console.log("");

rl.question("Paste the client's Device ID and press Enter: ", (input) => {
  const deviceId = input.trim();
  if (!deviceId) {
    console.log("\nNo Device ID entered. Nothing generated.");
    rl.close();
    return;
  }

  const key = computeExpectedKey(deviceId);

  console.log("");
  console.log("Device ID:       " + deviceId.toUpperCase());
  console.log("Activation Key:  " + key);
  console.log("");
  console.log("Send this Activation Key to the client.");
  console.log("");

  rl.close();
});
