@echo off
node "%~dp0generate-key.js"
echo.
pause
