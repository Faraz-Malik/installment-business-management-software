# InstallmentPro — Activation Key Generator

**This folder is for you (the developer) only. Never send this folder,
or this project's full source, to a client — only ever send them the
built `InstallmentPro-Setup-x.x.x.exe` installer.**

## What this is

A small tool that turns a client's Device ID into the matching
Activation Key. It runs entirely on your own computer, needs no
internet connection, and works instantly.

## How to use it

1. The client installs the app and it shows a screen: **"Activate This
   Computer"** with a Device ID like `A1B2C3D4E5F6G7H8`.
2. The client sends you that Device ID (WhatsApp, call, email —
   anything).
3. On your computer, double-click **Generate-Key.bat** in this folder.
4. Paste the Device ID in when it asks, press Enter.
5. It prints an Activation Key like `F3A9-2C7D-91B4-88E0-1A55`.
6. Send that key back to the client. They type it into the Activate
   screen and click Activate.

That's it — repeat steps 1–6 for every new client. Nothing runs out;
you can activate unlimited clients this way, forever.

## Requirements

Node.js must be installed on your computer (the same one you use to
build the app). If `Generate-Key.bat` shows an error like "node is not
recognized," Node.js isn't installed or isn't in your PATH.

## Keep this safe

- **Back up this `license-tool` folder** (or at least the
  `LICENSE_SECRET` value inside `generate-key.js`) somewhere safe — a
  USB drive or a cloud folder. If you lose it, you cannot generate any
  more keys until it's rebuilt with a new secret — and a new secret
  means every previously-issued key stops working.
- **`LICENSE_SECRET` inside `generate-key.js` must always exactly
  match `LICENSE_SECRET` inside `src/lib/license.ts`** in the main
  project. If you ever change one, you must change the other to
  match, and rebuild the app — otherwise every key this tool generates
  will be rejected.

## What this does and doesn't protect against

- **Stops:** a client copying the installer file and giving it to
  someone else — a fresh install on a different PC gets its own new
  Device ID, so an old key won't activate it.
- **Does not stop:** a technically skilled person reverse-engineering
  the app to bypass the check entirely. No purely offline license
  check can fully prevent that — this is a deterrent against casual
  copying, not an unbreakable lock.
