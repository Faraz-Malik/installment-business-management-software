#!/usr/bin/env node
// ============================================================
// Full production build: next build -> patch standalone deps
// Next's tracer misses -> rebuild native modules for Electron ->
// package with electron-builder -> restore native modules to a
// system-Node build so `npm run electron:dev` / `next dev` keep
// working afterward.
//
// Unlike chaining these with `&&`/`;` in package.json (which
// either aborts the cleanup step on failure, or silently eats
// a real failure's exit code), this script always runs the
// cleanup step in a `finally` block and always exits non-zero
// if the build itself failed.
//
// Usage:
//   node scripts/electron-build.js            # full installer (electron-builder --win)
//   node scripts/electron-build.js --dir       # unpacked dir only (electron-builder --win --dir)
// ============================================================

const { execFileSync } = require("child_process");
const path = require("path");

const ROOT = path.join(__dirname, "..");
const dirOnly = process.argv.includes("--dir");

function run(cmd, args, { useShell = false } = {}) {
  console.log(`\n[electron-build] $ ${cmd} ${args.join(" ")}\n`);
  execFileSync(cmd, args, {
    cwd: ROOT,
    stdio: "inherit",
    env: process.env,
    // shell:true is only safe/needed for the npx/npm .cmd shims on
    // Windows (real .exe files, like node.exe itself via
    // process.execPath, must NOT go through shell:true — if the
    // path contains a space, e.g. "C:\Program Files\nodejs\node.exe",
    // the shell splits on it instead of treating it as one path).
    shell: useShell && process.platform === "win32",
  });
}

const npx = process.platform === "win32" ? "npx.cmd" : "npx";
const npm = process.platform === "win32" ? "npm.cmd" : "npm";

let failed = false;
try {
  run(npx, ["next", "build"], { useShell: true });
  run(process.execPath, [path.join(ROOT, "scripts", "patch-standalone-deps.js")]);
  run(process.execPath, [path.join(ROOT, "scripts", "rebuild-native-for-electron.js")]);
  run(npx, dirOnly ? ["electron-builder", "--win", "--dir"] : ["electron-builder", "--win"], { useShell: true });
} catch (err) {
  failed = true;
  console.error("\n[electron-build] Build failed:", err.message, "\n");
} finally {
  try {
    run(npm, ["rebuild", "better-sqlite3"], { useShell: true });
  } catch (cleanupErr) {
    console.error(
      "\n[electron-build] WARNING: failed to restore native modules to a system-Node build. " +
        "Run `npm run rebuild:native:node` manually before using `next dev` / `next build` again.\n",
      cleanupErr.message,
    );
  }
}

if (failed) {
  process.exit(1);
}

console.log("\n[electron-build] Done. Installer output is in dist-installer/.\n");
