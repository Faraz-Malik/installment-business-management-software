// ============================================================
// electron-builder afterPack hook
//
// WHY THIS EXISTS: electron-builder's extraResources copy step
// silently drops any directory named `node_modules` by default,
// even when the filter pattern is `**/*` and `node_modules` is
// not mentioned anywhere in `files`/`filter`. This is a built-in
// default exclusion, not a bug in this project's config — but it
// means the extraResources copy of `.next/standalone` (which is
// how the Next.js server and its dependencies, including the
// Electron-rebuilt better-sqlite3, are shipped to the packaged
// app) was landing without its node_modules at all, so the
// packaged app would fail at first launch with "Cannot find
// module 'better-sqlite3'" (or 'next', 'react', etc.) even
// though the build itself completed with no errors.
//
// Fix: copy `.next/standalone/node_modules` into the packaged
// app's resources/app/node_modules directly with plain fs,
// after electron-builder finishes packaging, bypassing its
// file-matcher entirely for this one directory.
// ============================================================

const fs = require("fs");
const path = require("path");

module.exports = async function afterPack(context) {
  const src = path.join(context.packager.projectDir, ".next", "standalone", "node_modules");
  const dest = path.join(context.appOutDir, "resources", "app", "node_modules");

  if (!fs.existsSync(src)) {
    throw new Error(
      `[afterPack] Expected ${src} to exist (produced by \`next build\`) but it does not. ` +
        `Did next build run before electron-builder?`,
    );
  }

  console.log(`[afterPack] Copying ${src} -> ${dest} (electron-builder drops node_modules from extraResources by default)`);
  fs.cpSync(src, dest, { recursive: true });

  const marker = path.join(dest, "better-sqlite3", "build", "Release", "better_sqlite3.node");
  if (!fs.existsSync(marker)) {
    throw new Error(
      `[afterPack] Copy completed but ${marker} is missing. ` +
        `The packaged app would fail at runtime — aborting the build instead of shipping it broken.`,
    );
  }

  console.log("[afterPack] node_modules copied successfully; better-sqlite3 native binary confirmed present.");
};
