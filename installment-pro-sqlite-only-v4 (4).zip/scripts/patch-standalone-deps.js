#!/usr/bin/env node
// ============================================================
// Patch packages Next's standalone-output tracer misses.
// ============================================================
// `next build` with output:'standalone' traces which files each
// route actually needs and copies only those into
// .next/standalone/node_modules. This mostly works, but has been
// confirmed (by direct inspection, not assumption) to sometimes
// trace a package incompletely or not at all:
//   - bcryptjs: not copied at all, despite being statically
//     imported in src/lib/auth.ts
//   - adm-zip: only its internal util/ subfolder was copied —
//     missing package.json and the main adm-zip.js entry file
// Both would make the packaged app crash the moment they're
// actually used (login, backup, restore) despite `next build`
// and the rest of the pipeline reporting success. This script
// copies the complete package directory from root node_modules
// into .next/standalone/node_modules, overwriting whatever
// (incomplete) trace Next produced, for exactly the packages
// confirmed to need it — not a blanket "copy everything" that
// would just reintroduce the node_modules bloat already fixed
// elsewhere in this build pipeline.
// ============================================================

const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");
const STANDALONE_MODULES = path.join(ROOT, ".next", "standalone", "node_modules");

const PACKAGES_TO_PATCH = ["bcryptjs", "adm-zip"];

function main() {
  if (!fs.existsSync(STANDALONE_MODULES)) {
    console.error(
      "[patch-standalone-deps] .next/standalone/node_modules not found. Run `next build` first.",
    );
    process.exit(1);
  }

  for (const pkg of PACKAGES_TO_PATCH) {
    const src = path.join(ROOT, "node_modules", pkg);
    const dest = path.join(STANDALONE_MODULES, pkg);

    if (!fs.existsSync(src)) {
      throw new Error(
        `[patch-standalone-deps] ${pkg} not found in root node_modules — is it installed?`,
      );
    }

    fs.rmSync(dest, { recursive: true, force: true });
    fs.cpSync(src, dest, { recursive: true });

    const pkgJson = path.join(dest, "package.json");
    if (!fs.existsSync(pkgJson)) {
      throw new Error(
        `[patch-standalone-deps] Copy of ${pkg} completed but package.json is missing at ${pkgJson} — aborting rather than shipping it broken.`,
      );
    }
    console.log(`[patch-standalone-deps] ${pkg}: patched complete copy into standalone output.`);
  }
}

main();
