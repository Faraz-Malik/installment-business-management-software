#!/usr/bin/env node
// ============================================================
// Rebuild native modules (better-sqlite3) for Electron's
// Node ABI, then patch the compiled .node binaries into the
// Next.js standalone output that electron-builder packages.
//
// WHY THIS SCRIPT EXISTS:
// `next build` must run with better-sqlite3 built for the
// SYSTEM Node (whatever `node` runs the build), because Next's
// "Collecting page data" step actually requires() the API routes
// under plain Node — not under Electron. If better-sqlite3 is
// built for Electron's ABI at that point, `next build` crashes
// with an ERR_DLOPEN_FAILED / NODE_MODULE_VERSION mismatch.
//
// But the shipped .exe runs that same code inside Electron's
// Node engine (see electron/main.js — the standalone server is
// spawned via the Electron binary with ELECTRON_RUN_AS_NODE=1),
// which needs the Electron-ABI build instead.
//
// So the correct order is:
//   1. next build   (root node_modules must be built for system Node)
//   2. THIS SCRIPT   (rebuilds root node_modules for Electron's ABI,
//                      then copies the compiled binary into
//                      .next/standalone/node_modules/<mod>, which is
//                      a separate, minimal copy Next already produced
//                      and which electron-builder ships)
//   3. electron-builder --win
//   4. rebuild:native:node (see package.json) to put root
//      node_modules back to a system-Node build, so `next dev` /
//      `next build` keep working for the next session
// ============================================================

const { execFileSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");
const STANDALONE_MODULES = path.join(ROOT, ".next", "standalone", "node_modules");

// Only native module in this build: better-sqlite3.
const NATIVE_MODULES = ["better-sqlite3"];

function getElectronVersion() {
  const electronPkg = require(path.join(ROOT, "node_modules", "electron", "package.json"));
  return electronPkg.version;
}

function rebuildRootForElectron(electronVersion) {
  console.log(`\n[rebuild-native] Rebuilding native modules for Electron ${electronVersion}...\n`);
  execFileSync(
    process.platform === "win32" ? "npx.cmd" : "npx",
    [
      "electron-rebuild",
      "--force",
      "--version",
      electronVersion,
      "--only",
      NATIVE_MODULES.join(","),
    ],
    { cwd: ROOT, stdio: "inherit", shell: process.platform === "win32" },
  );
}

function copyBinary(moduleName) {
  const rootBinary = path.join(
    ROOT,
    "node_modules",
    moduleName,
    "build",
    "Release",
  );
  const standaloneBinaryDir = path.join(
    STANDALONE_MODULES,
    moduleName,
    "build",
    "Release",
  );

  if (!fs.existsSync(standaloneBinaryDir)) {
    // This module wasn't traced into the standalone output at all
    // (i.e. it's genuinely unused) — nothing to patch.
    console.log(`[rebuild-native] ${moduleName}: not present in .next/standalone — skipping.`);
    return;
  }

  if (!fs.existsSync(rootBinary)) {
    throw new Error(
      `[rebuild-native] Expected a rebuilt binary at ${rootBinary} but found none. ` +
        `Did the electron-rebuild step above fail silently?`,
    );
  }

  for (const file of fs.readdirSync(rootBinary)) {
    if (file.endsWith(".node")) {
      const src = path.join(rootBinary, file);
      const dest = path.join(standaloneBinaryDir, file);
      fs.copyFileSync(src, dest);
      console.log(`[rebuild-native] ${moduleName}: patched ${dest}`);
    }
  }
}

function main() {
  if (!fs.existsSync(STANDALONE_MODULES)) {
    console.error(
      "[rebuild-native] .next/standalone/node_modules not found. " +
        "Run `next build` before this script (electron:build does this automatically).",
    );
    process.exit(1);
  }

  const electronVersion = getElectronVersion();
  rebuildRootForElectron(electronVersion);

  for (const moduleName of NATIVE_MODULES) {
    copyBinary(moduleName);
  }

  console.log(
    "\n[rebuild-native] Done. .next/standalone now contains Electron-ABI native binaries, " +
      "ready for electron-builder to package.\n",
  );
}

main();
